import tkinter as tk
from tkinter import messagebox
import subprocess
import sys
import os


# =========================
# APP WINDOW
# =========================

root = tk.Tk()

root.title("AI Gym Trainer")

root.geometry("900x650")

root.configure(
    bg="#121212"
)

root.resizable(
    False,
    False
)


# =========================
# TITLE
# =========================

title = tk.Label(
    root,
    text="AI GYM TRAINER",
    font=("Arial", 30, "bold"),
    fg="white",
    bg="#121212"
)

title.pack(
    pady=(35, 5)
)


subtitle = tk.Label(
    root,
    text="Choose an exercise to start your workout",
    font=("Arial", 14),
    fg="#aaaaaa",
    bg="#121212"
)

subtitle.pack(
    pady=(0, 30)
)


# =========================
# SELECTED EXERCISE
# =========================

selected_exercise = tk.StringVar(
    value=""
)


def select_exercise(name):

    selected_exercise.set(name)

    selected_label.config(
        text="Selected Exercise: " + name
    )


# =========================
# EXERCISE FRAME
# =========================

exercise_frame = tk.Frame(
    root,
    bg="#121212"
)

exercise_frame.pack(
    pady=10
)


# =========================
# EXERCISES
# =========================

exercises = [
    "Push-Up",
    "Squat",
    "Bicep Curl",
    "Lunge",
    "Shoulder Press",
    "Plank",
    "Dumbbell Row",
    "Lateral Raise",
    "Tricep Extension"
]


# =========================
# CREATE EXERCISE BUTTONS
# =========================

for i, exercise in enumerate(exercises):

    button = tk.Button(
        exercise_frame,
        text=exercise,
        font=("Arial", 14, "bold"),
        width=18,
        height=2,
        bg="#242424",
        fg="white",
        activebackground="#3a3a3a",
        activeforeground="white",
        relief="flat",
        cursor="hand2",
        command=lambda e=exercise:
            select_exercise(e)
    )

    row = i // 3
    column = i % 3

    button.grid(
        row=row,
        column=column,
        padx=12,
        pady=12
    )


# =========================
# SELECTED EXERCISE LABEL
# =========================

selected_label = tk.Label(
    root,
    text="Selected Exercise: None",
    font=("Arial", 14, "bold"),
    fg="#00e676",
    bg="#121212"
)

selected_label.pack(
    pady=(25, 15)
)


# =========================
# EXERCISE FILES
# =========================

exercise_files = {

    "Push-Up":
        "pushup.py",

    "Squat":
        "squat.py",

    "Bicep Curl":
        "bicep.py",

    "Lunge":
        "lunge.py",

    "Shoulder Press":
        "shoulder_press.py",

    "Plank":
        "plank.py",

    "Dumbbell Row":
        "dumbbell_row.py",

    "Lateral Raise":
        "lateral_raise.py",

    "Tricep Extension":
        "tricep_extension.py"
}


# =========================
# START WORKOUT
# =========================

def start_workout():

    exercise = selected_exercise.get()


    # -------------------------
    # CHECK SELECTION
    # -------------------------

    if exercise == "":

        messagebox.showwarning(
            "Select Exercise",
            "Please select an exercise first."
        )

        return


    # -------------------------
    # GET FILE
    # -------------------------

    file_name = exercise_files.get(
        exercise
    )


    if file_name is None:

        messagebox.showerror(
            "Error",
            "Exercise file not found."
        )

        return


    # -------------------------
    # CHECK FILE EXISTS
    # -------------------------

    if not os.path.exists(file_name):

        messagebox.showerror(
            "File Not Found",
            file_name +
            " was not found in the project folder."
        )

        return


    # -------------------------
    # HIDE MAIN MENU
    # -------------------------

    root.withdraw()


    try:

        # -------------------------
        # RUN EXERCISE
        # -------------------------

        subprocess.run(
            [
                sys.executable,
                file_name
            ]
        )


    except Exception as e:

        messagebox.showerror(
            "Workout Error",
            str(e)
        )


    finally:

        # -------------------------
        # SHOW MENU AGAIN
        # -------------------------

        root.deiconify()

        root.lift()

        root.focus_force()


# =========================
# START BUTTON
# =========================

start_button = tk.Button(
    root,
    text="START WORKOUT",
    font=("Arial", 16, "bold"),
    width=22,
    height=2,
    bg="#00c853",
    fg="white",
    activebackground="#00a844",
    activeforeground="white",
    relief="flat",
    cursor="hand2",
    command=start_workout
)

start_button.pack(
    pady=10
)


# =========================
# WORKOUT HISTORY
# =========================

def show_history():

    history_file = (
        "workout_history.json"
    )


    if not os.path.exists(
        history_file
    ):

        messagebox.showinfo(
            "Workout History",
            "No workout history found yet."
        )

        return


    messagebox.showinfo(
        "Workout History",
        "Workout history dashboard will be added next."
    )


# =========================
# HISTORY BUTTON
# =========================

history_button = tk.Button(
    root,
    text="VIEW WORKOUT HISTORY",
    font=("Arial", 12, "bold"),
    width=25,
    height=2,
    bg="#333333",
    fg="white",
    activebackground="#444444",
    activeforeground="white",
    relief="flat",
    cursor="hand2",
    command=show_history
)

history_button.pack(
    pady=10
)


# =========================
# RUN APPLICATION
# =========================

root.mainloop()