import cv2
import mediapipe as mp
import math
import threading
from collections import deque
from workout_tracker import WorkoutTracker


def calculate_angle(a, b, c):
    angle = math.degrees(
        math.atan2(c[1] - b[1], c[0] - b[0]) -
        math.atan2(a[1] - b[1], a[0] - b[0])
    )

    angle = abs(angle)

    if angle > 180:
        angle = 360 - angle

    return angle


class PushupWorkout:

    def __init__(self):

        self.lock = threading.RLock()

        self.running = False
        self.saved = False

        self.cap = None
        self.pose = None

        self.mp_pose = mp.solutions.pose
        self.mp_draw = mp.solutions.drawing_utils

        self.reps = 0
        self.correct_reps = 0
        self.bad_form_reps = 0

        self.stage = None
        self.reached_bottom = False
        self.bad_form_during_rep = False

        self.feedback = "GET INTO POSITION"
        self.correction = "GET INTO POSITION"

        self.tracker = None

        self.elbow_history = deque(maxlen=5)
        self.body_history = deque(maxlen=5)
        self.correction_history = deque(maxlen=6)


    def start(self):

        with self.lock:

            if self.running:
                return False

            self.cap = cv2.VideoCapture(0)

            if not self.cap.isOpened():
                self.cap.release()
                self.cap = None
                return False

            try:
                self.pose = self.mp_pose.Pose(
                    min_detection_confidence=0.5,
                    min_tracking_confidence=0.5
                )

            except Exception:
                self.cap.release()
                self.cap = None
                raise

            self.tracker = WorkoutTracker("Push Up")

            self.running = True

            return True


    def stable_correction(self, message):

        self.correction_history.append(message)

        if len(self.correction_history) < 4:
            return message

        return max(
            set(self.correction_history),
            key=self.correction_history.count
        )


    def process_frame(self):

        with self.lock:

            if not self.running or self.cap is None:
                return None

            success, frame = self.cap.read()

            if not success:
                self.running = False
                return None

            frame = cv2.flip(frame, 1)

            rgb = cv2.cvtColor(
                frame,
                cv2.COLOR_BGR2RGB
            )

            result = self.pose.process(rgb)

            elapsed = self.tracker.get_duration()

            minutes = int(elapsed // 60)
            seconds = int(elapsed % 60)

            timer_text = f"{minutes:02d}:{seconds:02d}"


            if result.pose_landmarks:

                self.mp_draw.draw_landmarks(
                    frame,
                    result.pose_landmarks,
                    self.mp_pose.POSE_CONNECTIONS
                )

                lm = result.pose_landmarks.landmark


                # LANDMARKS

                shoulder = [
                    lm[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,
                    lm[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].y
                ]

                elbow = [
                    lm[self.mp_pose.PoseLandmark.LEFT_ELBOW.value].x,
                    lm[self.mp_pose.PoseLandmark.LEFT_ELBOW.value].y
                ]

                wrist = [
                    lm[self.mp_pose.PoseLandmark.LEFT_WRIST.value].x,
                    lm[self.mp_pose.PoseLandmark.LEFT_WRIST.value].y
                ]

                hip = [
                    lm[self.mp_pose.PoseLandmark.LEFT_HIP.value].x,
                    lm[self.mp_pose.PoseLandmark.LEFT_HIP.value].y
                ]

                knee = [
                    lm[self.mp_pose.PoseLandmark.LEFT_KNEE.value].x,
                    lm[self.mp_pose.PoseLandmark.LEFT_KNEE.value].y
                ]

                ankle = [
                    lm[self.mp_pose.PoseLandmark.LEFT_ANKLE.value].x,
                    lm[self.mp_pose.PoseLandmark.LEFT_ANKLE.value].y
                ]


                # VISIBILITY

                visible = (
                    lm[self.mp_pose.PoseLandmark.LEFT_SHOULDER.value].visibility > 0.5
                    and lm[self.mp_pose.PoseLandmark.LEFT_ELBOW.value].visibility > 0.5
                    and lm[self.mp_pose.PoseLandmark.LEFT_WRIST.value].visibility > 0.5
                    and lm[self.mp_pose.PoseLandmark.LEFT_HIP.value].visibility > 0.5
                    and lm[self.mp_pose.PoseLandmark.LEFT_KNEE.value].visibility > 0.5
                    and lm[self.mp_pose.PoseLandmark.LEFT_ANKLE.value].visibility > 0.5
                )


                if visible:

                    # RAW ANGLES

                    raw_elbow_angle = calculate_angle(
                        shoulder,
                        elbow,
                        wrist
                    )

                    raw_body_angle = calculate_angle(
                        shoulder,
                        hip,
                        ankle
                    )


                    # SMOOTH ANGLES

                    self.elbow_history.append(
                        raw_elbow_angle
                    )

                    self.body_history.append(
                        raw_body_angle
                    )

                    elbow_angle = (
                        sum(self.elbow_history)
                        / len(self.elbow_history)
                    )

                    body_angle = (
                        sum(self.body_history)
                        / len(self.body_history)
                    )


                    # BODY ERROR DIRECTION

                    sx, sy = shoulder
                    hx, hy = hip
                    ax, ay = ankle

                    dx = ax - sx
                    dy = ay - sy

                    length_squared = (
                        dx * dx + dy * dy
                    )

                    if length_squared > 0:

                        t = (
                            ((hx - sx) * dx)
                            + ((hy - sy) * dy)
                        ) / length_squared

                        expected_hip_x = sx + t * dx
                        expected_hip_y = sy + t * dy

                        hip_offset = (
                            hy - expected_hip_y
                        )

                    else:
                        hip_offset = 0


                    # REAL-TIME CORRECTION

                    current_form_good = True

                    if hip_offset > 0.045:

                        raw_correction = (
                            "RAISE YOUR HIPS"
                        )

                        current_form_good = False

                    elif hip_offset < -0.045:

                        raw_correction = (
                            "LOWER YOUR HIPS"
                        )

                        current_form_good = False

                    elif (
                        self.stage == "UP"
                        and elbow_angle < 145
                    ):

                        raw_correction = (
                            "EXTEND YOUR ARMS"
                        )

                        current_form_good = False

                    elif (
                        self.stage == "UP"
                        and elbow_angle > 105
                        and elbow_angle < 155
                    ):

                        raw_correction = (
                            "LOWER YOUR CHEST"
                        )

                    elif elbow_angle <= 95:

                        raw_correction = (
                            "GOOD DEPTH - PUSH UP"
                        )

                    else:

                        raw_correction = (
                            "GOOD FORM"
                        )


                    self.correction = (
                        self.stable_correction(
                            raw_correction
                        )
                    )


                    # TRACK FORM DURING REP

                    if self.stage in ["UP", "DOWN"]:

                        if not current_form_good:

                            self.bad_form_during_rep = True


                    # PUSH-UP REP LOGIC

                    if elbow_angle >= 155:

                        if self.stage == "DOWN":

                            if self.reached_bottom:

                                self.reps += 1

                                if self.bad_form_during_rep:

                                    self.bad_form_reps += 1

                                    self.feedback = (
                                        "REP COMPLETED - FORM ISSUE"
                                    )

                                else:

                                    self.correct_reps += 1

                                    self.feedback = (
                                        "GOOD REP"
                                    )

                                print(
                                    "Total:",
                                    self.reps,
                                    "| Correct:",
                                    self.correct_reps,
                                    "| Form issues:",
                                    self.bad_form_reps
                                )

                            else:

                                self.feedback = (
                                    "INCOMPLETE REP"
                                )

                            self.reached_bottom = False
                            self.bad_form_during_rep = False

                        else:

                            self.feedback = "READY"

                        self.stage = "UP"


                    elif elbow_angle <= 95:

                        if self.stage == "UP":

                            self.reached_bottom = True

                        self.stage = "DOWN"

                        self.feedback = "PUSH UP"


                    else:

                        if self.stage == "UP":

                            self.feedback = "LOWERING"

                        elif self.stage == "DOWN":

                            self.feedback = "PUSHING"

                        else:

                            self.feedback = (
                                "START WITH ARMS STRAIGHT"
                            )


                    # FORM SCORE

                    form_score = (
                        self.tracker.get_form_score(
                            self.correct_reps,
                            self.bad_form_reps
                        )
                    )


                    # DISPLAY COORDINATES

                    h, w, _ = frame.shape

                    shoulder_px = (
                        int(shoulder[0] * w),
                        int(shoulder[1] * h)
                    )

                    hip_px = (
                        int(hip[0] * w),
                        int(hip[1] * h)
                    )

                    ankle_px = (
                        int(ankle[0] * w),
                        int(ankle[1] * h)
                    )

                    elbow_px = (
                        int(elbow[0] * w),
                        int(elbow[1] * h)
                    )


                    # VISUAL CORRECTION

                    cv2.line(
                        frame,
                        shoulder_px,
                        ankle_px,
                        (255, 255, 255),
                        2
                    )


                    if self.correction in [
                        "RAISE YOUR HIPS",
                        "LOWER YOUR HIPS"
                    ]:

                        cv2.circle(
                            frame,
                            hip_px,
                            15,
                            (0, 0, 255),
                            -1
                        )

                        if (
                            self.correction
                            == "RAISE YOUR HIPS"
                        ):

                            arrow_end = (
                                hip_px[0],
                                hip_px[1] - 80
                            )

                        else:

                            arrow_end = (
                                hip_px[0],
                                hip_px[1] + 80
                            )

                        cv2.arrowedLine(
                            frame,
                            hip_px,
                            arrow_end,
                            (0, 0, 255),
                            5,
                            tipLength=0.3
                        )

                    else:

                        cv2.circle(
                            frame,
                            hip_px,
                            10,
                            (0, 255, 0),
                            -1
                        )


                    cv2.putText(
                        frame,
                        str(int(elbow_angle)),
                        elbow_px,
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (255, 255, 255),
                        2
                    )


                    # INFORMATION PANEL

                    cv2.rectangle(
                        frame,
                        (0, 0),
                        (680, 315),
                        (30, 30, 30),
                        -1
                    )

                    cv2.putText(
                        frame,
                        "AI GYM TRAINER - PUSH UP",
                        (20, 35),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (255, 255, 255),
                        2
                    )

                    cv2.putText(
                        frame,
                        "REPS: " + str(self.reps),
                        (20, 75),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.9,
                        (0, 255, 0),
                        2
                    )

                    cv2.putText(
                        frame,
                        "CORRECT: " + str(
                            self.correct_reps
                        ),
                        (170, 75),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.65,
                        (0, 255, 0),
                        2
                    )

                    cv2.putText(
                        frame,
                        "FORM ISSUES: " + str(
                            self.bad_form_reps
                        ),
                        (360, 75),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.65,
                        (0, 255, 255),
                        2
                    )

                    cv2.putText(
                        frame,
                        "TIME: " + timer_text,
                        (20, 115),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.65,
                        (255, 255, 255),
                        2
                    )

                    cv2.putText(
                        frame,
                        "FORM SCORE: "
                        + str(form_score)
                        + "%",
                        (260, 115),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.65,
                        (0, 255, 0),
                        2
                    )

                    cv2.putText(
                        frame,
                        "MOVEMENT: " + self.feedback,
                        (20, 155),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.65,
                        (255, 255, 0),
                        2
                    )

                    cv2.putText(
                        frame,
                        "CORRECTION:",
                        (20, 205),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (255, 255, 255),
                        2
                    )

                    if self.correction == "GOOD FORM":

                        correction_color = (
                            0, 255, 0
                        )

                    else:

                        correction_color = (
                            0, 165, 255
                        )

                    cv2.putText(
                        frame,
                        self.correction,
                        (20, 245),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.85,
                        correction_color,
                        2
                    )

                    cv2.putText(
                        frame,
                        "ELBOW: "
                        + str(int(elbow_angle))
                        + "  BODY: "
                        + str(int(body_angle)),
                        (20, 280),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.6,
                        (255, 255, 255),
                        2
                    )

                    cv2.putText(
                        frame,
                        "Use End Workout in browser",
                        (20, 305),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.5,
                        (255, 255, 255),
                        1
                    )

                else:

                    cv2.putText(
                        frame,
                        "KEEP FULL SIDE OF BODY VISIBLE",
                        (20, 50),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (0, 0, 255),
                        2
                    )

            else:

                cv2.putText(
                    frame,
                    "BODY NOT DETECTED",
                    (20, 50),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.8,
                    (0, 0, 255),
                    2
                )

            return frame


    def get_jpeg_frame(self):

        frame = self.process_frame()

        if frame is None:
            return None

        ok, encoded = cv2.imencode(
            ".jpg",
            frame,
            [cv2.IMWRITE_JPEG_QUALITY, 85]
        )

        return encoded.tobytes() if ok else None


    def get_status(self):

        with self.lock:

            return {
                "running": self.running,
                "exercise": "Push-Up",
                "reps": self.reps,
                "correct_reps": self.correct_reps,
                "form_issues": self.bad_form_reps,
                "form_score": (
                    self.tracker.get_form_score(
                        self.correct_reps,
                        self.bad_form_reps
                    )
                    if self.tracker
                    else 0
                ),
                "correction": self.correction,
                "movement": self.feedback,
                "stage": self.stage,
                "duration": (
                    self.tracker.get_duration()
                    if self.tracker
                    else 0
                )
            }


    def stop(self):

        with self.lock:

            if self.saved or not self.running:
                return None

            self.running = False

            if self.cap is not None:
                self.cap.release()
                self.cap = None

            if self.pose is not None:
                self.pose.close()
                self.pose = None

            self.saved = True

            workout = self.tracker.save_workout(
                self.correct_reps,
                self.bad_form_reps
            )

            self.tracker.print_summary(workout)

            return workout