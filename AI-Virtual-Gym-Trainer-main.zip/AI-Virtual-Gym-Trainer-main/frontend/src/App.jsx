import { useEffect, useState } from "react";
import "./App.css";

const API_URL = "http://127.0.0.1:8000";

const exercises = [
  "Push-Up",
  "Squat",
  "Bicep Curl",
  "Lunge",
  "Shoulder Press",
  "Plank",
  "Dumbbell Row",
  "Lateral Raise",
  "Tricep Extension",
];

const cameraEndpoints = {
  "Push-Up": "pushup",
  Squat: "squat",
  "Bicep Curl": "bicep",
  Lunge: "lunge",
  "Shoulder Press": "shoulder-press",
  Plank: "plank",
  "Dumbbell Row": "dumbbell-row",
  "Lateral Raise": "lateral-raise",
  "Tricep Extension": "tricep-extension",
};

function App() {
  const [workouts, setWorkouts] = useState([]);
  const [stats, setStats] = useState(null);

  const [selected, setSelected] = useState("Push-Up");
  const [starting, setStarting] = useState(false);
  const [ending, setEnding] = useState(false);

  const [workoutRunning, setWorkoutRunning] = useState(false);
  const [activeExercise, setActiveExercise] = useState(null);

  const [webCamera, setWebCamera] = useState(false);
  const [liveData, setLiveData] = useState(null);

  const [message, setMessage] = useState("");

  // =========================
  // FORMAT DURATION
  // =========================

  const formatDuration = (seconds) => {
    const totalSeconds = Math.max(
      0,
      Math.round(Number(seconds) || 0)
    );

    const minutes = Math.floor(totalSeconds / 60);
    const remainingSeconds = totalSeconds % 60;

    if (minutes > 0) {
      return `${minutes}m ${remainingSeconds}s`;
    }

    return `${remainingSeconds}s`;
  };

  // =========================
  // LOAD DASHBOARD DATA
  // =========================

  const loadData = async () => {
    try {
      const workoutResponse = await fetch(
        `${API_URL}/workouts`
      );

      if (!workoutResponse.ok) {
        throw new Error("Could not load workouts");
      }

      const workoutData = await workoutResponse.json();

      setWorkouts(
        Array.isArray(workoutData) ? workoutData : []
      );

      const statsResponse = await fetch(
        `${API_URL}/stats`
      );

      if (!statsResponse.ok) {
        throw new Error("Could not load statistics");
      }

      const statsData = await statsResponse.json();

      setStats(statsData);
    } catch (error) {
      console.error(
        "Could not load dashboard:",
        error
      );
    }
  };

  // =========================
  // RESTORE ACTIVE WORKOUT
  // =========================

  const restoreWorkout = async () => {
    try {
      const response = await fetch(
        `${API_URL}/live-workout`
      );

      if (!response.ok) {
        return;
      }

      const data = await response.json();

      if (!data.running) {
        return;
      }

      setWorkoutRunning(true);
      setActiveExercise(data.exercise);
      setSelected(data.exercise);

      const usesWebCamera =
        Object.prototype.hasOwnProperty.call(
          cameraEndpoints,
          data.exercise
        );

      setWebCamera(usesWebCamera);

      if (usesWebCamera) {
        setLiveData(data);

        setMessage(
          `${data.exercise} is running.`
        );
      } else {
        setMessage(
          `${data.exercise} is running in a separate camera window.`
        );
      }
    } catch (error) {
      console.error(
        "Could not restore workout:",
        error
      );
    }
  };

  // =========================
  // INITIAL LOAD
  // =========================

  useEffect(() => {
    loadData();
    restoreWorkout();
  }, []);

  // =========================
  // CHECK SEPARATE WINDOW WORKOUT
  // =========================

  useEffect(() => {
    if (!workoutRunning || webCamera) {
      return;
    }

    let busy = false;

    const interval = setInterval(async () => {
      if (busy) {
        return;
      }

      busy = true;

      try {
        const response = await fetch(
          `${API_URL}/workout-status`
        );

        if (!response.ok) {
          return;
        }

        const data = await response.json();

        if (data.running) {
          setActiveExercise(data.exercise);
          return;
        }

        if (data.finished) {
          setWorkoutRunning(false);
          setActiveExercise(null);
          setWebCamera(false);

          if (data.return_code === 0) {
            setMessage(
              `${data.exercise} completed. Dashboard updated.`
            );
          } else {
            setMessage(
              `${data.exercise} closed with an error. Check the backend terminal.`
            );
          }

          await loadData();
        }
      } catch (error) {
        console.error(
          "Could not check workout status:",
          error
        );
      } finally {
        busy = false;
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [workoutRunning, webCamera]);

  // =========================
  // LIVE WEB WORKOUT STATISTICS
  // =========================

  useEffect(() => {
    if (!workoutRunning || !webCamera) {
      return;
    }

    let busy = false;

    const interval = setInterval(async () => {
      if (busy) {
        return;
      }

      busy = true;

      try {
        const response = await fetch(
          `${API_URL}/live-workout`
        );

        if (!response.ok) {
          return;
        }

        const data = await response.json();

        if (data.running) {
          setLiveData(data);
        }
      } catch (error) {
        console.error(
          "Live statistics unavailable:",
          error
        );
      } finally {
        busy = false;
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [workoutRunning, webCamera]);

  // =========================
  // START WORKOUT
  // =========================

  const startWorkout = async () => {
    if (workoutRunning || starting) {
      setMessage(
        `${activeExercise || selected} is already running.`
      );

      return;
    }

    try {
      setStarting(true);

      setMessage(
        `Starting ${selected}...`
      );

      const response = await fetch(
        `${API_URL}/start-workout`,
        {
          method: "POST",

          headers: {
            "Content-Type": "application/json",
          },

          body: JSON.stringify({
            exercise: selected,
          }),
        }
      );

      const data = await response.json();

      if (!response.ok || !data.success) {
        setMessage(
          data.message ||
          "Could not start workout."
        );

        return;
      }

      setWebCamera(
        Boolean(data.web_camera)
      );

      setLiveData(null);
      setWorkoutRunning(true);
      setActiveExercise(data.exercise || selected);

      if (data.web_camera) {
        setMessage(
          `${selected} is live in your browser. Click End Workout to save.`
        );
      } else {
        setMessage(
          `${selected} is running. Press Q in the camera window when finished.`
        );
      }
    } catch (error) {
      console.error(error);

      setMessage(
        "Could not connect to the AI Gym Trainer backend."
      );
    } finally {
      setStarting(false);
    }
  };

  // =========================
  // END WEB WORKOUT
  // =========================

  const endWebWorkout = async () => {
    if (ending) {
      return;
    }

    const completedExercise = activeExercise;

    setEnding(true);

    try {
      const response = await fetch(
        `${API_URL}/end-workout`,
        {
          method: "POST",
        }
      );

      const data = await response.json();

      if (!response.ok || !data.success) {
        setMessage(
          data.message ||
          "Could not end workout."
        );

        return;
      }

      setWebCamera(false);
      setWorkoutRunning(false);
      setActiveExercise(null);
      setLiveData(null);

      await loadData();

      setMessage(
        `${completedExercise} saved. Dashboard updated.`
      );
    } catch (error) {
      console.error(error);

      setMessage(
        "Could not end workout. Check the backend terminal."
      );
    } finally {
      setEnding(false);
    }
  };

  // =========================
  // CAMERA ENDPOINT
  // =========================

  const cameraEndpoint =
    cameraEndpoints[activeExercise];

  // =========================
  // USER INTERFACE
  // =========================

  return (
    <div className="app">

      {/* HEADER */}

      <header>
        <div>
          <h1>AI Gym Trainer</h1>

          <p>
            Real-Time Exercise Detection
            &amp; Form Correction
          </p>
        </div>

        <div className="status">
          <span></span>

          {workoutRunning
            ? `${activeExercise} Running`
            : "AI System Ready"}
        </div>
      </header>

      <main>

        {/* DASHBOARD STATISTICS */}

        <section className="stats-grid">

          <div className="stat-card">
            <p>Total Workouts</p>

            <h2>
              {stats?.total_workouts ?? 0}
            </h2>
          </div>

          <div className="stat-card">
            <p>Total Reps</p>

            <h2>
              {stats?.total_reps ?? 0}
            </h2>
          </div>

          <div className="stat-card">
            <p>Average Form Score</p>

            <h2>
              {stats
                ? Number(
                    stats.average_form_score ?? 0
                  ).toFixed(1)
                : "0.0"}
              %
            </h2>
          </div>

          <div className="stat-card">
            <p>Training Time</p>

            <h2>
              {stats
                ? formatDuration(
                    stats.total_duration
                  )
                : "0s"}
            </h2>
          </div>

        </section>

        {/* EXERCISE SELECTION */}

        <section className="section">

          <div className="section-heading">
            <div>
              <h2>Choose Exercise</h2>

              <p>
                Select an exercise to begin
                AI form analysis.
              </p>
            </div>
          </div>

          <div className="exercise-grid">

            {exercises.map((exercise) => (
              <button
                key={exercise}

                className={
                  selected === exercise
                    ? "exercise-card selected"
                    : "exercise-card"
                }

                disabled={
                  workoutRunning || starting
                }

                onClick={() => {
                  setSelected(exercise);
                  setMessage("");
                }}
              >

                <div className="exercise-icon">
                  AI
                </div>

                <div>
                  <h3>
                    {exercise}
                  </h3>

                  <p>
                    Real-time form correction
                  </p>
                </div>

              </button>
            ))}

          </div>

          {/* START PANEL */}

          <div className="start-panel">

            <div>
              <p>
                {workoutRunning
                  ? "Workout In Progress"
                  : "Selected Exercise"}
              </p>

              <h2>
                {workoutRunning
                  ? activeExercise
                  : selected}
              </h2>

              {message && (
                <p
                  style={{
                    marginTop: "8px",
                  }}
                >
                  {message}
                </p>
              )}
            </div>

            <button
              className="start-button"

              onClick={startWorkout}

              disabled={
                starting ||
                workoutRunning
              }
            >
              {starting
                ? "Starting..."
                : workoutRunning
                ? "Workout Running"
                : "Start Workout"}
            </button>

          </div>

          {/* LIVE WORKOUT: CAMERA LEFT, STATISTICS RIGHT */}
          {workoutRunning && webCamera && (
            <section className="original-live-section">
              <div className="original-live-heading">
                <h2>Live AI Workout</h2>
                <p>Real-time pose detection and form correction</p>
                <span className="original-live-badge">LIVE</span>
              </div>

              <div className="original-live-layout">
                <div className="original-camera-box">
                  {cameraEndpoint ? (
                    <img
                      key={cameraEndpoint}
                      className="original-camera-feed"
                      src={`${API_URL}/video-feed/${cameraEndpoint}`}
                      alt={`${activeExercise} live camera`}
                    />
                  ) : (
                    <p>Camera unavailable for this exercise.</p>
                  )}
                </div>

                <aside className="original-live-sidebar">
                  <h2>{activeExercise}</h2>
                  <div className="original-live-row">
                    <span>{activeExercise === "Plank" ? "Good Form Hold" : "Repetitions"}</span>
                    <strong>{activeExercise === "Plank"
                      ? formatDuration(liveData?.good_form_seconds ?? 0)
                      : liveData?.reps ?? 0}</strong>
                  </div>
                  {activeExercise !== "Plank" && (
                    <div className="original-live-row">
                      <span>Correct Reps</span>
                      <strong>{liveData?.correct_reps ?? 0}</strong>
                    </div>
                  )}
                  <div className="original-live-row">
                    <span>Form Issues</span>
                    <strong>{liveData?.form_issues ?? liveData?.incorrect_reps ?? 0}</strong>
                  </div>
                  <div className="original-live-row">
                    <span>Form Score</span>
                    <strong>{Number(liveData?.form_score ?? 0).toFixed(1)}%</strong>
                  </div>
                  <div className="original-live-row">
                    <span>Duration</span>
                    <strong>{formatDuration(liveData?.duration ?? 0)}</strong>
                  </div>
                  <div className="original-correction-card">
                    <span>LIVE CORRECTION</span>
                    <strong>{liveData?.correction ?? "GET READY"}</strong>
                    <small>Movement: {liveData?.movement ?? "GET READY"}</small>
                  </div>
                  <button
                    className="original-end-button"
                    onClick={endWebWorkout}
                    disabled={ending}
                  >
                    {ending ? "Saving..." : "End Workout"}
                  </button>
                </aside>
              </div>
            </section>
          )}

        </section>

        {/* WORKOUT HISTORY */}

        <section className="section">

          <div className="section-heading">
            <div>
              <h2>Recent Workouts</h2>

              <p>
                Workout history stored
                in MySQL.
              </p>
            </div>
          </div>

          <div className="history-card">

            {workouts.length === 0 ? (
              <p className="empty">
                No workouts yet.
              </p>
            ) : (

              <div className="table-wrapper">

                <table>

                  <thead>
                    <tr>
                      <th>Exercise</th>
                      <th>Performance</th>
                      <th>Correct</th>
                      <th>Form Issues</th>
                      <th>Score</th>
                      <th>Duration</th>
                      <th>Date</th>
                    </tr>
                  </thead>

                  <tbody>

                    {workouts.map((workout) => (
                      <tr key={workout.id}>

                        <td>
                          {workout.exercise}
                        </td>

                        {workout.exercise ===
                        "Plank" ? (
                          <>
                            <td>
                              {Number(
                                workout.good_form_seconds ??
                                  0
                              ).toFixed(1)}
                              {"s hold"}
                            </td>

                            <td>—</td>
                            <td>—</td>
                          </>
                        ) : (
                          <>
                            <td>
                              {workout.total_reps}
                              {" reps"}
                            </td>

                            <td>
                              {workout.correct_reps}
                            </td>

                            <td>
                              {workout.incorrect_reps}
                            </td>
                          </>
                        )}

                        <td>
                          {Number(
                            workout.form_score ?? 0
                          ).toFixed(1)}
                          %
                        </td>

                        <td>
                          {formatDuration(
                            workout.duration_seconds
                          )}
                        </td>

                        <td>
                          {workout.created_at
                            ? new Date(
                                workout.created_at
                              ).toLocaleString()
                            : "—"}
                        </td>

                      </tr>
                    ))}

                  </tbody>

                </table>

              </div>
            )}

          </div>

        </section>

      </main>

    </div>
  );
}

export default App;