from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from database import get_connection

from bicep import BicepWorkout
from squat import SquatWorkout
from pushup import PushupWorkout
from lunge import LungeWorkout
from shoulder_press import ShoulderPressWorkout
from plank import PlankWorkout
from dumbbell_row import DumbbellRowWorkout
from lateral_raise import LateralRaiseWorkout
from tricep_extension import TricepExtensionWorkout

import subprocess
import sys
import os
import time


app = FastAPI(
    title="AI Gym Trainer API",
    version="1.5.0"
)


# =========================
# CORS
# =========================

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5174",
        "http://127.0.0.1:5174"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)


# =========================
# EXERCISE FILES
# =========================

exercise_files = {}


# =========================
# WORKOUT STATE
# =========================

bicep_workout = None
squat_workout = None
pushup_workout = None
lunge_workout = None
shoulder_press_workout = None
plank_workout = None
dumbbell_row_workout = None
lateral_raise_workout = None
tricep_extension_workout = None

workout_process = None
current_exercise = None


class WorkoutRequest(BaseModel):
    exercise: str


# =========================
# HOME
# =========================

@app.get("/")
def home():
    return {
        "message": "AI Gym Trainer API is running"
    }


# =========================
# WORKOUT HISTORY
# =========================

@app.get("/workouts")
def get_workouts():

    connection = None
    cursor = None

    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        cursor.execute("""
            SELECT
                id,
                exercise,
                total_reps,
                correct_reps,
                incorrect_reps,
                form_score,
                duration_seconds,
                good_form_seconds,
                created_at
            FROM workouts
            ORDER BY id DESC
        """)

        return cursor.fetchall()

    finally:

        if cursor is not None:
            cursor.close()

        if (
            connection is not None
            and connection.is_connected()
        ):
            connection.close()


# =========================
# DASHBOARD STATISTICS
# =========================

@app.get("/stats")
def get_stats():

    connection = None
    cursor = None

    try:
        connection = get_connection()
        cursor = connection.cursor(dictionary=True)

        cursor.execute("""
            SELECT
                COUNT(*) AS total_workouts,

                COALESCE(
                    SUM(total_reps),
                    0
                ) AS total_reps,

                COALESCE(
                    AVG(form_score),
                    0
                ) AS average_form_score,

                COALESCE(
                    SUM(duration_seconds),
                    0
                ) AS total_duration

            FROM workouts
        """)

        return cursor.fetchone()

    finally:

        if cursor is not None:
            cursor.close()

        if (
            connection is not None
            and connection.is_connected()
        ):
            connection.close()


# =========================
# ACTIVE WEB WORKOUT
# =========================

def get_active_web_workout():

    for workout in [
        bicep_workout,
        squat_workout,
        pushup_workout,
        lunge_workout,
        shoulder_press_workout,
        plank_workout,
        dumbbell_row_workout,
        lateral_raise_workout,
        tricep_extension_workout
    ]:

        if (
            workout is not None
            and workout.running
        ):
            return workout

    return None


# =========================
# START WORKOUT
# =========================

@app.post("/start-workout")
def start_workout(request: WorkoutRequest):

    global bicep_workout
    global squat_workout
    global pushup_workout
    global lunge_workout
    global shoulder_press_workout
    global plank_workout
    global dumbbell_row_workout
    global lateral_raise_workout
    global tricep_extension_workout

    global workout_process
    global current_exercise

    exercise = request.exercise

    # Prevent simultaneous workouts

    if get_active_web_workout() is not None:

        return {
            "success": False,
            "message": "A workout is already running."
        }

    if (
        workout_process is not None
        and workout_process.poll() is None
    ):

        return {
            "success": False,
            "message": "A workout is already running."
        }

    # =========================
    # BICEP CURL
    # =========================

    if exercise == "Bicep Curl":

        try:

            bicep_workout = BicepWorkout()

            started = bicep_workout.start()

            if not started:

                bicep_workout = None

                return {
                    "success": False,
                    "message": "Could not open camera."
                }

            current_exercise = exercise

            return {
                "success": True,
                "exercise": exercise,
                "web_camera": True,
                "message": "Bicep Curl started."
            }

        except Exception as e:

            bicep_workout = None
            current_exercise = None

            return {
                "success": False,
                "message": str(e)
            }

    # =========================
    # SQUAT
    # =========================

    if exercise == "Squat":

        try:

            squat_workout = SquatWorkout()

            started = squat_workout.start()

            if not started:

                squat_workout = None

                return {
                    "success": False,
                    "message": "Could not open camera."
                }

            current_exercise = exercise

            return {
                "success": True,
                "exercise": exercise,
                "web_camera": True,
                "message": "Squat started."
            }

        except Exception as e:

            squat_workout = None
            current_exercise = None

            return {
                "success": False,
                "message": str(e)
            }

    # =========================
    # PUSH-UP
    # =========================

    if exercise == "Push-Up":

        try:

            pushup_workout = PushupWorkout()

            started = pushup_workout.start()

            if not started:

                pushup_workout = None

                return {
                    "success": False,
                    "message": "Could not open camera."
                }

            current_exercise = exercise

            return {
                "success": True,
                "exercise": exercise,
                "web_camera": True,
                "message": "Push-Up started."
            }

        except Exception as e:

            pushup_workout = None
            current_exercise = None

            return {
                "success": False,
                "message": str(e)
            }

    # =========================
    # LUNGE
    # =========================

    if exercise == "Lunge":

        try:

            lunge_workout = LungeWorkout()

            started = lunge_workout.start()

            if not started:

                lunge_workout = None

                return {
                    "success": False,
                    "message": "Could not open camera."
                }

            current_exercise = exercise

            return {
                "success": True,
                "exercise": exercise,
                "web_camera": True,
                "message": "Lunge started."
            }

        except Exception as e:

            lunge_workout = None
            current_exercise = None

            return {
                "success": False,
                "message": str(e)
            }

    # =========================
    # SHOULDER PRESS
    # =========================

    if exercise == "Shoulder Press":

        try:

            shoulder_press_workout = ShoulderPressWorkout()

            started = shoulder_press_workout.start()

            if not started:

                shoulder_press_workout = None

                return {
                    "success": False,
                    "message": "Could not open camera."
                }

            current_exercise = exercise

            return {
                "success": True,
                "exercise": exercise,
                "web_camera": True,
                "message": "Shoulder Press started."
            }

        except Exception as e:

            shoulder_press_workout = None
            current_exercise = None

            return {
                "success": False,
                "message": str(e)
            }

    # =========================
    # PLANK (BROWSER CAMERA)
    # =========================

    if exercise == "Plank":

        try:
            plank_workout = PlankWorkout()
            # PlankWorkout.start() returns None on success;
            # camera errors raise an exception instead.
            plank_workout.start()
            current_exercise = exercise

            return {
                "success": True,
                "exercise": exercise,
                "web_camera": True,
                "message": "Plank started."
            }

        except Exception as e:
            plank_workout = None
            current_exercise = None

            return {
                "success": False,
                "message": str(e)
            }

    # =========================
    # DUMBBELL ROW (BROWSER CAMERA)
    # =========================

    if exercise == "Dumbbell Row":
        try:
            dumbbell_row_workout = DumbbellRowWorkout()
            started = dumbbell_row_workout.start()
            if not started:
                dumbbell_row_workout = None
                return {"success": False, "message": "Could not open camera."}

            current_exercise = exercise
            return {
                "success": True,
                "exercise": exercise,
                "web_camera": True,
                "message": "Dumbbell Row started."
            }
        except Exception as e:
            dumbbell_row_workout = None
            current_exercise = None
            return {"success": False, "message": str(e)}

    # =========================
    # LATERAL RAISE (BROWSER CAMERA)
    # =========================

    if exercise == "Lateral Raise":
        try:
            lateral_raise_workout = LateralRaiseWorkout()
            started = lateral_raise_workout.start()
            if not started:
                lateral_raise_workout = None
                return {"success": False, "message": "Could not open camera."}
            current_exercise = exercise
            return {
                "success": True,
                "exercise": exercise,
                "web_camera": True,
                "message": "Lateral Raise started."
            }
        except Exception as e:
            lateral_raise_workout = None
            current_exercise = None
            return {"success": False, "message": str(e)}

    # =========================
    # TRICEP EXTENSION (BROWSER CAMERA)
    # =========================

    if exercise == "Tricep Extension":
        try:
            tricep_extension_workout = TricepExtensionWorkout()
            started = tricep_extension_workout.start()
            if not started:
                tricep_extension_workout = None
                return {"success": False, "message": "Could not open camera."}
            current_exercise = exercise
            return {
                "success": True,
                "exercise": exercise,
                "web_camera": True,
                "message": "Tricep Extension started."
            }
        except Exception as e:
            tricep_extension_workout = None
            current_exercise = None
            return {"success": False, "message": str(e)}

    # =========================
    # OTHER EXERCISES
    # =========================

    if exercise not in exercise_files:

        return {
            "success": False,
            "message": "Invalid exercise."
        }

    file_name = exercise_files[exercise]

    base_directory = os.path.dirname(
        os.path.abspath(__file__)
    )

    script_path = os.path.join(
        base_directory,
        file_name
    )

    if not os.path.exists(script_path):

        return {
            "success": False,
            "message": f"{file_name} was not found."
        }

    try:

        workout_process = subprocess.Popen(
            [
                sys.executable,
                script_path
            ],
            cwd=base_directory
        )

        current_exercise = exercise

        return {
            "success": True,
            "exercise": exercise,
            "web_camera": False,
            "message": f"{exercise} started."
        }

    except Exception as e:

        workout_process = None
        current_exercise = None

        return {
            "success": False,
            "message": str(e)
        }


# =========================
# VIDEO GENERATOR
# =========================

def generate_frames(workout):

    while workout.running:

        frame = workout.get_jpeg_frame()

        if frame is None:

            time.sleep(0.03)

            continue

        yield (
            b"--frame\r\n"
            b"Content-Type: image/jpeg\r\n\r\n"
            + frame
            + b"\r\n"
        )


# =========================
# BICEP VIDEO
# =========================

@app.get("/video-feed/bicep")
def video_feed_bicep():

    if (
        bicep_workout is None
        or not bicep_workout.running
    ):

        return {
            "error": "Bicep workout is not running."
        }

    return StreamingResponse(
        generate_frames(bicep_workout),
        media_type=(
            "multipart/x-mixed-replace;"
            " boundary=frame"
        )
    )


# =========================
# SQUAT VIDEO
# =========================

@app.get("/video-feed/squat")
def video_feed_squat():

    if (
        squat_workout is None
        or not squat_workout.running
    ):

        return {
            "error": "Squat workout is not running."
        }

    return StreamingResponse(
        generate_frames(squat_workout),
        media_type=(
            "multipart/x-mixed-replace;"
            " boundary=frame"
        )
    )


# =========================
# PUSH-UP VIDEO
# =========================

@app.get("/video-feed/pushup")
def video_feed_pushup():

    if (
        pushup_workout is None
        or not pushup_workout.running
    ):

        return {
            "error": "Push-Up workout is not running."
        }

    return StreamingResponse(
        generate_frames(pushup_workout),
        media_type=(
            "multipart/x-mixed-replace;"
            " boundary=frame"
        )
    )


# =========================
# LUNGE VIDEO
# =========================

@app.get("/video-feed/lunge")
def video_feed_lunge():

    if (
        lunge_workout is None
        or not lunge_workout.running
    ):

        return {
            "error": "Lunge workout is not running."
        }

    return StreamingResponse(
        generate_frames(lunge_workout),
        media_type=(
            "multipart/x-mixed-replace;"
            " boundary=frame"
        )
    )


# =========================
# SHOULDER PRESS VIDEO
# =========================

@app.get("/video-feed/shoulder-press")
def video_feed_shoulder_press():

    if (
        shoulder_press_workout is None
        or not shoulder_press_workout.running
    ):

        return {
            "error": "Shoulder Press workout is not running."
        }

    return StreamingResponse(
        generate_frames(shoulder_press_workout),
        media_type=(
            "multipart/x-mixed-replace;"
            " boundary=frame"
        )
    )


# =========================
# PLANK VIDEO
# =========================

@app.get("/video-feed/plank")
def video_feed_plank():

    if plank_workout is None or not plank_workout.running:
        return {"error": "Plank workout is not running."}

    return StreamingResponse(
        generate_frames(plank_workout),
        media_type="multipart/x-mixed-replace; boundary=frame"
    )


# =========================
# DUMBBELL ROW VIDEO
# =========================

@app.get("/video-feed/dumbbell-row")
def video_feed_dumbbell_row():
    if dumbbell_row_workout is None or not dumbbell_row_workout.running:
        return {"error": "Dumbbell Row workout is not running."}

    return StreamingResponse(
        generate_frames(dumbbell_row_workout),
        media_type="multipart/x-mixed-replace; boundary=frame"
    )


# =========================
# LATERAL RAISE VIDEO
# =========================

@app.get("/video-feed/lateral-raise")
def video_feed_lateral_raise():
    if lateral_raise_workout is None or not lateral_raise_workout.running:
        return {"error": "Lateral Raise workout is not running."}
    return StreamingResponse(
        generate_frames(lateral_raise_workout),
        media_type="multipart/x-mixed-replace; boundary=frame"
    )


    # =========================
    # TRICEP EXTENSION VIDEO
    # =========================

@app.get("/video-feed/tricep-extension")
def video_feed_tricep_extension():
    if tricep_extension_workout is None or not tricep_extension_workout.running:
        return {"error": "Tricep Extension workout is not running."}
    return StreamingResponse(
        generate_frames(tricep_extension_workout),
        media_type="multipart/x-mixed-replace; boundary=frame"
    )

# =========================
# LIVE WORKOUT
# =========================

@app.get("/live-workout")
def live_workout():

    workout = get_active_web_workout()

    if workout is not None:

        return workout.get_status()

    if (
        workout_process is not None
        and workout_process.poll() is None
    ):

        return {
            "running": True,
            "exercise": current_exercise,
            "web_camera": False
        }

    return {
        "running": False,
        "exercise": None
    }


# =========================
# END WEB WORKOUT
# =========================

@app.post("/end-workout")
def end_workout():

    global bicep_workout
    global squat_workout
    global pushup_workout
    global lunge_workout
    global shoulder_press_workout
    global plank_workout
    global dumbbell_row_workout
    global lateral_raise_workout
    global tricep_extension_workout

    global current_exercise

    workout = get_active_web_workout()

    if workout is None:

        return {
            "success": False,
            "message": "No web workout is running."
        }

    exercise = current_exercise

    try:

        result = workout.stop()

        if exercise == "Bicep Curl":

            bicep_workout = None

        elif exercise == "Squat":

            squat_workout = None

        elif exercise == "Push-Up":

            pushup_workout = None

        elif exercise == "Lunge":

            lunge_workout = None

        elif exercise == "Shoulder Press":

            shoulder_press_workout = None

        elif exercise == "Plank":

            plank_workout = None

        elif exercise == "Dumbbell Row":

            dumbbell_row_workout = None

        elif exercise == "Lateral Raise":

            lateral_raise_workout = None

        elif exercise == "Tricep Extension":

            tricep_extension_workout = None

        current_exercise = None

        return {
            "success": True,
            "message": f"{exercise} workout completed.",
            "workout": result
        }

    except Exception as e:

        return {
            "success": False,
            "message": str(e)
        }


# =========================
# WORKOUT STATUS
# =========================

@app.get("/workout-status")
def workout_status():

    global workout_process
    global current_exercise

    workout = get_active_web_workout()

    if workout is not None:

        return {
            "running": True,
            "exercise": current_exercise,
            "web_camera": True
        }

    if workout_process is None:

        return {
            "running": False,
            "exercise": None
        }

    if workout_process.poll() is None:

        return {
            "running": True,
            "exercise": current_exercise,
            "web_camera": False
        }

    finished_exercise = current_exercise
    return_code = workout_process.returncode

    workout_process = None
    current_exercise = None

    return {
        "running": False,
        "finished": True,
        "exercise": finished_exercise,
        "return_code": return_code
    }