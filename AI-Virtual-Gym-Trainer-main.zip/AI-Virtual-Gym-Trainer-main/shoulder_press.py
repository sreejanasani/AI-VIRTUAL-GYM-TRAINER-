import cv2
import mediapipe as mp
import math
import threading

from collections import deque
from workout_tracker import WorkoutTracker


def calculate_angle(a, b, c):
    angle = math.degrees(
        math.atan2(c[1] - b[1], c[0] - b[0])
        - math.atan2(a[1] - b[1], a[0] - b[0])
    )

    angle = abs(angle)

    if angle > 180:
        angle = 360 - angle

    return angle


class ShoulderPressWorkout:

    def __init__(self):
        self.lock = threading.RLock()

        self.running = False
        self.saved = False

        self.cap = None
        self.pose = None
        self.tracker = None

        self.mp_pose = mp.solutions.pose
        self.mp_draw = mp.solutions.drawing_utils

        self.reps = 0
        self.incorrect = 0

        self.stage = None
        self.feedback = "GET READY"
        self.correction = "GET READY"

        self.reached_top = False
        self.bad_form_during_rep = False

        self.left_history = deque(maxlen=5)
        self.right_history = deque(maxlen=5)

    # =========================
    # START WORKOUT
    # =========================

    def start(self):
        with self.lock:
            if self.running:
                return False

            self.cap = cv2.VideoCapture(0)

            if not self.cap.isOpened():
                self.cap.release()
                self.cap = None
                return False

            try:
                self.pose = self.mp_pose.Pose(
                    min_detection_confidence=0.5,
                    min_tracking_confidence=0.5
                )
            except Exception:
                self.cap.release()
                self.cap = None
                raise

            self.tracker = WorkoutTracker("Shoulder Press")
            self.running = True

            return True

    # =========================
    # PROCESS FRAME
    # =========================

    def process_frame(self):
        with self.lock:
            if not self.running or self.cap is None:
                return None

            success, frame = self.cap.read()

            if not success:
                print("Could not access camera")
                self.running = False
                return None

            frame = cv2.flip(frame, 1)

            rgb = cv2.cvtColor(
                frame,
                cv2.COLOR_BGR2RGB
            )

            result = self.pose.process(rgb)

            elapsed = self.tracker.get_duration()
            minutes = int(elapsed // 60)
            seconds = int(elapsed % 60)

            timer_text = f"{minutes:02d}:{seconds:02d}"

            if result.pose_landmarks:

                self.mp_draw.draw_landmarks(
                    frame,
                    result.pose_landmarks,
                    self.mp_pose.POSE_CONNECTIONS
                )

                lm = result.pose_landmarks.landmark
                P = self.mp_pose.PoseLandmark

                # =========================
                # ARM LANDMARKS
                # =========================

                ls = lm[P.LEFT_SHOULDER.value]
                le = lm[P.LEFT_ELBOW.value]
                lw = lm[P.LEFT_WRIST.value]

                rs = lm[P.RIGHT_SHOULDER.value]
                re = lm[P.RIGHT_ELBOW.value]
                rw = lm[P.RIGHT_WRIST.value]

                left_shoulder = [ls.x, ls.y]
                left_elbow = [le.x, le.y]
                left_wrist = [lw.x, lw.y]

                right_shoulder = [rs.x, rs.y]
                right_elbow = [re.x, re.y]
                right_wrist = [rw.x, rw.y]

                # =========================
                # VISIBILITY
                # =========================

                visible = all(
                    landmark.visibility > 0.5
                    for landmark in [
                        ls, le, lw, rs, re, rw
                    ]
                )

                if visible:

                    # =========================
                    # ELBOW ANGLES
                    # =========================

                    raw_left_angle = calculate_angle(
                        left_shoulder,
                        left_elbow,
                        left_wrist
                    )

                    raw_right_angle = calculate_angle(
                        right_shoulder,
                        right_elbow,
                        right_wrist
                    )

                    self.left_history.append(
                        raw_left_angle
                    )

                    self.right_history.append(
                        raw_right_angle
                    )

                    left_angle = (
                        sum(self.left_history)
                        / len(self.left_history)
                    )

                    right_angle = (
                        sum(self.right_history)
                        / len(self.right_history)
                    )

                    average_angle = (
                        left_angle + right_angle
                    ) / 2

                    # =========================
                    # WRIST POSITION
                    # =========================

                    wrists_above_shoulders = (
                        left_wrist[1] < left_shoulder[1]
                        and
                        right_wrist[1] < right_shoulder[1]
                    )

                    # =========================
                    # ARM ASYMMETRY
                    # =========================

                    angle_difference = abs(
                        left_angle - right_angle
                    )

                    arms_uneven = (
                        angle_difference > 25
                        and average_angle > 110
                    )

                    if arms_uneven:
                        self.bad_form_during_rep = True

                    # =========================
                    # ORIGINAL REP LOGIC
                    # =========================

                    if average_angle < 110:

                        if (
                            self.stage == "UP"
                            and self.reached_top
                        ):

                            self.reps += 1

                            if self.bad_form_during_rep:

                                self.incorrect += 1

                                self.feedback = (
                                    "REP COMPLETED - FORM ISSUE"
                                )

                            else:
                                self.feedback = "GOOD REP"

                            print(
                                "Shoulder Press:",
                                self.reps
                            )

                        else:
                            self.feedback = "PRESS UP"

                        self.stage = "DOWN"
                        self.reached_top = False
                        self.bad_form_during_rep = False

                    elif (
                        average_angle > 155
                        and wrists_above_shoulders
                    ):

                        self.stage = "UP"
                        self.reached_top = True

                        self.feedback = (
                            "GOOD - LOWER SLOWLY"
                        )

                    else:

                        if self.stage == "DOWN":

                            self.feedback = (
                                "KEEP PRESSING"
                            )

                        elif self.stage == "UP":

                            self.feedback = (
                                "LOWER SLOWLY"
                            )

                        else:

                            self.feedback = (
                                "START WITH ARMS BENT"
                            )

                    # =========================
                    # REAL-TIME CORRECTION
                    # =========================

                    if arms_uneven:

                        self.correction = (
                            "KEEP ARMS EVEN"
                        )

                    elif self.stage == "DOWN":

                        if average_angle < 120:

                            self.correction = (
                                "PRESS UP"
                            )

                        elif average_angle < 150:

                            self.correction = (
                                "EXTEND ARMS FULLY"
                            )

                        else:

                            self.correction = (
                                "KEEP PRESSING"
                            )

                    elif self.stage == "UP":

                        self.correction = (
                            "LOWER SLOWLY"
                        )

                    else:

                        self.correction = (
                            "START WITH ARMS BENT"
                        )

                    # =========================
                    # FORM SCORE
                    # =========================

                    correct_reps = max(
                        0,
                        self.reps - self.incorrect
                    )

                    form_score = (
                        self.tracker.get_form_score(
                            correct_reps,
                            self.incorrect
                        )
                    )

                    # =========================
                    # PIXEL POSITIONS
                    # =========================

                    h, w, _ = frame.shape

                    left_shoulder_px = (
                        int(left_shoulder[0] * w),
                        int(left_shoulder[1] * h)
                    )

                    left_elbow_px = (
                        int(left_elbow[0] * w),
                        int(left_elbow[1] * h)
                    )

                    left_wrist_px = (
                        int(left_wrist[0] * w),
                        int(left_wrist[1] * h)
                    )

                    right_shoulder_px = (
                        int(right_shoulder[0] * w),
                        int(right_shoulder[1] * h)
                    )

                    right_elbow_px = (
                        int(right_elbow[0] * w),
                        int(right_elbow[1] * h)
                    )

                    right_wrist_px = (
                        int(right_wrist[0] * w),
                        int(right_wrist[1] * h)
                    )

                    # =========================
                    # VISUAL CORRECTIONS
                    # =========================

                    if arms_uneven:

                        for start, end in [
                            (
                                left_shoulder_px,
                                left_elbow_px
                            ),
                            (
                                left_elbow_px,
                                left_wrist_px
                            ),
                            (
                                right_shoulder_px,
                                right_elbow_px
                            ),
                            (
                                right_elbow_px,
                                right_wrist_px
                            )
                        ]:

                            cv2.line(
                                frame,
                                start,
                                end,
                                (0, 0, 255),
                                7
                            )

                    elif self.correction in [
                        "PRESS UP",
                        "EXTEND ARMS FULLY",
                        "KEEP PRESSING"
                    ]:

                        cv2.arrowedLine(
                            frame,
                            (
                                left_wrist_px[0] - 30,
                                left_wrist_px[1] + 60
                            ),
                            (
                                left_wrist_px[0] - 30,
                                left_wrist_px[1] - 30
                            ),
                            (0, 165, 255),
                            5,
                            tipLength=0.25
                        )

                        cv2.arrowedLine(
                            frame,
                            (
                                right_wrist_px[0] + 30,
                                right_wrist_px[1] + 60
                            ),
                            (
                                right_wrist_px[0] + 30,
                                right_wrist_px[1] - 30
                            ),
                            (0, 165, 255),
                            5,
                            tipLength=0.25
                        )

                    elif self.correction == "LOWER SLOWLY":

                        cv2.arrowedLine(
                            frame,
                            (
                                left_wrist_px[0] - 30,
                                left_wrist_px[1] - 30
                            ),
                            (
                                left_wrist_px[0] - 30,
                                left_wrist_px[1] + 60
                            ),
                            (0, 255, 0),
                            5,
                            tipLength=0.25
                        )

                        cv2.arrowedLine(
                            frame,
                            (
                                right_wrist_px[0] + 30,
                                right_wrist_px[1] - 30
                            ),
                            (
                                right_wrist_px[0] + 30,
                                right_wrist_px[1] + 60
                            ),
                            (0, 255, 0),
                            5,
                            tipLength=0.25
                        )

                    # =========================
                    # ELBOW ANGLES
                    # =========================

                    cv2.putText(
                        frame,
                        str(int(left_angle)),
                        left_elbow_px,
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (255, 255, 255),
                        2
                    )

                    cv2.putText(
                        frame,
                        str(int(right_angle)),
                        right_elbow_px,
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (255, 255, 255),
                        2
                    )

                    # =========================
                    # INFORMATION PANEL
                    # =========================

                    cv2.rectangle(
                        frame,
                        (0, 0),
                        (720, 350),
                        (30, 30, 30),
                        -1
                    )

                    cv2.putText(
                        frame,
                        "AI GYM TRAINER - SHOULDER PRESS",
                        (20, 35),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (255, 255, 255),
                        2
                    )

                    cv2.putText(
                        frame,
                        "REPS: " + str(self.reps),
                        (20, 75),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        1,
                        (0, 255, 0),
                        2
                    )

                    cv2.putText(
                        frame,
                        "FORM ISSUES: " + str(self.incorrect),
                        (190, 75),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.65,
                        (0, 255, 255),
                        2
                    )

                    cv2.putText(
                        frame,
                        "FORM SCORE: "
                        + str(form_score)
                        + "%",
                        (20, 115),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.65,
                        (0, 255, 0),
                        2
                    )

                    cv2.putText(
                        frame,
                        "TIME: " + timer_text,
                        (350, 115),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.65,
                        (255, 255, 255),
                        2
                    )

                    cv2.putText(
                        frame,
                        "POSITION: " + str(self.stage),
                        (20, 155),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (255, 255, 0),
                        2
                    )

                    cv2.putText(
                        frame,
                        "MOVEMENT: " + self.feedback,
                        (20, 195),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.65,
                        (255, 255, 0),
                        2
                    )

                    cv2.putText(
                        frame,
                        "CORRECTION:",
                        (20, 235),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.65,
                        (255, 255, 255),
                        2
                    )

                    if arms_uneven:

                        correction_color = (
                            0, 0, 255
                        )

                    elif self.correction == "LOWER SLOWLY":

                        correction_color = (
                            0, 255, 0
                        )

                    else:

                        correction_color = (
                            0, 165, 255
                        )

                    cv2.putText(
                        frame,
                        self.correction,
                        (20, 275),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.75,
                        correction_color,
                        2
                    )

                    cv2.putText(
                        frame,
                        "LEFT: "
                        + str(int(left_angle))
                        + "   RIGHT: "
                        + str(int(right_angle))
                        + "   DIFFERENCE: "
                        + str(int(angle_difference)),
                        (20, 315),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.55,
                        (255, 255, 255),
                        1
                    )

                    cv2.putText(
                        frame,
                        "Click End Workout to finish",
                        (20, 340),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.5,
                        (255, 255, 255),
                        1
                    )

                else:

                    cv2.putText(
                        frame,
                        "KEEP BOTH ARMS VISIBLE",
                        (20, 50),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.8,
                        (0, 0, 255),
                        2
                    )

            else:

                cv2.putText(
                    frame,
                    "BODY NOT DETECTED",
                    (20, 50),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.8,
                    (0, 0, 255),
                    2
                )

            return frame

    # =========================
    # JPEG CAMERA STREAM
    # =========================

    def get_jpeg_frame(self):

        frame = self.process_frame()

        if frame is None:
            return None

        success, encoded = cv2.imencode(
            ".jpg",
            frame,
            [cv2.IMWRITE_JPEG_QUALITY, 85]
        )

        if not success:
            return None

        return encoded.tobytes()

    # =========================
    # LIVE STATISTICS
    # =========================

    def get_status(self):
        with self.lock:

            correct_reps = max(
                0,
                self.reps - self.incorrect
            )

            form_score = (
                self.tracker.get_form_score(
                    correct_reps,
                    self.incorrect
                )
                if self.tracker
                else 0
            )

            duration = (
                self.tracker.get_duration()
                if self.tracker
                else 0
            )

            return {
                "running": self.running,
                "exercise": "Shoulder Press",
                "reps": self.reps,
                "correct_reps": correct_reps,
                "form_issues": self.incorrect,
                "form_score": form_score,
                "duration": duration,
                "stage": self.stage,
                "movement": self.feedback,
                "correction": self.correction
            }

    # =========================
    # END WORKOUT
    # =========================

    def stop(self):
        with self.lock:

            if self.saved:
                return None

            if self.tracker is None:
                return None

            self.running = False

            if self.cap is not None:
                self.cap.release()
                self.cap = None

            if self.pose is not None:
                self.pose.close()
                self.pose = None

            correct_reps = max(
                0,
                self.reps - self.incorrect
            )

            workout = self.tracker.save_workout(
                correct_reps,
                self.incorrect
            )

            self.saved = True

            self.tracker.print_summary(workout)

            return workout