import cv2
import mediapipe as mp
import math
from collections import deque

from workout_tracker import WorkoutTracker


def calculate_angle(a, b, c):
    angle = math.degrees(
        math.atan2(c[1] - b[1], c[0] - b[0]) -
        math.atan2(a[1] - b[1], a[0] - b[0])
    )

    angle = abs(angle)

    if angle > 180:
        angle = 360 - angle

    return angle


# -------------------------
# CAMERA
# -------------------------

cap = cv2.VideoCapture(0)

mp_pose = mp.solutions.pose

pose = mp_pose.Pose(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

mp_draw = mp.solutions.drawing_utils


# -------------------------
# VARIABLES
# -------------------------

reps = 0
correct_reps = 0
bad_form_reps = 0

stage = None
reached_bottom = False
bad_form_during_rep = False

feedback = "GET INTO POSITION"
correction = "GET INTO POSITION"

tracker = WorkoutTracker("Push Up")


# -------------------------
# SMOOTHING
# -------------------------

elbow_history = deque(maxlen=5)
body_history = deque(maxlen=5)

correction_history = deque(maxlen=6)


def stable_correction(message):
    correction_history.append(message)

    if len(correction_history) < 4:
        return message

    return max(
        set(correction_history),
        key=correction_history.count
    )


# -------------------------
# MAIN LOOP
# -------------------------

while True:

    success, frame = cap.read()

    if not success:
        print("Could not access camera")
        break

    frame = cv2.flip(frame, 1)

    rgb = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )

    result = pose.process(rgb)


    # -------------------------
    # TIMER
    # -------------------------

    elapsed = tracker.get_duration()

    minutes = int(elapsed // 60)
    seconds = int(elapsed % 60)

    timer_text = f"{minutes:02d}:{seconds:02d}"


    if result.pose_landmarks:

        mp_draw.draw_landmarks(
            frame,
            result.pose_landmarks,
            mp_pose.POSE_CONNECTIONS
        )

        lm = result.pose_landmarks.landmark


        # -------------------------
        # LANDMARKS
        # -------------------------

        shoulder = [
            lm[mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,
            lm[mp_pose.PoseLandmark.LEFT_SHOULDER.value].y
        ]

        elbow = [
            lm[mp_pose.PoseLandmark.LEFT_ELBOW.value].x,
            lm[mp_pose.PoseLandmark.LEFT_ELBOW.value].y
        ]

        wrist = [
            lm[mp_pose.PoseLandmark.LEFT_WRIST.value].x,
            lm[mp_pose.PoseLandmark.LEFT_WRIST.value].y
        ]

        hip = [
            lm[mp_pose.PoseLandmark.LEFT_HIP.value].x,
            lm[mp_pose.PoseLandmark.LEFT_HIP.value].y
        ]

        knee = [
            lm[mp_pose.PoseLandmark.LEFT_KNEE.value].x,
            lm[mp_pose.PoseLandmark.LEFT_KNEE.value].y
        ]

        ankle = [
            lm[mp_pose.PoseLandmark.LEFT_ANKLE.value].x,
            lm[mp_pose.PoseLandmark.LEFT_ANKLE.value].y
        ]


        # -------------------------
        # VISIBILITY
        # -------------------------

        visible = (
            lm[mp_pose.PoseLandmark.LEFT_SHOULDER.value].visibility > 0.5
            and lm[mp_pose.PoseLandmark.LEFT_ELBOW.value].visibility > 0.5
            and lm[mp_pose.PoseLandmark.LEFT_WRIST.value].visibility > 0.5
            and lm[mp_pose.PoseLandmark.LEFT_HIP.value].visibility > 0.5
            and lm[mp_pose.PoseLandmark.LEFT_KNEE.value].visibility > 0.5
            and lm[mp_pose.PoseLandmark.LEFT_ANKLE.value].visibility > 0.5
        )


        if visible:

            # -------------------------
            # RAW ANGLES
            # -------------------------

            raw_elbow_angle = calculate_angle(
                shoulder,
                elbow,
                wrist
            )

            raw_body_angle = calculate_angle(
                shoulder,
                hip,
                ankle
            )


            # -------------------------
            # SMOOTH ANGLES
            # -------------------------

            elbow_history.append(raw_elbow_angle)
            body_history.append(raw_body_angle)

            elbow_angle = sum(elbow_history) / len(
                elbow_history
            )

            body_angle = sum(body_history) / len(
                body_history
            )


            # -------------------------
            # BODY ERROR DIRECTION
            # -------------------------

            # Distance of hip from the straight
            # shoulder-to-ankle line.

            sx, sy = shoulder
            hx, hy = hip
            ax, ay = ankle

            dx = ax - sx
            dy = ay - sy

            length_squared = dx * dx + dy * dy


            if length_squared > 0:

                t = (
                    ((hx - sx) * dx) +
                    ((hy - sy) * dy)
                ) / length_squared

                expected_hip_x = sx + t * dx
                expected_hip_y = sy + t * dy

                hip_offset = hy - expected_hip_y

            else:

                hip_offset = 0


            # -------------------------
            # REAL-TIME CORRECTION
            # -------------------------

            current_form_good = True


            # Hip significantly below line
            if hip_offset > 0.045:

                raw_correction = "RAISE YOUR HIPS"
                current_form_good = False


            # Hip significantly above line
            elif hip_offset < -0.045:

                raw_correction = "LOWER YOUR HIPS"
                current_form_good = False


            # At top but elbows not extended enough
            elif stage == "UP" and elbow_angle < 145:

                raw_correction = "EXTEND YOUR ARMS"
                current_form_good = False


            # Going down but not deep yet
            elif (
                stage == "UP"
                and elbow_angle > 105
                and elbow_angle < 155
            ):

                raw_correction = "LOWER YOUR CHEST"


            # Good bottom depth
            elif elbow_angle <= 95:

                raw_correction = "GOOD DEPTH - PUSH UP"


            else:

                raw_correction = "GOOD FORM"


            correction = stable_correction(
                raw_correction
            )


            # -------------------------
            # TRACK FORM DURING REP
            # -------------------------

            if stage in ["UP", "DOWN"]:

                if not current_form_good:
                    bad_form_during_rep = True


            # -------------------------
            # PUSH-UP REP LOGIC
            # -------------------------

            # TOP
            if elbow_angle >= 155:

                if stage == "DOWN":

                    if reached_bottom:

                        reps += 1

                        if bad_form_during_rep:

                            bad_form_reps += 1
                            feedback = "REP COMPLETED - FORM ISSUE"

                        else:

                            correct_reps += 1
                            feedback = "GOOD REP"

                        print(
                            "Total:",
                            reps,
                            "| Correct:",
                            correct_reps,
                            "| Form issues:",
                            bad_form_reps
                        )

                    else:

                        feedback = "INCOMPLETE REP"


                    reached_bottom = False
                    bad_form_during_rep = False

                else:

                    feedback = "READY"

                stage = "UP"


            # BOTTOM
            elif elbow_angle <= 95:

                if stage == "UP":
                    reached_bottom = True

                stage = "DOWN"

                feedback = "PUSH UP"


            # MIDDLE
            else:

                if stage == "UP":
                    feedback = "LOWERING"

                elif stage == "DOWN":
                    feedback = "PUSHING"

                else:
                    feedback = "START WITH ARMS STRAIGHT"


            # -------------------------
            # FORM SCORE
            # -------------------------

            form_score = tracker.get_form_score(
                correct_reps,
                bad_form_reps
            )


            # -------------------------
            # DISPLAY COORDINATES
            # -------------------------

            h, w, _ = frame.shape

            shoulder_px = (
                int(shoulder[0] * w),
                int(shoulder[1] * h)
            )

            hip_px = (
                int(hip[0] * w),
                int(hip[1] * h)
            )

            ankle_px = (
                int(ankle[0] * w),
                int(ankle[1] * h)
            )

            elbow_px = (
                int(elbow[0] * w),
                int(elbow[1] * h)
            )


            # -------------------------
            # VISUAL CORRECTION
            # -------------------------

            # Draw expected straight body line
            cv2.line(
                frame,
                shoulder_px,
                ankle_px,
                (255, 255, 255),
                2
            )


            # Highlight hip
            if correction in [
                "RAISE YOUR HIPS",
                "LOWER YOUR HIPS"
            ]:

                cv2.circle(
                    frame,
                    hip_px,
                    15,
                    (0, 0, 255),
                    -1
                )

                # Arrow showing correction direction
                if correction == "RAISE YOUR HIPS":

                    arrow_end = (
                        hip_px[0],
                        hip_px[1] - 80
                    )

                else:

                    arrow_end = (
                        hip_px[0],
                        hip_px[1] + 80
                    )


                cv2.arrowedLine(
                    frame,
                    hip_px,
                    arrow_end,
                    (0, 0, 255),
                    5,
                    tipLength=0.3
                )


            else:

                cv2.circle(
                    frame,
                    hip_px,
                    10,
                    (0, 255, 0),
                    -1
                )


            # Show elbow angle
            cv2.putText(
                frame,
                str(int(elbow_angle)),
                elbow_px,
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )


            # -------------------------
            # PANEL
            # -------------------------

            cv2.rectangle(
                frame,
                (0, 0),
                (680, 315),
                (30, 30, 30),
                -1
            )


            cv2.putText(
                frame,
                "AI GYM TRAINER - PUSH UP",
                (20, 35),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "REPS: " + str(reps),
                (20, 75),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.9,
                (0, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "CORRECT: " + str(correct_reps),
                (170, 75),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "FORM ISSUES: " + str(bad_form_reps),
                (360, 75),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "TIME: " + timer_text,
                (20, 115),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "FORM SCORE: " + str(form_score) + "%",
                (260, 115),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "MOVEMENT: " + feedback,
                (20, 155),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 0),
                2
            )


            # Correction shown prominently
            cv2.putText(
                frame,
                "CORRECTION:",
                (20, 205),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )


            if correction == "GOOD FORM":

                correction_color = (0, 255, 0)

            else:

                correction_color = (0, 165, 255)


            cv2.putText(
                frame,
                correction,
                (20, 245),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.85,
                correction_color,
                2
            )


            cv2.putText(
                frame,
                "ELBOW: " + str(int(elbow_angle)) +
                "  BODY: " + str(int(body_angle)),
                (20, 280),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "Press Q to finish",
                (20, 305),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (255, 255, 255),
                1
            )


        else:

            cv2.putText(
                frame,
                "KEEP FULL SIDE OF BODY VISIBLE",
                (20, 50),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 0, 255),
                2
            )


    else:

        cv2.putText(
            frame,
            "BODY NOT DETECTED",
            (20, 50),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 0, 255),
            2
        )


    cv2.imshow(
        "AI Gym Trainer - Push Up",
        frame
    )


    if cv2.waitKey(1) & 0xFF == ord("q"):
        break


# -------------------------
# FINISH WORKOUT
# -------------------------

cap.release()
pose.close()
cv2.destroyAllWindows()


workout = tracker.save_workout(
    correct_reps,
    bad_form_reps
)

tracker.print_summary(workout)