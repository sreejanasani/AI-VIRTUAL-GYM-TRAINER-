import cv2
import mediapipe as mp
import math
import time
import threading

from collections import deque
from workout_tracker import WorkoutTracker


def calculate_angle(a, b, c):
    angle = math.degrees(
        math.atan2(c[1] - b[1], c[0] - b[0])
        - math.atan2(a[1] - b[1], a[0] - b[0])
    )

    angle = abs(angle)

    if angle > 180:
        angle = 360 - angle

    return angle


def calculate_torso_angle(shoulder, hip):
    dx = shoulder[0] - hip[0]
    dy = hip[1] - shoulder[1]

    if dy <= 0:
        return 0

    return math.degrees(
        math.atan2(abs(dx), abs(dy))
    )


class DumbbellRowWorkout:

    def __init__(self):
        self.mp_pose = mp.solutions.pose
        self.mp_draw = mp.solutions.drawing_utils

        self.cap = None
        self.pose = None
        self.thread = None
        self.running = False

        self.lock = threading.Lock()
        self.frame = None

        self.reps = 0
        self.incorrect = 0

        self.stage = None
        self.feedback = "GET READY"
        self.correction = "LEAN FORWARD INTO ROW POSITION"

        self.reached_top = False
        self.bad_form_during_rep = False

        self.baseline_torso_angle = None
        self.setup_ready = False

        self.elbow_history = deque(maxlen=5)
        self.torso_history = deque(maxlen=7)

        self.elbow_angle = 0
        self.torso_angle = 0
        self.torso_change = 0

        self.tracker = None
        self.saved_result = None
        self.session_start = None
        self.session_end = None

    def start(self):
        if self.running:
            return True

        self.cap = cv2.VideoCapture(0)

        if not self.cap.isOpened():
            self.cap.release()
            self.cap = None
            return False

        try:
            self.pose = self.mp_pose.Pose(
                min_detection_confidence=0.5,
                min_tracking_confidence=0.5
            )
        except Exception:
            self.cap.release()
            self.cap = None
            raise

        self.tracker = WorkoutTracker("Dumbbell Row")
        self.session_start = time.time()
        self.session_end = None

        self.running = True

        self.thread = threading.Thread(
            target=self.process_frame,
            daemon=True
        )

        self.thread.start()

        return True

    def process_frame(self):
        try:
            while self.running:
                success, frame = self.cap.read()

                if not success:
                    self.feedback = "CAMERA ERROR"
                    self.correction = "CAMERA NOT AVAILABLE"
                    break

                frame = cv2.flip(frame, 1)

                rgb = cv2.cvtColor(
                    frame,
                    cv2.COLOR_BGR2RGB
                )

                result = self.pose.process(rgb)

                elapsed = self.tracker.get_duration()
                minutes = int(elapsed // 60)
                seconds = int(elapsed % 60)
                timer_text = f"{minutes:02d}:{seconds:02d}"

                if result.pose_landmarks:
                    self.mp_draw.draw_landmarks(
                        frame,
                        result.pose_landmarks,
                        self.mp_pose.POSE_CONNECTIONS
                    )

                    lm = result.pose_landmarks.landmark
                    landmarks = self.mp_pose.PoseLandmark

                    shoulder_lm = lm[
                        landmarks.LEFT_SHOULDER.value
                    ]

                    elbow_lm = lm[
                        landmarks.LEFT_ELBOW.value
                    ]

                    wrist_lm = lm[
                        landmarks.LEFT_WRIST.value
                    ]

                    hip_lm = lm[
                        landmarks.LEFT_HIP.value
                    ]

                    shoulder = [
                        shoulder_lm.x,
                        shoulder_lm.y
                    ]

                    elbow = [
                        elbow_lm.x,
                        elbow_lm.y
                    ]

                    wrist = [
                        wrist_lm.x,
                        wrist_lm.y
                    ]

                    hip = [
                        hip_lm.x,
                        hip_lm.y
                    ]

                    visible = all(
                        landmark.visibility > 0.5
                        for landmark in [
                            shoulder_lm,
                            elbow_lm,
                            wrist_lm,
                            hip_lm
                        ]
                    )

                    if visible:
                        raw_elbow_angle = calculate_angle(
                            shoulder,
                            elbow,
                            wrist
                        )

                        self.elbow_history.append(
                            raw_elbow_angle
                        )

                        self.elbow_angle = (
                            sum(self.elbow_history)
                            / len(self.elbow_history)
                        )

                        raw_torso_angle = calculate_torso_angle(
                            shoulder,
                            hip
                        )

                        self.torso_history.append(
                            raw_torso_angle
                        )

                        self.torso_angle = (
                            sum(self.torso_history)
                            / len(self.torso_history)
                        )

                        proper_row_setup = (
                            30 <= self.torso_angle <= 75
                        )

                        if (
                            proper_row_setup
                            and not self.setup_ready
                        ):
                            self.setup_ready = True

                            self.baseline_torso_angle = (
                                self.torso_angle
                            )

                            self.stage = None
                            self.reached_top = False

                            self.feedback = "ROW POSITION READY"
                            self.correction = "EXTEND ARM TO START"

                        if (
                            self.setup_ready
                            and self.torso_angle < 18
                        ):
                            self.setup_ready = False
                            self.baseline_torso_angle = None

                            self.stage = None
                            self.reached_top = False
                            self.bad_form_during_rep = False

                            self.feedback = (
                                "WAITING FOR ROW POSITION"
                            )

                            self.correction = (
                                "LEAN FORWARD INTO ROW POSITION"
                            )

                        torso_unstable = False
                        elbow_far_from_hip = False
                        self.torso_change = 0

                        if not self.setup_ready:
                            self.feedback = (
                                "WAITING FOR ROW POSITION"
                            )

                            self.correction = (
                                "LEAN FORWARD INTO ROW POSITION"
                            )

                        else:
                            self.torso_change = abs(
                                self.torso_angle
                                - self.baseline_torso_angle
                            )

                            torso_unstable = (
                                self.elbow_angle < 140
                                and self.torso_change > 18
                            )

                            elbow_to_hip_distance = math.sqrt(
                                (elbow[0] - hip[0]) ** 2
                                + (elbow[1] - hip[1]) ** 2
                            )

                            elbow_far_from_hip = (
                                self.elbow_angle < 110
                                and elbow_to_hip_distance > 0.32
                            )

                            if not proper_row_setup:
                                self.correction = (
                                    "RETURN TO ROW POSITION"
                                )

                                self.bad_form_during_rep = True

                            elif torso_unstable:
                                self.correction = (
                                    "KEEP TORSO STABLE"
                                )

                                self.bad_form_during_rep = True

                            elif elbow_far_from_hip:
                                self.correction = (
                                    "PULL ELBOW TOWARD HIP"
                                )

                                self.bad_form_during_rep = True

                            elif (
                                self.stage == "EXTENDED"
                                and self.elbow_angle > 120
                            ):
                                self.correction = (
                                    "PULL ELBOW BACK"
                                )

                            elif (
                                self.stage == "EXTENDED"
                                and self.elbow_angle >= 100
                            ):
                                self.correction = "PULL HIGHER"

                            elif self.stage == "PULLED":
                                self.correction = (
                                    "EXTEND ARM FULLY"
                                )

                            else:
                                self.correction = (
                                    "GOOD ROW POSITION"
                                )

                            if self.elbow_angle > 145:
                                if (
                                    self.stage == "PULLED"
                                    and self.reached_top
                                ):
                                    self.reps += 1

                                    if self.bad_form_during_rep:
                                        self.incorrect += 1
                                        self.feedback = (
                                            "REP COMPLETED - FORM ISSUE"
                                        )
                                    else:
                                        self.feedback = "GOOD REP"

                                    print(
                                        "Dumbbell Row:",
                                        self.reps
                                    )

                                else:
                                    self.feedback = "PULL"

                                self.stage = "EXTENDED"
                                self.reached_top = False
                                self.bad_form_during_rep = False

                                if proper_row_setup:
                                    self.baseline_torso_angle = (
                                        0.95
                                        * self.baseline_torso_angle
                                        + 0.05
                                        * self.torso_angle
                                    )

                            elif self.elbow_angle < 100:
                                if self.stage == "EXTENDED":
                                    self.stage = "PULLED"
                                    self.reached_top = True
                                    self.feedback = "GOOD PULL"

                                elif self.stage == "PULLED":
                                    self.feedback = "EXTEND SLOWLY"

                                else:
                                    self.feedback = (
                                        "EXTEND ARM FIRST"
                                    )

                            else:
                                if self.stage == "EXTENDED":
                                    self.feedback = "KEEP PULLING"

                                elif self.stage == "PULLED":
                                    self.feedback = "EXTEND ARM"

                                else:
                                    self.feedback = (
                                        "EXTEND ARM FIRST"
                                    )

                        h, w, _ = frame.shape

                        shoulder_px = (
                            int(shoulder[0] * w),
                            int(shoulder[1] * h)
                        )

                        elbow_px = (
                            int(elbow[0] * w),
                            int(elbow[1] * h)
                        )

                        hip_px = (
                            int(hip[0] * w),
                            int(hip[1] * h)
                        )

                        if (
                            not self.setup_ready
                            or not proper_row_setup
                            or torso_unstable
                        ):
                            torso_color = (0, 0, 255)
                        else:
                            torso_color = (0, 255, 0)

                        cv2.line(
                            frame,
                            shoulder_px,
                            hip_px,
                            torso_color,
                            7
                        )

                        if not self.setup_ready:
                            cv2.arrowedLine(
                                frame,
                                shoulder_px,
                                (
                                    shoulder_px[0] + 80,
                                    shoulder_px[1] + 50
                                ),
                                (0, 0, 255),
                                5,
                                tipLength=0.25
                            )

                        elif elbow_far_from_hip:
                            cv2.circle(
                                frame,
                                elbow_px,
                                14,
                                (0, 0, 255),
                                -1
                            )

                            cv2.arrowedLine(
                                frame,
                                elbow_px,
                                hip_px,
                                (0, 0, 255),
                                5,
                                tipLength=0.20
                            )

                        elif self.stage == "EXTENDED":
                            target = (
                                int(
                                    (elbow[0] + hip[0])
                                    / 2 * w
                                ),
                                int(
                                    (elbow[1] + hip[1])
                                    / 2 * h
                                )
                            )

                            cv2.arrowedLine(
                                frame,
                                elbow_px,
                                target,
                                (0, 165, 255),
                                5,
                                tipLength=0.25
                            )

                        cv2.putText(
                            frame,
                            str(int(self.elbow_angle)),
                            elbow_px,
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.7,
                            (255, 255, 255),
                            2
                        )

                    else:
                        self.feedback = "BODY NOT VISIBLE"
                        self.correction = (
                            "KEEP LEFT SIDE VISIBLE"
                        )

                        self.elbow_history.clear()
                        self.torso_history.clear()

                else:
                    self.feedback = "BODY NOT DETECTED"
                    self.correction = "BODY NOT DETECTED"

                    self.elbow_history.clear()
                    self.torso_history.clear()

                correct_reps = max(
                    0,
                    self.reps - self.incorrect
                )

                form_score = self.tracker.get_form_score(
                    correct_reps,
                    self.incorrect
                )

                panel_width = min(
                    frame.shape[1],
                    800
                )

                cv2.rectangle(
                    frame,
                    (0, 0),
                    (panel_width, 430),
                    (30, 30, 30),
                    -1
                )

                def draw_text(text, y, color=(255, 255, 255), scale=0.6):
                    cv2.putText(
                        frame,
                        text,
                        (20, y),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        scale,
                        color,
                        2
                    )

                draw_text(
                    "AI GYM TRAINER - DUMBBELL ROW",
                    35,
                    scale=0.7
                )

                draw_text(
                    f"REPS: {self.reps}",
                    80,
                    (0, 255, 0),
                    0.9
                )

                draw_text(
                    f"FORM ISSUES: {self.incorrect}",
                    120,
                    (0, 255, 255)
                )

                draw_text(
                    f"FORM SCORE: {form_score}%",
                    160,
                    (0, 255, 0)
                )

                draw_text(
                    f"TIME: {timer_text}",
                    200
                )

                setup_text = (
                    "READY - ROW POSITION"
                    if self.setup_ready
                    else "NOT READY - LEAN FORWARD"
                )

                draw_text(
                    f"SETUP: {setup_text}",
                    240,
                    (
                        (0, 255, 0)
                        if self.setup_ready
                        else (0, 0, 255)
                    )
                )

                draw_text(
                    f"MOVEMENT: {self.feedback}",
                    280,
                    (255, 255, 0)
                )

                correction_color = (
                    (0, 255, 0)
                    if self.correction == "GOOD ROW POSITION"
                    else (0, 165, 255)
                )

                if self.correction in [
                    "LEAN FORWARD INTO ROW POSITION",
                    "RETURN TO ROW POSITION",
                    "KEEP TORSO STABLE",
                    "PULL ELBOW TOWARD HIP"
                ]:
                    correction_color = (0, 0, 255)

                draw_text(
                    f"CORRECTION: {self.correction}",
                    320,
                    correction_color,
                    0.55
                )

                draw_text(
                    (
                        f"ELBOW: {int(self.elbow_angle)}"
                        f"  TORSO: {int(self.torso_angle)}"
                    ),
                    360
                )

                draw_text(
                    "REP TARGET: >145 -> <100 -> >145",
                    395,
                    scale=0.55
                )

                with self.lock:
                    self.frame = frame.copy()

        except Exception as error:
            print("Dumbbell Row camera error:", error)
            self.feedback = "CAMERA ERROR"
            self.correction = str(error)

        finally:
            self.running = False

            if self.cap is not None:
                self.cap.release()
                self.cap = None

            if self.pose is not None:
                self.pose.close()
                self.pose = None

    def get_jpeg_frame(self):
        with self.lock:
            if self.frame is None:
                return None

            frame = self.frame.copy()

        success, buffer = cv2.imencode(
            ".jpg",
            frame
        )

        if not success:
            return None

        return buffer.tobytes()

    def get_status(self):
        correct_reps = max(
            0,
            self.reps - self.incorrect
        )

        if self.tracker is not None:
            duration = self.tracker.get_duration()

            form_score = self.tracker.get_form_score(
                correct_reps,
                self.incorrect
            )
        else:
            duration = 0
            form_score = 0

        return {
            "running": self.running,
            "exercise": "Dumbbell Row",
            "reps": self.reps,
            "correct_reps": correct_reps,
            "incorrect_reps": self.incorrect,
            "form_issues": self.incorrect,
            "form_score": form_score,
            "duration": round(duration, 2),
            "correction": self.correction,
            "movement": self.feedback,
            "stage": self.stage,
            "setup_ready": self.setup_ready,
            "elbow_angle": round(self.elbow_angle, 1),
            "torso_angle": round(self.torso_angle, 1)
        }

    def stop(self):
        if self.saved_result is not None:
            return self.saved_result

        self.running = False

        if self.thread is not None and self.thread.is_alive():
            self.thread.join(timeout=5)

            if self.thread.is_alive():
                raise RuntimeError(
                    "Camera is still processing. Please try again."
                )

        self.session_end = time.time()

        correct_reps = max(
            0,
            self.reps - self.incorrect
        )

        workout = self.tracker.save_workout(
            correct_reps,
            self.incorrect
        )

        self.tracker.print_summary(workout)

        self.saved_result = {
            "success": True,
            "exercise": "Dumbbell Row",
            "total_reps": self.reps,
            "correct_reps": correct_reps,
            "incorrect_reps": self.incorrect,
            "workout": workout
        }

        return self.saved_result