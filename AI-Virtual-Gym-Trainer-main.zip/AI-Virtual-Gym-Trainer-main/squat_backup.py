import cv2
import mediapipe as mp
import math
from collections import deque

from workout_tracker import WorkoutTracker


def calculate_angle(a, b, c):
    angle = math.degrees(
        math.atan2(c[1] - b[1], c[0] - b[0]) -
        math.atan2(a[1] - b[1], a[0] - b[0])
    )

    angle = abs(angle)

    if angle > 180:
        angle = 360 - angle

    return angle


# -------------------------
# CAMERA
# -------------------------

cap = cv2.VideoCapture(0)

mp_pose = mp.solutions.pose

pose = mp_pose.Pose(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

mp_draw = mp.solutions.drawing_utils


# -------------------------
# SESSION VARIABLES
# -------------------------

reps = 0
incomplete = 0

stage = None
feedback = "GET READY"
correction = "GET READY"

reached_depth = False

tracker = WorkoutTracker("Squat")


# -------------------------
# SMOOTHING
# -------------------------

knee_history = deque(maxlen=5)
torso_history = deque(maxlen=5)
correction_history = deque(maxlen=6)


def stable_correction(message):
    correction_history.append(message)

    if len(correction_history) < 4:
        return message

    return max(
        set(correction_history),
        key=correction_history.count
    )


# -------------------------
# MAIN LOOP
# -------------------------

while True:

    success, frame = cap.read()

    if not success:
        print("Could not access camera")
        break

    frame = cv2.flip(frame, 1)

    rgb = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )

    result = pose.process(rgb)


    # -------------------------
    # TIMER
    # -------------------------

    elapsed = tracker.get_duration()

    minutes = int(elapsed // 60)
    seconds = int(elapsed % 60)

    timer_text = f"{minutes:02d}:{seconds:02d}"


    if result.pose_landmarks:

        mp_draw.draw_landmarks(
            frame,
            result.pose_landmarks,
            mp_pose.POSE_CONNECTIONS
        )

        lm = result.pose_landmarks.landmark


        # -------------------------
        # LANDMARKS
        # -------------------------

        shoulder = [
            lm[mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,
            lm[mp_pose.PoseLandmark.LEFT_SHOULDER.value].y
        ]

        hip = [
            lm[mp_pose.PoseLandmark.LEFT_HIP.value].x,
            lm[mp_pose.PoseLandmark.LEFT_HIP.value].y
        ]

        knee = [
            lm[mp_pose.PoseLandmark.LEFT_KNEE.value].x,
            lm[mp_pose.PoseLandmark.LEFT_KNEE.value].y
        ]

        ankle = [
            lm[mp_pose.PoseLandmark.LEFT_ANKLE.value].x,
            lm[mp_pose.PoseLandmark.LEFT_ANKLE.value].y
        ]


        # -------------------------
        # VISIBILITY
        # -------------------------

        visible = (
            lm[mp_pose.PoseLandmark.LEFT_SHOULDER.value].visibility > 0.5
            and lm[mp_pose.PoseLandmark.LEFT_HIP.value].visibility > 0.5
            and lm[mp_pose.PoseLandmark.LEFT_KNEE.value].visibility > 0.5
            and lm[mp_pose.PoseLandmark.LEFT_ANKLE.value].visibility > 0.5
        )


        if visible:

            # -------------------------
            # ANGLES
            # -------------------------

            raw_knee_angle = calculate_angle(
                hip,
                knee,
                ankle
            )


            # Virtual point directly above hip.
            # This lets us estimate torso lean
            # relative to vertical.
            vertical_point = [
                hip[0],
                hip[1] - 0.3
            ]

            raw_torso_angle = calculate_angle(
                shoulder,
                hip,
                vertical_point
            )


            # -------------------------
            # SMOOTH ANGLES
            # -------------------------

            knee_history.append(raw_knee_angle)
            torso_history.append(raw_torso_angle)

            knee_angle = sum(knee_history) / len(
                knee_history
            )

            torso_angle = sum(torso_history) / len(
                torso_history
            )


            # -------------------------
            # SQUAT REP LOGIC
            # -------------------------

            if knee_angle > 160:

                if stage == "DOWN":

                    if reached_depth:

                        reps += 1
                        feedback = "GOOD REP"

                        print(
                            "Completed squat:",
                            reps
                        )

                    else:

                        incomplete += 1
                        feedback = "INCOMPLETE REP"

                        print(
                            "Incomplete attempt:",
                            incomplete
                        )

                else:

                    feedback = "READY"

                stage = "UP"
                reached_depth = False


            else:

                if stage == "UP":
                    stage = "DOWN"


                if knee_angle < 100:

                    reached_depth = True
                    feedback = "GOOD DEPTH"

                elif knee_angle < 130:

                    feedback = "ALMOST THERE"

                else:

                    feedback = "SQUATTING"


            # -------------------------
            # REAL-TIME CORRECTION
            # -------------------------

            # Standing
            if knee_angle > 160:

                raw_correction = "READY - START SQUAT"


            # Excessive forward torso lean
            elif torso_angle > 50:

                raw_correction = "KEEP CHEST UP"


            # Beginning / shallow squat
            elif knee_angle >= 130:

                raw_correction = "GO LOWER"


            # Close to required depth
            elif knee_angle >= 100:

                raw_correction = "A LITTLE LOWER"


            # Good depth
            elif knee_angle >= 75:

                raw_correction = "GOOD DEPTH - STAND UP"


            # Very deep squat
            else:

                raw_correction = "STAND UP"


            correction = stable_correction(
                raw_correction
            )


            # -------------------------
            # FORM SCORE
            # -------------------------

            form_score = tracker.get_form_score(
                reps,
                incomplete
            )


            # -------------------------
            # DISPLAY COORDINATES
            # -------------------------

            h, w, _ = frame.shape

            shoulder_px = (
                int(shoulder[0] * w),
                int(shoulder[1] * h)
            )

            hip_px = (
                int(hip[0] * w),
                int(hip[1] * h)
            )

            knee_px = (
                int(knee[0] * w),
                int(knee[1] * h)
            )

            ankle_px = (
                int(ankle[0] * w),
                int(ankle[1] * h)
            )


            # -------------------------
            # VISUAL CORRECTION
            # -------------------------

            # Highlight knee for depth correction
            if correction in [
                "GO LOWER",
                "A LITTLE LOWER"
            ]:

                cv2.circle(
                    frame,
                    knee_px,
                    15,
                    (0, 165, 255),
                    -1
                )

                # Downward arrow near hip
                arrow_start = (
                    hip_px[0] + 40,
                    hip_px[1]
                )

                arrow_end = (
                    hip_px[0] + 40,
                    hip_px[1] + 80
                )

                cv2.arrowedLine(
                    frame,
                    arrow_start,
                    arrow_end,
                    (0, 165, 255),
                    5,
                    tipLength=0.3
                )


            # Highlight torso when leaning too much
            elif correction == "KEEP CHEST UP":

                cv2.line(
                    frame,
                    shoulder_px,
                    hip_px,
                    (0, 0, 255),
                    6
                )

                arrow_start = shoulder_px

                arrow_end = (
                    shoulder_px[0],
                    shoulder_px[1] - 80
                )

                cv2.arrowedLine(
                    frame,
                    arrow_start,
                    arrow_end,
                    (0, 0, 255),
                    5,
                    tipLength=0.3
                )


            # Up arrow when squat is deep enough
            elif correction in [
                "GOOD DEPTH - STAND UP",
                "STAND UP"
            ]:

                cv2.circle(
                    frame,
                    hip_px,
                    12,
                    (0, 255, 0),
                    -1
                )

                arrow_start = (
                    hip_px[0] + 40,
                    hip_px[1]
                )

                arrow_end = (
                    hip_px[0] + 40,
                    hip_px[1] - 80
                )

                cv2.arrowedLine(
                    frame,
                    arrow_start,
                    arrow_end,
                    (0, 255, 0),
                    5,
                    tipLength=0.3
                )


            # -------------------------
            # ANGLE DISPLAY
            # -------------------------

            cv2.putText(
                frame,
                str(int(knee_angle)),
                knee_px,
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (255, 255, 255),
                2
            )


            # -------------------------
            # INFORMATION PANEL
            # -------------------------

            cv2.rectangle(
                frame,
                (0, 0),
                (680, 330),
                (30, 30, 30),
                -1
            )


            cv2.putText(
                frame,
                "AI GYM TRAINER - SQUAT",
                (20, 35),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "REPS: " + str(reps),
                (20, 75),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (0, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "INCOMPLETE: " + str(incomplete),
                (200, 75),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "FORM SCORE: " + str(form_score) + "%",
                (20, 115),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "TIME: " + timer_text,
                (350, 115),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "POSITION: " + str(stage),
                (20, 155),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "MOVEMENT: " + feedback,
                (20, 195),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "CORRECTION:",
                (20, 235),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )


            if correction in [
                "READY - START SQUAT",
                "GOOD DEPTH - STAND UP"
            ]:

                correction_color = (0, 255, 0)

            else:

                correction_color = (0, 165, 255)


            cv2.putText(
                frame,
                correction,
                (20, 275),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                correction_color,
                2
            )


            cv2.putText(
                frame,
                "KNEE: " + str(int(knee_angle)) +
                "  TORSO LEAN: " +
                str(int(torso_angle)),
                (20, 305),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "Press Q to finish",
                (20, 325),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.45,
                (255, 255, 255),
                1
            )


        else:

            cv2.putText(
                frame,
                "KEEP FULL SIDE OF BODY VISIBLE",
                (20, 50),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 0, 255),
                2
            )


    else:

        cv2.putText(
            frame,
            "BODY NOT DETECTED",
            (20, 50),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 0, 255),
            2
        )


    cv2.imshow(
        "AI Gym Trainer - Squat",
        frame
    )


    if cv2.waitKey(1) & 0xFF == ord("q"):
        break


# -------------------------
# FINISH WORKOUT
# -------------------------

cap.release()
pose.close()
cv2.destroyAllWindows()


workout = tracker.save_workout(
    reps,
    incomplete
)

tracker.print_summary(workout)