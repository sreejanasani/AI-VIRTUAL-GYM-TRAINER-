import cv2
import mediapipe as mp
import math
import time
from collections import deque

from workout_tracker import WorkoutTracker


def calculate_angle(a, b, c):
    angle = math.degrees(
        math.atan2(c[1] - b[1], c[0] - b[0]) -
        math.atan2(a[1] - b[1], a[0] - b[0])
    )

    angle = abs(angle)

    if angle > 180:
        angle = 360 - angle

    return angle


def distance(a, b):
    return math.sqrt(
        (a[0] - b[0]) ** 2 +
        (a[1] - b[1]) ** 2
    )


cap = cv2.VideoCapture(0)

mp_pose = mp.solutions.pose

pose = mp_pose.Pose(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

mp_draw = mp.solutions.drawing_utils


# -------------------------
# VARIABLES
# -------------------------

reps = 0
incorrect = 0

stage = None
reached_top = False

feedback = "GET READY"
correction = "ARMS DOWN TO START"

bad_form_during_rep = False

tracker = WorkoutTracker("Lateral Raise")


# -------------------------
# SMOOTHING
# -------------------------

left_shoulder_history = deque(maxlen=5)
right_shoulder_history = deque(maxlen=5)

left_elbow_history = deque(maxlen=5)
right_elbow_history = deque(maxlen=5)

torso_history = deque(maxlen=5)


# -------------------------
# TORSO REFERENCE
# -------------------------

baseline_torso_x = None


# -------------------------
# LOWERING SPEED
# -------------------------

previous_avg_angle = None
previous_time = time.time()


while True:

    success, frame = cap.read()

    if not success:
        print("Could not access camera")
        break

    frame = cv2.flip(frame, 1)

    rgb = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )

    result = pose.process(rgb)


    # -------------------------
    # TIMER
    # -------------------------

    elapsed = tracker.get_duration()

    minutes = int(elapsed // 60)
    seconds = int(elapsed % 60)

    timer_text = f"{minutes:02d}:{seconds:02d}"


    if result.pose_landmarks:

        mp_draw.draw_landmarks(
            frame,
            result.pose_landmarks,
            mp_pose.POSE_CONNECTIONS
        )

        lm = result.pose_landmarks.landmark


        # -------------------------
        # LANDMARKS
        # -------------------------

        left_ear = [
            lm[mp_pose.PoseLandmark.LEFT_EAR.value].x,
            lm[mp_pose.PoseLandmark.LEFT_EAR.value].y
        ]

        right_ear = [
            lm[mp_pose.PoseLandmark.RIGHT_EAR.value].x,
            lm[mp_pose.PoseLandmark.RIGHT_EAR.value].y
        ]

        left_shoulder = [
            lm[mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,
            lm[mp_pose.PoseLandmark.LEFT_SHOULDER.value].y
        ]

        right_shoulder = [
            lm[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].x,
            lm[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].y
        ]

        left_elbow = [
            lm[mp_pose.PoseLandmark.LEFT_ELBOW.value].x,
            lm[mp_pose.PoseLandmark.LEFT_ELBOW.value].y
        ]

        right_elbow = [
            lm[mp_pose.PoseLandmark.RIGHT_ELBOW.value].x,
            lm[mp_pose.PoseLandmark.RIGHT_ELBOW.value].y
        ]

        left_wrist = [
            lm[mp_pose.PoseLandmark.LEFT_WRIST.value].x,
            lm[mp_pose.PoseLandmark.LEFT_WRIST.value].y
        ]

        right_wrist = [
            lm[mp_pose.PoseLandmark.RIGHT_WRIST.value].x,
            lm[mp_pose.PoseLandmark.RIGHT_WRIST.value].y
        ]

        left_hip = [
            lm[mp_pose.PoseLandmark.LEFT_HIP.value].x,
            lm[mp_pose.PoseLandmark.LEFT_HIP.value].y
        ]

        right_hip = [
            lm[mp_pose.PoseLandmark.RIGHT_HIP.value].x,
            lm[mp_pose.PoseLandmark.RIGHT_HIP.value].y
        ]

        left_knee = [
            lm[mp_pose.PoseLandmark.LEFT_KNEE.value].x,
            lm[mp_pose.PoseLandmark.LEFT_KNEE.value].y
        ]

        right_knee = [
            lm[mp_pose.PoseLandmark.RIGHT_KNEE.value].x,
            lm[mp_pose.PoseLandmark.RIGHT_KNEE.value].y
        ]


        # -------------------------
        # VISIBILITY
        # -------------------------

        visible = (
            lm[mp_pose.PoseLandmark.LEFT_SHOULDER.value].visibility > 0.5
            and
            lm[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].visibility > 0.5
            and
            lm[mp_pose.PoseLandmark.LEFT_ELBOW.value].visibility > 0.5
            and
            lm[mp_pose.PoseLandmark.RIGHT_ELBOW.value].visibility > 0.5
            and
            lm[mp_pose.PoseLandmark.LEFT_WRIST.value].visibility > 0.5
            and
            lm[mp_pose.PoseLandmark.RIGHT_WRIST.value].visibility > 0.5
            and
            lm[mp_pose.PoseLandmark.LEFT_HIP.value].visibility > 0.5
            and
            lm[mp_pose.PoseLandmark.RIGHT_HIP.value].visibility > 0.5
        )


        if visible:

            # =========================
            # SHOULDER ANGLES
            # =========================

            raw_left_shoulder = calculate_angle(
                left_hip,
                left_shoulder,
                left_elbow
            )

            raw_right_shoulder = calculate_angle(
                right_hip,
                right_shoulder,
                right_elbow
            )


            left_shoulder_history.append(
                raw_left_shoulder
            )

            right_shoulder_history.append(
                raw_right_shoulder
            )


            left_angle = (
                sum(left_shoulder_history) /
                len(left_shoulder_history)
            )

            right_angle = (
                sum(right_shoulder_history) /
                len(right_shoulder_history)
            )


            average_angle = (
                left_angle +
                right_angle
            ) / 2


            # =========================
            # ELBOW BEND
            # =========================

            raw_left_elbow = calculate_angle(
                left_shoulder,
                left_elbow,
                left_wrist
            )

            raw_right_elbow = calculate_angle(
                right_shoulder,
                right_elbow,
                right_wrist
            )


            left_elbow_history.append(
                raw_left_elbow
            )

            right_elbow_history.append(
                raw_right_elbow
            )


            left_elbow_angle = (
                sum(left_elbow_history) /
                len(left_elbow_history)
            )

            right_elbow_angle = (
                sum(right_elbow_history) /
                len(right_elbow_history)
            )


            # =========================
            # LEFT / RIGHT BALANCE
            # =========================

            arm_difference = abs(
                left_angle -
                right_angle
            )

            arms_uneven = (
                average_angle > 35
                and
                arm_difference > 15
            )


            # =========================
            # ELBOW FORM
            # =========================
            #
            # Lateral raise should have
            # a slight elbow bend.
            #
            # Too straight: >178
            # Too bent: <140
            # =========================

            elbows_too_straight = (
                average_angle > 30
                and
                left_elbow_angle > 178
                and
                right_elbow_angle > 178
            )

            elbows_too_bent = (
                average_angle > 30
                and
                (
                    left_elbow_angle < 140
                    or
                    right_elbow_angle < 140
                )
            )


            # =========================
            # TORSO POSITION
            # =========================

            shoulder_center_x = (
                left_shoulder[0] +
                right_shoulder[0]
            ) / 2

            hip_center_x = (
                left_hip[0] +
                right_hip[0]
            ) / 2

            torso_x = (
                shoulder_center_x -
                hip_center_x
            )


            torso_history.append(
                torso_x
            )

            smooth_torso_x = (
                sum(torso_history) /
                len(torso_history)
            )


            # Learn upright reference
            # when arms are down.

            if average_angle < 25:

                if baseline_torso_x is None:

                    baseline_torso_x = (
                        smooth_torso_x
                    )

                else:

                    baseline_torso_x = (
                        0.95 *
                        baseline_torso_x
                        +
                        0.05 *
                        smooth_torso_x
                    )


            if baseline_torso_x is not None:

                torso_change = abs(
                    smooth_torso_x -
                    baseline_torso_x
                )

            else:

                torso_change = 0


            torso_swing = (
                average_angle > 30
                and
                torso_change > 0.055
            )


            # =========================
            # SHOULDER SHRUG
            # =========================
            #
            # Approximation:
            # shoulder-to-ear distance
            # becomes unusually small.
            #
            # =========================

            left_ear_distance = distance(
                left_ear,
                left_shoulder
            )

            right_ear_distance = distance(
                right_ear,
                right_shoulder
            )

            average_ear_distance = (
                left_ear_distance +
                right_ear_distance
            ) / 2


            shrugging = (
                average_angle > 55
                and
                average_ear_distance < 0.105
            )


            # =========================
            # TOP HEIGHT
            # =========================

            too_high = (
                average_angle > 105
            )


            good_top = (
                75 <= average_angle <= 100
            )


            # =========================
            # LOWERING SPEED
            # =========================

            current_time = time.time()

            dt = (
                current_time -
                previous_time
            )

            if (
                previous_avg_angle is not None
                and
                dt > 0
            ):

                angle_speed = abs(
                    average_angle -
                    previous_avg_angle
                ) / dt

            else:

                angle_speed = 0


            lowering_too_fast = (
                stage == "UP"
                and
                average_angle < 70
                and
                angle_speed > 160
            )


            previous_avg_angle = average_angle
            previous_time = current_time


            # =========================
            # FORM CORRECTION
            # =========================

            if arms_uneven:

                correction = (
                    "KEEP ARMS EVEN"
                )

                bad_form_during_rep = True


            elif torso_swing:

                correction = (
                    "KEEP TORSO STABLE"
                )

                bad_form_during_rep = True


            elif shrugging:

                correction = (
                    "KEEP SHOULDERS DOWN"
                )

                bad_form_during_rep = True


            elif elbows_too_bent:

                correction = (
                    "LESS ELBOW BEND"
                )

                bad_form_during_rep = True


            elif elbows_too_straight:

                correction = (
                    "KEEP SLIGHT ELBOW BEND"
                )

                bad_form_during_rep = True


            elif too_high:

                correction = (
                    "DO NOT RAISE TOO HIGH"
                )

                bad_form_during_rep = True


            elif lowering_too_fast:

                correction = (
                    "LOWER MORE SLOWLY"
                )

                bad_form_during_rep = True


            elif (
                stage == "DOWN"
                and
                average_angle < 65
            ):

                correction = (
                    "RAISE ARMS HIGHER"
                )


            elif good_top:

                correction = (
                    "GOOD HEIGHT - LOWER SLOWLY"
                )


            elif stage == "UP":

                correction = (
                    "LOWER SLOWLY"
                )


            else:

                correction = (
                    "GOOD FORM"
                )


            # =========================
            # REP COUNTING
            # =========================
            #
            # Preserve working logic:
            #
            # DOWN <25
            # TOP >=75
            # DOWN <25
            # = 1 rep
            # =========================


            # -------------------------
            # ARMS DOWN
            # -------------------------

            if average_angle < 25:

                if (
                    stage == "UP"
                    and
                    reached_top
                ):

                    reps += 1


                    if bad_form_during_rep:

                        incorrect += 1

                        feedback = (
                            "REP COMPLETED - FORM ISSUE"
                        )

                    else:

                        feedback = "GOOD REP"


                    print(
                        "Lateral Raise:",
                        reps
                    )


                else:

                    feedback = (
                        "RAISE ARMS"
                    )


                stage = "DOWN"

                reached_top = False

                bad_form_during_rep = False


            # -------------------------
            # TOP
            # -------------------------

            elif average_angle >= 75:

                if stage == "DOWN":

                    stage = "UP"

                    reached_top = True

                    if too_high:

                        feedback = (
                            "TOO HIGH - LOWER"
                        )

                    else:

                        feedback = (
                            "GOOD HEIGHT"
                        )


                elif stage == "UP":

                    feedback = (
                        "LOWER ARMS"
                    )


            # -------------------------
            # MIDDLE
            # -------------------------

            else:

                if stage == "DOWN":

                    feedback = (
                        "KEEP RAISING"
                    )


                elif stage == "UP":

                    feedback = (
                        "LOWER SLOWLY"
                    )


                else:

                    feedback = (
                        "LOWER ARMS FIRST"
                    )


            # =========================
            # FORM SCORE
            # =========================

            correct_reps = (
                reps -
                incorrect
            )

            if correct_reps < 0:
                correct_reps = 0


            form_score = (
                tracker.get_form_score(
                    correct_reps,
                    incorrect
                )
            )


            # =========================
            # PIXEL POSITIONS
            # =========================

            h, w, _ = frame.shape


            left_shoulder_px = (
                int(left_shoulder[0] * w),
                int(left_shoulder[1] * h)
            )

            right_shoulder_px = (
                int(right_shoulder[0] * w),
                int(right_shoulder[1] * h)
            )

            left_elbow_px = (
                int(left_elbow[0] * w),
                int(left_elbow[1] * h)
            )

            right_elbow_px = (
                int(right_elbow[0] * w),
                int(right_elbow[1] * h)
            )

            left_wrist_px = (
                int(left_wrist[0] * w),
                int(left_wrist[1] * h)
            )

            right_wrist_px = (
                int(right_wrist[0] * w),
                int(right_wrist[1] * h)
            )


            # =========================
            # ARM COLORS
            # =========================

            if (
                arms_uneven
                or
                too_high
                or
                elbows_too_bent
                or
                elbows_too_straight
            ):

                arm_color = (
                    0,
                    0,
                    255
                )

            else:

                arm_color = (
                    0,
                    255,
                    0
                )


            cv2.line(
                frame,
                left_shoulder_px,
                left_elbow_px,
                arm_color,
                6
            )

            cv2.line(
                frame,
                left_elbow_px,
                left_wrist_px,
                arm_color,
                6
            )

            cv2.line(
                frame,
                right_shoulder_px,
                right_elbow_px,
                arm_color,
                6
            )

            cv2.line(
                frame,
                right_elbow_px,
                right_wrist_px,
                arm_color,
                6
            )


            # =========================
            # VISUAL ARROWS
            # =========================

            if (
                stage == "DOWN"
                and
                average_angle < 65
            ):

                cv2.arrowedLine(
                    frame,
                    left_elbow_px,
                    (
                        left_elbow_px[0] - 70,
                        left_elbow_px[1] - 50
                    ),
                    (0, 165, 255),
                    5,
                    tipLength=0.25
                )

                cv2.arrowedLine(
                    frame,
                    right_elbow_px,
                    (
                        right_elbow_px[0] + 70,
                        right_elbow_px[1] - 50
                    ),
                    (0, 165, 255),
                    5,
                    tipLength=0.25
                )


            elif too_high:

                cv2.arrowedLine(
                    frame,
                    left_elbow_px,
                    (
                        left_elbow_px[0],
                        left_elbow_px[1] + 70
                    ),
                    (0, 0, 255),
                    5,
                    tipLength=0.25
                )

                cv2.arrowedLine(
                    frame,
                    right_elbow_px,
                    (
                        right_elbow_px[0],
                        right_elbow_px[1] + 70
                    ),
                    (0, 0, 255),
                    5,
                    tipLength=0.25
                )


            # =========================
            # PANEL
            # =========================

            cv2.rectangle(
                frame,
                (0, 0),
                (850, 470),
                (30, 30, 30),
                -1
            )


            cv2.putText(
                frame,
                "AI GYM TRAINER - LATERAL RAISE",
                (20, 35),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "REPS: " +
                str(reps),
                (20, 80),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (0, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "FORM ISSUES: " +
                str(incorrect),
                (190, 80),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "FORM SCORE: " +
                str(form_score) +
                "%",
                (20, 120),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "TIME: " +
                timer_text,
                (350, 120),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "POSITION: " +
                str(stage),
                (20, 160),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "MOVEMENT: " +
                feedback,
                (20, 200),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 0),
                2
            )


            # -------------------------
            # CORRECTION COLOR
            # -------------------------

            form_problem = (
                arms_uneven
                or
                torso_swing
                or
                shrugging
                or
                elbows_too_bent
                or
                elbows_too_straight
                or
                too_high
                or
                lowering_too_fast
            )


            if form_problem:

                correction_color = (
                    0,
                    0,
                    255
                )

            elif correction == "GOOD FORM":

                correction_color = (
                    0,
                    255,
                    0
                )

            else:

                correction_color = (
                    0,
                    165,
                    255
                )


            cv2.putText(
                frame,
                "CORRECTION:",
                (20, 240),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                correction,
                (20, 280),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                correction_color,
                2
            )


            cv2.putText(
                frame,
                "SHOULDER  L: " +
                str(int(left_angle)) +
                "  R: " +
                str(int(right_angle)),
                (20, 325),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "ELBOW     L: " +
                str(int(left_elbow_angle)) +
                "  R: " +
                str(int(right_elbow_angle)),
                (20, 360),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "ARM DIFFERENCE: " +
                str(
                    round(
                        arm_difference,
                        1
                    )
                ) +
                " deg",
                (20, 395),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (255, 255, 255),
                1
            )


            cv2.putText(
                frame,
                "TORSO MOVEMENT: " +
                str(
                    round(
                        torso_change,
                        3
                    )
                ),
                (20, 430),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (255, 255, 255),
                1
            )


        else:

            cv2.putText(
                frame,
                "KEEP FULL UPPER BODY VISIBLE",
                (20, 50),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 0, 255),
                2
            )


    else:

        cv2.putText(
            frame,
            "BODY NOT DETECTED",
            (20, 50),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 0, 255),
            2
        )


    cv2.imshow(
        "AI Gym Trainer - Lateral Raise",
        frame
    )


    if cv2.waitKey(1) & 0xFF == ord("q"):
        break


# -------------------------
# CLEANUP
# -------------------------

cap.release()
pose.close()
cv2.destroyAllWindows()


# -------------------------
# SAVE WORKOUT
# -------------------------

correct_reps = (
    reps -
    incorrect
)

if correct_reps < 0:
    correct_reps = 0


workout = tracker.save_workout(
    correct_reps,
    incorrect
)

tracker.print_summary(
    workout
)