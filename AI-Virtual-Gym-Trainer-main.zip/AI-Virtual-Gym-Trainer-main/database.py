import mysql.connector
import os


def get_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password=os.getenv("MYSQL_PASSWORD"),
        database="ai_gym_trainer"
    )


def test_connection():
    connection = None

    try:
        connection = get_connection()

        if connection.is_connected():
            print("Connected to MySQL successfully!")
            print("Database: ai_gym_trainer")

    except mysql.connector.Error as e:
        print("MySQL connection failed:")
        print(e)

    finally:
        if connection is not None and connection.is_connected():
            connection.close()


if __name__ == "__main__":
    test_connection()