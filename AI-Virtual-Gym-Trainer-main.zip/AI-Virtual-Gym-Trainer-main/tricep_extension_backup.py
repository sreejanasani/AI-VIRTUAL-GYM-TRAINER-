import cv2
import mediapipe as mp
import math
import time
from collections import deque

from workout_tracker import WorkoutTracker


def calculate_angle(a, b, c):
    angle = math.degrees(
        math.atan2(c[1] - b[1], c[0] - b[0]) -
        math.atan2(a[1] - b[1], a[0] - b[0])
    )

    angle = abs(angle)

    if angle > 180:
        angle = 360 - angle

    return angle


def upper_arm_angle(shoulder, elbow):
    dx = elbow[0] - shoulder[0]
    dy = shoulder[1] - elbow[1]

    if dy <= 0:
        return 90

    return math.degrees(
        math.atan2(abs(dx), abs(dy))
    )


def torso_angle(shoulder, hip):
    dx = shoulder[0] - hip[0]
    dy = hip[1] - shoulder[1]

    if dy <= 0:
        return 0

    return math.degrees(
        math.atan2(abs(dx), abs(dy))
    )


cap = cv2.VideoCapture(0)

mp_pose = mp.solutions.pose

pose = mp_pose.Pose(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

mp_draw = mp.solutions.drawing_utils


# =========================
# VARIABLES
# =========================

reps = 0
incorrect = 0

stage = None
reached_bottom = False

feedback = "GET READY"
correction = "GET INTO POSITION"

bad_form_during_rep = False

tracker = WorkoutTracker(
    "Single Arm Overhead Tricep Extension"
)


# =========================
# SMOOTHING
# =========================

elbow_history = deque(maxlen=5)
upper_arm_history = deque(maxlen=5)
torso_history = deque(maxlen=5)


# =========================
# REFERENCE VALUES
# =========================

baseline_upper_arm = None
baseline_torso = None


while True:

    success, frame = cap.read()

    if not success:
        print("Could not access camera")
        break

    frame = cv2.flip(frame, 1)

    rgb = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )

    result = pose.process(rgb)


    # =========================
    # TIMER
    # =========================

    elapsed = tracker.get_duration()

    minutes = int(elapsed // 60)
    seconds = int(elapsed % 60)

    timer_text = (
        f"{minutes:02d}:{seconds:02d}"
    )


    if result.pose_landmarks:

        mp_draw.draw_landmarks(
            frame,
            result.pose_landmarks,
            mp_pose.POSE_CONNECTIONS
        )

        lm = result.pose_landmarks.landmark


        # =========================
        # LEFT SIDE LANDMARKS
        # =========================

        shoulder = [
            lm[
                mp_pose.PoseLandmark.LEFT_SHOULDER.value
            ].x,
            lm[
                mp_pose.PoseLandmark.LEFT_SHOULDER.value
            ].y
        ]

        elbow = [
            lm[
                mp_pose.PoseLandmark.LEFT_ELBOW.value
            ].x,
            lm[
                mp_pose.PoseLandmark.LEFT_ELBOW.value
            ].y
        ]

        wrist = [
            lm[
                mp_pose.PoseLandmark.LEFT_WRIST.value
            ].x,
            lm[
                mp_pose.PoseLandmark.LEFT_WRIST.value
            ].y
        ]

        hip = [
            lm[
                mp_pose.PoseLandmark.LEFT_HIP.value
            ].x,
            lm[
                mp_pose.PoseLandmark.LEFT_HIP.value
            ].y
        ]


        # =========================
        # VISIBILITY
        # =========================

        visible = (
            lm[
                mp_pose.PoseLandmark.LEFT_SHOULDER.value
            ].visibility > 0.5
            and
            lm[
                mp_pose.PoseLandmark.LEFT_ELBOW.value
            ].visibility > 0.5
            and
            lm[
                mp_pose.PoseLandmark.LEFT_WRIST.value
            ].visibility > 0.5
            and
            lm[
                mp_pose.PoseLandmark.LEFT_HIP.value
            ].visibility > 0.5
        )


        if visible:

            # =========================
            # ELBOW ANGLE
            # =========================

            raw_elbow = calculate_angle(
                shoulder,
                elbow,
                wrist
            )

            elbow_history.append(
                raw_elbow
            )

            elbow_angle = (
                sum(elbow_history) /
                len(elbow_history)
            )


            # =========================
            # UPPER ARM POSITION
            # =========================

            raw_upper_arm = upper_arm_angle(
                shoulder,
                elbow
            )

            upper_arm_history.append(
                raw_upper_arm
            )

            arm_angle = (
                sum(upper_arm_history) /
                len(upper_arm_history)
            )


            # =========================
            # TORSO ANGLE
            # =========================

            raw_torso = torso_angle(
                shoulder,
                hip
            )

            torso_history.append(
                raw_torso
            )

            current_torso = (
                sum(torso_history) /
                len(torso_history)
            )


            # =========================
            # START POSITION
            # =========================
            #
            # Upper arm should be
            # reasonably vertical.
            #
            # =========================

            arm_in_position = (
                arm_angle < 35
            )


            # =========================
            # LEARN BASELINE
            # =========================

            if (
                elbow_angle > 145
                and
                arm_in_position
            ):

                if baseline_upper_arm is None:

                    baseline_upper_arm = (
                        arm_angle
                    )

                else:

                    baseline_upper_arm = (
                        0.95 *
                        baseline_upper_arm
                        +
                        0.05 *
                        arm_angle
                    )


                if baseline_torso is None:

                    baseline_torso = (
                        current_torso
                    )

                else:

                    baseline_torso = (
                        0.95 *
                        baseline_torso
                        +
                        0.05 *
                        current_torso
                    )


            # =========================
            # UPPER ARM MOVEMENT
            # =========================

            if baseline_upper_arm is not None:

                upper_arm_change = abs(
                    arm_angle -
                    baseline_upper_arm
                )

            else:

                upper_arm_change = 0


            upper_arm_moving = (
                elbow_angle < 145
                and
                upper_arm_change > 18
            )


            # =========================
            # TORSO MOVEMENT
            # =========================

            if baseline_torso is not None:

                torso_change = abs(
                    current_torso -
                    baseline_torso
                )

            else:

                torso_change = 0


            torso_moving = (
                torso_change > 15
            )


            # =========================
            # RANGE OF MOTION
            # =========================

            good_depth = (
                elbow_angle < 90
            )

            full_extension = (
                elbow_angle > 155
            )


            # =========================
            # FORM CORRECTION
            # =========================

            if not arm_in_position:

                correction = (
                    "KEEP UPPER ARM VERTICAL"
                )

                if stage is not None:
                    bad_form_during_rep = True


            elif torso_moving:

                correction = (
                    "KEEP TORSO STABLE"
                )

                bad_form_during_rep = True


            elif upper_arm_moving:

                correction = (
                    "KEEP ELBOW FIXED"
                )

                bad_form_during_rep = True


            elif (
                stage == "UP"
                and
                elbow_angle > 110
            ):

                correction = (
                    "LOWER BEHIND HEAD"
                )


            elif (
                stage == "UP"
                and
                elbow_angle >= 90
            ):

                correction = (
                    "LOWER A LITTLE MORE"
                )


            elif (
                stage == "DOWN"
                and
                elbow_angle < 125
            ):

                correction = (
                    "EXTEND YOUR ARM"
                )


            elif (
                stage == "DOWN"
                and
                elbow_angle <= 155
            ):

                correction = (
                    "EXTEND FULLY"
                )


            elif full_extension:

                correction = (
                    "GOOD EXTENSION"
                )


            else:

                correction = (
                    "GOOD FORM"
                )


            # =========================
            # REP COUNTING
            # =========================
            #
            # Preserve working logic:
            #
            # <90  = bottom
            # >155 = extension
            #
            # =========================


            # -------------------------
            # BOTTOM
            # -------------------------

            if elbow_angle < 90:

                if stage != "DOWN":

                    stage = "DOWN"

                    reached_bottom = True


                feedback = (
                    "EXTEND ARM"
                )


            # -------------------------
            # FULL EXTENSION
            # -------------------------

            elif elbow_angle > 155:

                if (
                    stage == "DOWN"
                    and
                    reached_bottom
                ):

                    reps += 1


                    if bad_form_during_rep:

                        incorrect += 1

                        feedback = (
                            "REP COMPLETED - FORM ISSUE"
                        )

                    else:

                        feedback = (
                            "GOOD REP"
                        )


                    print(
                        "Tricep Extension:",
                        reps
                    )


                else:

                    feedback = (
                        "LOWER BEHIND HEAD"
                    )


                stage = "UP"

                reached_bottom = False

                bad_form_during_rep = False


            # -------------------------
            # MIDDLE
            # -------------------------

            else:

                if stage == "DOWN":

                    feedback = (
                        "KEEP EXTENDING"
                    )


                elif stage == "UP":

                    feedback = (
                        "LOWER SLOWLY"
                    )


                else:

                    feedback = (
                        "LOWER ARM FIRST"
                    )


            # =========================
            # FORM SCORE
            # =========================

            correct_reps = (
                reps -
                incorrect
            )

            if correct_reps < 0:
                correct_reps = 0


            form_score = (
                tracker.get_form_score(
                    correct_reps,
                    incorrect
                )
            )


            # =========================
            # PIXEL POSITIONS
            # =========================

            h, w, _ = frame.shape


            shoulder_px = (
                int(shoulder[0] * w),
                int(shoulder[1] * h)
            )

            elbow_px = (
                int(elbow[0] * w),
                int(elbow[1] * h)
            )

            wrist_px = (
                int(wrist[0] * w),
                int(wrist[1] * h)
            )

            hip_px = (
                int(hip[0] * w),
                int(hip[1] * h)
            )


            # =========================
            # ARM COLOR
            # =========================

            arm_problem = (
                not arm_in_position
                or
                upper_arm_moving
            )


            if arm_problem:

                arm_color = (
                    0,
                    0,
                    255
                )

            else:

                arm_color = (
                    0,
                    255,
                    0
                )


            # Upper arm
            cv2.line(
                frame,
                shoulder_px,
                elbow_px,
                arm_color,
                7
            )


            # Forearm
            cv2.line(
                frame,
                elbow_px,
                wrist_px,
                arm_color,
                7
            )


            # =========================
            # TORSO VISUAL
            # =========================

            if torso_moving:

                torso_color = (
                    0,
                    0,
                    255
                )

            else:

                torso_color = (
                    0,
                    255,
                    0
                )


            cv2.line(
                frame,
                shoulder_px,
                hip_px,
                torso_color,
                5
            )


            # =========================
            # VISUAL CORRECTIONS
            # =========================


            # -------------------------
            # UPPER ARM NOT VERTICAL
            # -------------------------

            if not arm_in_position:

                target_elbow = (
                    shoulder_px[0],
                    shoulder_px[1] - 130
                )

                cv2.arrowedLine(
                    frame,
                    elbow_px,
                    target_elbow,
                    (0, 0, 255),
                    5,
                    tipLength=0.25
                )


            # -------------------------
            # KEEP ELBOW FIXED
            # -------------------------

            elif upper_arm_moving:

                cv2.circle(
                    frame,
                    elbow_px,
                    15,
                    (0, 0, 255),
                    -1
                )


            # -------------------------
            # LOWER
            # -------------------------

            elif stage == "UP":

                cv2.arrowedLine(
                    frame,
                    wrist_px,
                    (
                        wrist_px[0],
                        wrist_px[1] + 80
                    ),
                    (0, 165, 255),
                    5,
                    tipLength=0.25
                )


            # -------------------------
            # EXTEND
            # -------------------------

            elif stage == "DOWN":

                cv2.arrowedLine(
                    frame,
                    wrist_px,
                    (
                        wrist_px[0],
                        wrist_px[1] - 80
                    ),
                    (0, 255, 0),
                    5,
                    tipLength=0.25
                )


            # =========================
            # PANEL
            # =========================

            cv2.rectangle(
                frame,
                (0, 0),
                (820, 455),
                (30, 30, 30),
                -1
            )


            cv2.putText(
                frame,
                "AI GYM TRAINER - OVERHEAD TRICEP EXTENSION",
                (20, 35),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.68,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "REPS: " +
                str(reps),
                (20, 80),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (0, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "FORM ISSUES: " +
                str(incorrect),
                (190, 80),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "FORM SCORE: " +
                str(form_score) +
                "%",
                (20, 120),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "TIME: " +
                timer_text,
                (350, 120),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "POSITION: " +
                str(stage),
                (20, 160),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "MOVEMENT: " +
                feedback,
                (20, 200),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 0),
                2
            )


            # =========================
            # CORRECTION COLOR
            # =========================

            form_problem = (
                not arm_in_position
                or
                torso_moving
                or
                upper_arm_moving
            )


            if form_problem:

                correction_color = (
                    0,
                    0,
                    255
                )

            elif (
                correction ==
                "GOOD EXTENSION"
                or
                correction ==
                "GOOD FORM"
            ):

                correction_color = (
                    0,
                    255,
                    0
                )

            else:

                correction_color = (
                    0,
                    165,
                    255
                )


            cv2.putText(
                frame,
                "CORRECTION:",
                (20, 240),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                correction,
                (20, 280),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                correction_color,
                2
            )


            cv2.putText(
                frame,
                "ELBOW ANGLE: " +
                str(int(elbow_angle)),
                (20, 325),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "UPPER ARM TILT: " +
                str(
                    round(
                        arm_angle,
                        1
                    )
                ) +
                " deg",
                (20, 360),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "ARM MOVEMENT: " +
                str(
                    round(
                        upper_arm_change,
                        1
                    )
                ) +
                " deg",
                (20, 395),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (255, 255, 255),
                1
            )


            cv2.putText(
                frame,
                "TORSO CHANGE: " +
                str(
                    round(
                        torso_change,
                        1
                    )
                ) +
                " deg",
                (20, 430),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (255, 255, 255),
                1
            )


        else:

            cv2.putText(
                frame,
                "KEEP LEFT ARM AND TORSO VISIBLE",
                (20, 50),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.75,
                (0, 0, 255),
                2
            )


    else:

        cv2.putText(
            frame,
            "BODY NOT DETECTED",
            (20, 50),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 0, 255),
            2
        )


    cv2.imshow(
        "AI Gym Trainer - Tricep Extension",
        frame
    )


    if cv2.waitKey(1) & 0xFF == ord("q"):
        break


# =========================
# CLEANUP
# =========================

cap.release()
pose.close()
cv2.destroyAllWindows()


# =========================
# SAVE WORKOUT
# =========================

correct_reps = (
    reps -
    incorrect
)

if correct_reps < 0:
    correct_reps = 0


workout = tracker.save_workout(
    correct_reps,
    incorrect
)

tracker.print_summary(
    workout
)