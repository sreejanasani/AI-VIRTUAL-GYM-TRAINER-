import cv2
import mediapipe as mp
import math
import time
import threading
from collections import deque
from workout_tracker import WorkoutTracker


def calculate_angle(a, b, c):
    angle = math.degrees(math.atan2(c[1] - b[1], c[0] - b[0]) - math.atan2(a[1] - b[1], a[0] - b[0]))
    angle = abs(angle)
    return 360 - angle if angle > 180 else angle


def distance(a, b):
    return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2)


class LateralRaiseWorkout:
    def __init__(self):
        self.cap = None
        self.pose = None
        self.thread = None
        self.running = False
        self.frame = None
        self.lock = threading.Lock()
        self.tracker = None
        self.saved_result = None
        self.reps = 0
        self.incorrect = 0
        self.feedback = "GET READY"
        self.correction = "ARMS DOWN TO START"
        self.stage = None
        self.left_angle = 0
        self.right_angle = 0

    def start(self):
        if self.running:
            return True
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            self.cap.release()
            self.cap = None
            return False
        try:
            self.pose = mp.solutions.pose.Pose(
                min_detection_confidence=0.5,
                min_tracking_confidence=0.5
            )
        except Exception:
            self.cap.release()
            self.cap = None
            raise
        self.tracker = WorkoutTracker("Lateral Raise")
        self.running = True
        self.thread = threading.Thread(target=self.process_frame, daemon=True)
        self.thread.start()
        return True

    def process_frame(self):
        cap = self.cap
        pose = self.pose
        tracker = self.tracker
        mp_pose = mp.solutions.pose
        mp_draw = mp.solutions.drawing_utils
        reps = 0
        incorrect = 0
        stage = None
        reached_top = False
        feedback = "GET READY"
        correction = "ARMS DOWN TO START"
        bad_form_during_rep = False
        left_shoulder_history = deque(maxlen=5)
        right_shoulder_history = deque(maxlen=5)
        left_elbow_history = deque(maxlen=5)
        right_elbow_history = deque(maxlen=5)
        torso_history = deque(maxlen=5)
        baseline_torso_x = None
        previous_avg_angle = None
        previous_time = time.time()
        left_angle = right_angle = 0
        try:
            while self.running:
                success, frame = cap.read()
                if not success:
                    feedback = "CAMERA ERROR"
                    correction = "CAMERA NOT AVAILABLE"
                    break
                frame = cv2.flip(frame, 1)
                rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                result = pose.process(rgb)
                elapsed = tracker.get_duration()
                minutes = int(elapsed // 60)
                seconds = int(elapsed % 60)
                timer_text = f"{minutes:02d}:{seconds:02d}"
                if result.pose_landmarks:

                    mp_draw.draw_landmarks(
                        frame,
                        result.pose_landmarks,
                        mp_pose.POSE_CONNECTIONS
                    )

                    lm = result.pose_landmarks.landmark


                    # -------------------------
                    # LANDMARKS
                    # -------------------------

                    left_ear = [
                        lm[mp_pose.PoseLandmark.LEFT_EAR.value].x,
                        lm[mp_pose.PoseLandmark.LEFT_EAR.value].y
                    ]

                    right_ear = [
                        lm[mp_pose.PoseLandmark.RIGHT_EAR.value].x,
                        lm[mp_pose.PoseLandmark.RIGHT_EAR.value].y
                    ]

                    left_shoulder = [
                        lm[mp_pose.PoseLandmark.LEFT_SHOULDER.value].x,
                        lm[mp_pose.PoseLandmark.LEFT_SHOULDER.value].y
                    ]

                    right_shoulder = [
                        lm[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].x,
                        lm[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].y
                    ]

                    left_elbow = [
                        lm[mp_pose.PoseLandmark.LEFT_ELBOW.value].x,
                        lm[mp_pose.PoseLandmark.LEFT_ELBOW.value].y
                    ]

                    right_elbow = [
                        lm[mp_pose.PoseLandmark.RIGHT_ELBOW.value].x,
                        lm[mp_pose.PoseLandmark.RIGHT_ELBOW.value].y
                    ]

                    left_wrist = [
                        lm[mp_pose.PoseLandmark.LEFT_WRIST.value].x,
                        lm[mp_pose.PoseLandmark.LEFT_WRIST.value].y
                    ]

                    right_wrist = [
                        lm[mp_pose.PoseLandmark.RIGHT_WRIST.value].x,
                        lm[mp_pose.PoseLandmark.RIGHT_WRIST.value].y
                    ]

                    left_hip = [
                        lm[mp_pose.PoseLandmark.LEFT_HIP.value].x,
                        lm[mp_pose.PoseLandmark.LEFT_HIP.value].y
                    ]

                    right_hip = [
                        lm[mp_pose.PoseLandmark.RIGHT_HIP.value].x,
                        lm[mp_pose.PoseLandmark.RIGHT_HIP.value].y
                    ]

                    left_knee = [
                        lm[mp_pose.PoseLandmark.LEFT_KNEE.value].x,
                        lm[mp_pose.PoseLandmark.LEFT_KNEE.value].y
                    ]

                    right_knee = [
                        lm[mp_pose.PoseLandmark.RIGHT_KNEE.value].x,
                        lm[mp_pose.PoseLandmark.RIGHT_KNEE.value].y
                    ]


                    # -------------------------
                    # VISIBILITY
                    # -------------------------

                    visible = (
                        lm[mp_pose.PoseLandmark.LEFT_SHOULDER.value].visibility > 0.5
                        and
                        lm[mp_pose.PoseLandmark.RIGHT_SHOULDER.value].visibility > 0.5
                        and
                        lm[mp_pose.PoseLandmark.LEFT_ELBOW.value].visibility > 0.5
                        and
                        lm[mp_pose.PoseLandmark.RIGHT_ELBOW.value].visibility > 0.5
                        and
                        lm[mp_pose.PoseLandmark.LEFT_WRIST.value].visibility > 0.5
                        and
                        lm[mp_pose.PoseLandmark.RIGHT_WRIST.value].visibility > 0.5
                        and
                        lm[mp_pose.PoseLandmark.LEFT_HIP.value].visibility > 0.5
                        and
                        lm[mp_pose.PoseLandmark.RIGHT_HIP.value].visibility > 0.5
                    )


                    if visible:

                        # =========================
                        # SHOULDER ANGLES
                        # =========================

                        raw_left_shoulder = calculate_angle(
                            left_hip,
                            left_shoulder,
                            left_elbow
                        )

                        raw_right_shoulder = calculate_angle(
                            right_hip,
                            right_shoulder,
                            right_elbow
                        )


                        left_shoulder_history.append(
                            raw_left_shoulder
                        )

                        right_shoulder_history.append(
                            raw_right_shoulder
                        )


                        left_angle = (
                            sum(left_shoulder_history) /
                            len(left_shoulder_history)
                        )

                        right_angle = (
                            sum(right_shoulder_history) /
                            len(right_shoulder_history)
                        )


                        average_angle = (
                            left_angle +
                            right_angle
                        ) / 2


                        # =========================
                        # ELBOW BEND
                        # =========================

                        raw_left_elbow = calculate_angle(
                            left_shoulder,
                            left_elbow,
                            left_wrist
                        )

                        raw_right_elbow = calculate_angle(
                            right_shoulder,
                            right_elbow,
                            right_wrist
                        )


                        left_elbow_history.append(
                            raw_left_elbow
                        )

                        right_elbow_history.append(
                            raw_right_elbow
                        )


                        left_elbow_angle = (
                            sum(left_elbow_history) /
                            len(left_elbow_history)
                        )

                        right_elbow_angle = (
                            sum(right_elbow_history) /
                            len(right_elbow_history)
                        )


                        # =========================
                        # LEFT / RIGHT BALANCE
                        # =========================

                        arm_difference = abs(
                            left_angle -
                            right_angle
                        )

                        arms_uneven = (
                            average_angle > 35
                            and
                            arm_difference > 15
                        )


                        # =========================
                        # ELBOW FORM
                        # =========================
                        #
                        # Lateral raise should have
                        # a slight elbow bend.
                        #
                        # Too straight: >178
                        # Too bent: <140
                        # =========================

                        elbows_too_straight = (
                            average_angle > 30
                            and
                            left_elbow_angle > 178
                            and
                            right_elbow_angle > 178
                        )

                        elbows_too_bent = (
                            average_angle > 30
                            and
                            (
                                left_elbow_angle < 140
                                or
                                right_elbow_angle < 140
                            )
                        )


                        # =========================
                        # TORSO POSITION
                        # =========================

                        shoulder_center_x = (
                            left_shoulder[0] +
                            right_shoulder[0]
                        ) / 2

                        hip_center_x = (
                            left_hip[0] +
                            right_hip[0]
                        ) / 2

                        torso_x = (
                            shoulder_center_x -
                            hip_center_x
                        )


                        torso_history.append(
                            torso_x
                        )

                        smooth_torso_x = (
                            sum(torso_history) /
                            len(torso_history)
                        )


                        # Learn upright reference
                        # when arms are down.

                        if average_angle < 25:

                            if baseline_torso_x is None:

                                baseline_torso_x = (
                                    smooth_torso_x
                                )

                            else:

                                baseline_torso_x = (
                                    0.95 *
                                    baseline_torso_x
                                    +
                                    0.05 *
                                    smooth_torso_x
                                )


                        if baseline_torso_x is not None:

                            torso_change = abs(
                                smooth_torso_x -
                                baseline_torso_x
                            )

                        else:

                            torso_change = 0


                        torso_swing = (
                            average_angle > 30
                            and
                            torso_change > 0.055
                        )


                        # =========================
                        # SHOULDER SHRUG
                        # =========================
                        #
                        # Approximation:
                        # shoulder-to-ear distance
                        # becomes unusually small.
                        #
                        # =========================

                        left_ear_distance = distance(
                            left_ear,
                            left_shoulder
                        )

                        right_ear_distance = distance(
                            right_ear,
                            right_shoulder
                        )

                        average_ear_distance = (
                            left_ear_distance +
                            right_ear_distance
                        ) / 2


                        shrugging = (
                            average_angle > 55
                            and
                            average_ear_distance < 0.105
                        )


                        # =========================
                        # TOP HEIGHT
                        # =========================

                        too_high = (
                            average_angle > 105
                        )


                        good_top = (
                            75 <= average_angle <= 100
                        )


                        # =========================
                        # LOWERING SPEED
                        # =========================

                        current_time = time.time()

                        dt = (
                            current_time -
                            previous_time
                        )

                        if (
                            previous_avg_angle is not None
                            and
                            dt > 0
                        ):

                            angle_speed = abs(
                                average_angle -
                                previous_avg_angle
                            ) / dt

                        else:

                            angle_speed = 0


                        lowering_too_fast = (
                            stage == "UP"
                            and
                            average_angle < 70
                            and
                            angle_speed > 160
                        )


                        previous_avg_angle = average_angle
                        previous_time = current_time


                        # =========================
                        # FORM CORRECTION
                        # =========================

                        if arms_uneven:

                            correction = (
                                "KEEP ARMS EVEN"
                            )

                            bad_form_during_rep = True


                        elif torso_swing:

                            correction = (
                                "KEEP TORSO STABLE"
                            )

                            bad_form_during_rep = True


                        elif shrugging:

                            correction = (
                                "KEEP SHOULDERS DOWN"
                            )

                            bad_form_during_rep = True


                        elif elbows_too_bent:

                            correction = (
                                "LESS ELBOW BEND"
                            )

                            bad_form_during_rep = True


                        elif elbows_too_straight:

                            correction = (
                                "KEEP SLIGHT ELBOW BEND"
                            )

                            bad_form_during_rep = True


                        elif too_high:

                            correction = (
                                "DO NOT RAISE TOO HIGH"
                            )

                            bad_form_during_rep = True


                        elif lowering_too_fast:

                            correction = (
                                "LOWER MORE SLOWLY"
                            )

                            bad_form_during_rep = True


                        elif (
                            stage == "DOWN"
                            and
                            average_angle < 65
                        ):

                            correction = (
                                "RAISE ARMS HIGHER"
                            )


                        elif good_top:

                            correction = (
                                "GOOD HEIGHT - LOWER SLOWLY"
                            )


                        elif stage == "UP":

                            correction = (
                                "LOWER SLOWLY"
                            )


                        else:

                            correction = (
                                "GOOD FORM"
                            )


                        # =========================
                        # REP COUNTING
                        # =========================
                        #
                        # Preserve working logic:
                        #
                        # DOWN <25
                        # TOP >=75
                        # DOWN <25
                        # = 1 rep
                        # =========================


                        # -------------------------
                        # ARMS DOWN
                        # -------------------------

                        if average_angle < 25:

                            if (
                                stage == "UP"
                                and
                                reached_top
                            ):

                                reps += 1


                                if bad_form_during_rep:

                                    incorrect += 1

                                    feedback = (
                                        "REP COMPLETED - FORM ISSUE"
                                    )

                                else:

                                    feedback = "GOOD REP"


                                print(
                                    "Lateral Raise:",
                                    reps
                                )


                            else:

                                feedback = (
                                    "RAISE ARMS"
                                )


                            stage = "DOWN"

                            reached_top = False

                            bad_form_during_rep = False


                        # -------------------------
                        # TOP
                        # -------------------------

                        elif average_angle >= 75:

                            if stage == "DOWN":

                                stage = "UP"

                                reached_top = True

                                if too_high:

                                    feedback = (
                                        "TOO HIGH - LOWER"
                                    )

                                else:

                                    feedback = (
                                        "GOOD HEIGHT"
                                    )


                            elif stage == "UP":

                                feedback = (
                                    "LOWER ARMS"
                                )


                        # -------------------------
                        # MIDDLE
                        # -------------------------

                        else:

                            if stage == "DOWN":

                                feedback = (
                                    "KEEP RAISING"
                                )


                            elif stage == "UP":

                                feedback = (
                                    "LOWER SLOWLY"
                                )


                            else:

                                feedback = (
                                    "LOWER ARMS FIRST"
                                )


                        # =========================
                        # FORM SCORE
                        # =========================

                        correct_reps = (
                            reps -
                            incorrect
                        )

                        if correct_reps < 0:
                            correct_reps = 0


                        form_score = (
                            tracker.get_form_score(
                                correct_reps,
                                incorrect
                            )
                        )


                        # =========================
                        # PIXEL POSITIONS
                        # =========================

                        h, w, _ = frame.shape


                        left_shoulder_px = (
                            int(left_shoulder[0] * w),
                            int(left_shoulder[1] * h)
                        )

                        right_shoulder_px = (
                            int(right_shoulder[0] * w),
                            int(right_shoulder[1] * h)
                        )

                        left_elbow_px = (
                            int(left_elbow[0] * w),
                            int(left_elbow[1] * h)
                        )

                        right_elbow_px = (
                            int(right_elbow[0] * w),
                            int(right_elbow[1] * h)
                        )

                        left_wrist_px = (
                            int(left_wrist[0] * w),
                            int(left_wrist[1] * h)
                        )

                        right_wrist_px = (
                            int(right_wrist[0] * w),
                            int(right_wrist[1] * h)
                        )


                        # =========================
                        # ARM COLORS
                        # =========================

                        if (
                            arms_uneven
                            or
                            too_high
                            or
                            elbows_too_bent
                            or
                            elbows_too_straight
                        ):

                            arm_color = (
                                0,
                                0,
                                255
                            )

                        else:

                            arm_color = (
                                0,
                                255,
                                0
                            )


                        cv2.line(
                            frame,
                            left_shoulder_px,
                            left_elbow_px,
                            arm_color,
                            6
                        )

                        cv2.line(
                            frame,
                            left_elbow_px,
                            left_wrist_px,
                            arm_color,
                            6
                        )

                        cv2.line(
                            frame,
                            right_shoulder_px,
                            right_elbow_px,
                            arm_color,
                            6
                        )

                        cv2.line(
                            frame,
                            right_elbow_px,
                            right_wrist_px,
                            arm_color,
                            6
                        )


                        # =========================
                        # VISUAL ARROWS
                        # =========================

                        if (
                            stage == "DOWN"
                            and
                            average_angle < 65
                        ):

                            cv2.arrowedLine(
                                frame,
                                left_elbow_px,
                                (
                                    left_elbow_px[0] - 70,
                                    left_elbow_px[1] - 50
                                ),
                                (0, 165, 255),
                                5,
                                tipLength=0.25
                            )

                            cv2.arrowedLine(
                                frame,
                                right_elbow_px,
                                (
                                    right_elbow_px[0] + 70,
                                    right_elbow_px[1] - 50
                                ),
                                (0, 165, 255),
                                5,
                                tipLength=0.25
                            )


                        elif too_high:

                            cv2.arrowedLine(
                                frame,
                                left_elbow_px,
                                (
                                    left_elbow_px[0],
                                    left_elbow_px[1] + 70
                                ),
                                (0, 0, 255),
                                5,
                                tipLength=0.25
                            )

                            cv2.arrowedLine(
                                frame,
                                right_elbow_px,
                                (
                                    right_elbow_px[0],
                                    right_elbow_px[1] + 70
                                ),
                                (0, 0, 255),
                                5,
                                tipLength=0.25
                            )


                        # =========================
                        # PANEL
                        # =========================

                        cv2.rectangle(
                            frame,
                            (0, 0),
                            (850, 470),
                            (30, 30, 30),
                            -1
                        )


                        cv2.putText(
                            frame,
                            "AI GYM TRAINER - LATERAL RAISE",
                            (20, 35),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.7,
                            (255, 255, 255),
                            2
                        )


                        cv2.putText(
                            frame,
                            "REPS: " +
                            str(reps),
                            (20, 80),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            1,
                            (0, 255, 0),
                            2
                        )


                        cv2.putText(
                            frame,
                            "FORM ISSUES: " +
                            str(incorrect),
                            (190, 80),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.65,
                            (0, 255, 255),
                            2
                        )


                        cv2.putText(
                            frame,
                            "FORM SCORE: " +
                            str(form_score) +
                            "%",
                            (20, 120),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.65,
                            (0, 255, 0),
                            2
                        )


                        cv2.putText(
                            frame,
                            "TIME: " +
                            timer_text,
                            (350, 120),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.65,
                            (255, 255, 255),
                            2
                        )


                        cv2.putText(
                            frame,
                            "POSITION: " +
                            str(stage),
                            (20, 160),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.65,
                            (255, 255, 0),
                            2
                        )


                        cv2.putText(
                            frame,
                            "MOVEMENT: " +
                            feedback,
                            (20, 200),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.65,
                            (255, 255, 0),
                            2
                        )


                        # -------------------------
                        # CORRECTION COLOR
                        # -------------------------

                        form_problem = (
                            arms_uneven
                            or
                            torso_swing
                            or
                            shrugging
                            or
                            elbows_too_bent
                            or
                            elbows_too_straight
                            or
                            too_high
                            or
                            lowering_too_fast
                        )


                        if form_problem:

                            correction_color = (
                                0,
                                0,
                                255
                            )

                        elif correction == "GOOD FORM":

                            correction_color = (
                                0,
                                255,
                                0
                            )

                        else:

                            correction_color = (
                                0,
                                165,
                                255
                            )


                        cv2.putText(
                            frame,
                            "CORRECTION:",
                            (20, 240),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.65,
                            (255, 255, 255),
                            2
                        )


                        cv2.putText(
                            frame,
                            correction,
                            (20, 280),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.65,
                            correction_color,
                            2
                        )


                        cv2.putText(
                            frame,
                            "SHOULDER  L: " +
                            str(int(left_angle)) +
                            "  R: " +
                            str(int(right_angle)),
                            (20, 325),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.6,
                            (255, 255, 255),
                            2
                        )


                        cv2.putText(
                            frame,
                            "ELBOW     L: " +
                            str(int(left_elbow_angle)) +
                            "  R: " +
                            str(int(right_elbow_angle)),
                            (20, 360),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.6,
                            (255, 255, 255),
                            2
                        )


                        cv2.putText(
                            frame,
                            "ARM DIFFERENCE: " +
                            str(
                                round(
                                    arm_difference,
                                    1
                                )
                            ) +
                            " deg",
                            (20, 395),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.55,
                            (255, 255, 255),
                            1
                        )


                        cv2.putText(
                            frame,
                            "TORSO MOVEMENT: " +
                            str(
                                round(
                                    torso_change,
                                    3
                                )
                            ),
                            (20, 430),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.55,
                            (255, 255, 255),
                            1
                        )


                    else:

                        cv2.putText(
                            frame,
                            "KEEP FULL UPPER BODY VISIBLE",
                            (20, 50),
                            cv2.FONT_HERSHEY_SIMPLEX,
                            0.7,
                            (0, 0, 255),
                            2
                        )


                else:

                    cv2.putText(
                        frame,
                        "BODY NOT DETECTED",
                        (20, 50),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.8,
                        (0, 0, 255),
                        2
                    )


                with self.lock:
                    self.reps = reps
                    self.incorrect = incorrect
                    self.feedback = feedback
                    self.correction = correction
                    self.stage = stage
                    self.left_angle = left_angle
                    self.right_angle = right_angle
                    self.frame = frame.copy()
        except Exception as exc:
            print("Lateral Raise processing error:", exc)
            with self.lock:
                self.feedback = "CAMERA ERROR"
                self.correction = str(exc)
        finally:
            self.running = False
            if self.cap is not None:
                self.cap.release()
                self.cap = None
            if self.pose is not None:
                self.pose.close()
                self.pose = None

    def get_jpeg_frame(self):
        with self.lock:
            if self.frame is None:
                return None
            frame = self.frame.copy()
        ok, encoded = cv2.imencode(".jpg", frame)
        return encoded.tobytes() if ok else None

    def get_status(self):
        with self.lock:
            reps = self.reps
            incorrect = self.incorrect
            correction = self.correction
            feedback = self.feedback
            stage = self.stage
            left_angle = self.left_angle
            right_angle = self.right_angle
        correct = max(0, reps - incorrect)
        score = self.tracker.get_form_score(correct, incorrect) if self.tracker else 0
        duration = self.tracker.get_duration() if self.tracker else 0
        return {
            "running": self.running,
            "exercise": "Lateral Raise",
            "reps": reps,
            "correct_reps": correct,
            "incorrect_reps": incorrect,
            "form_issues": incorrect,
            "form_score": score,
            "duration": round(duration, 2),
            "correction": correction,
            "movement": feedback,
            "stage": stage,
            "left_angle": round(left_angle, 1),
            "right_angle": round(right_angle, 1),
        }

    def stop(self):
        if self.saved_result is not None:
            return self.saved_result
        self.running = False
        if self.thread is not None and self.thread.is_alive():
            self.thread.join(timeout=5)
            if self.thread.is_alive():
                raise RuntimeError("Camera is still processing; please retry ending the workout.")
        if self.tracker is None:
            raise RuntimeError("Workout was never started.")
        correct = max(0, self.reps - self.incorrect)
        workout = self.tracker.save_workout(correct, self.incorrect)
        self.tracker.print_summary(workout)
        self.saved_result = {
            "success": True,
            "exercise": "Lateral Raise",
            "total_reps": self.reps,
            "correct_reps": correct,
            "incorrect_reps": self.incorrect,
            "workout": workout,
        }
        return self.saved_result
