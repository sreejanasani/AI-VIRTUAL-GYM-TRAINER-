import cv2
import mediapipe as mp
import math
import time
import threading

from collections import deque
from database import get_connection


def calculate_angle(a, b, c):
    angle = math.degrees(
        math.atan2(c[1] - b[1], c[0] - b[0])
        - math.atan2(a[1] - b[1], a[0] - b[0])
    )

    angle = abs(angle)

    if angle > 180:
        angle = 360 - angle

    return angle


class PlankWorkout:

    def __init__(self):
        self.cap = None
        self.pose = None

        self.mp_pose = mp.solutions.pose
        self.mp_draw = mp.solutions.drawing_utils

        self.running = False
        self.thread = None
        self.lock = threading.Lock()

        self.frame = None

        self.feedback = "GET INTO PLANK POSITION"
        self.movement = "GET READY"

        self.angle_history = deque(maxlen=5)

        self.good_hold_time = 0.0
        self.session_start = None
        self.last_frame_time = None

        self.body_angle = 0
        self.good_form = False

        self.workout_saved = False

    # =========================
    # START WORKOUT
    # =========================

    def start(self):

        if self.running:
            return

        self.cap = cv2.VideoCapture(0)

        if not self.cap.isOpened():
            self.cap.release()
            self.cap = None
            raise RuntimeError("Could not access camera")

        try:
            self.pose = self.mp_pose.Pose(
                min_detection_confidence=0.5,
                min_tracking_confidence=0.5
            )
        except Exception:
            self.cap.release()
            self.cap = None
            raise

        self.session_start = time.time()
        self.last_frame_time = self.session_start

        self.running = True

        self.thread = threading.Thread(
            target=self.process_frame,
            daemon=True
        )

        self.thread.start()

    # =========================
    # CAMERA PROCESSING
    # =========================

    def process_frame(self):

        try:

            while self.running:

                success, frame = self.cap.read()

                if not success:
                    self.feedback = "CAMERA NOT AVAILABLE"
                    self.movement = "CAMERA ERROR"
                    break

                current_time = time.time()

                frame_delta = max(
                    0,
                    current_time - self.last_frame_time
                )

                self.last_frame_time = current_time

                frame = cv2.flip(frame, 1)

                rgb = cv2.cvtColor(
                    frame,
                    cv2.COLOR_BGR2RGB
                )

                result = self.pose.process(rgb)

                session_time = (
                    current_time - self.session_start
                )

                session_minutes = int(
                    session_time // 60
                )

                session_seconds = int(
                    session_time % 60
                )

                session_text = (
                    f"{session_minutes:02d}:"
                    f"{session_seconds:02d}"
                )

                self.good_form = False

                body_color = (0, 165, 255)

                if result.pose_landmarks:

                    self.mp_draw.draw_landmarks(
                        frame,
                        result.pose_landmarks,
                        self.mp_pose.POSE_CONNECTIONS
                    )

                    lm = result.pose_landmarks.landmark

                    shoulder_lm = lm[
                        self.mp_pose.PoseLandmark.LEFT_SHOULDER.value
                    ]

                    hip_lm = lm[
                        self.mp_pose.PoseLandmark.LEFT_HIP.value
                    ]

                    ankle_lm = lm[
                        self.mp_pose.PoseLandmark.LEFT_ANKLE.value
                    ]

                    shoulder = [
                        shoulder_lm.x,
                        shoulder_lm.y
                    ]

                    hip = [
                        hip_lm.x,
                        hip_lm.y
                    ]

                    ankle = [
                        ankle_lm.x,
                        ankle_lm.y
                    ]

                    visible = (
                        shoulder_lm.visibility > 0.5
                        and hip_lm.visibility > 0.5
                        and ankle_lm.visibility > 0.5
                    )

                    if visible:

                        raw_angle = calculate_angle(
                            shoulder,
                            hip,
                            ankle
                        )

                        self.angle_history.append(
                            raw_angle
                        )

                        self.body_angle = (
                            sum(self.angle_history)
                            / len(self.angle_history)
                        )

                        horizontal_body = (
                            abs(
                                shoulder[1] - ankle[1]
                            ) < 0.30
                        )

                        if not horizontal_body:

                            self.feedback = (
                                "GET INTO PLANK POSITION"
                            )

                            body_color = (0, 165, 255)

                        elif self.body_angle >= 175:

                            self.feedback = "GOOD PLANK"

                            body_color = (0, 255, 0)

                            self.good_form = True

                        elif hip[1] < (
                            shoulder[1] + ankle[1]
                        ) / 2:

                            self.feedback = (
                                "LOWER YOUR HIPS"
                            )

                            body_color = (0, 0, 255)

                        else:

                            self.feedback = (
                                "RAISE YOUR HIPS"
                            )

                            body_color = (0, 0, 255)

                        if self.good_form:

                            self.good_hold_time += (
                                frame_delta
                            )

                            self.movement = (
                                "TIMER RUNNING"
                            )

                        else:

                            self.movement = (
                                "TIMER PAUSED"
                            )

                        h, w, _ = frame.shape

                        shoulder_px = (
                            int(shoulder[0] * w),
                            int(shoulder[1] * h)
                        )

                        hip_px = (
                            int(hip[0] * w),
                            int(hip[1] * h)
                        )

                        ankle_px = (
                            int(ankle[0] * w),
                            int(ankle[1] * h)
                        )

                        cv2.line(
                            frame,
                            shoulder_px,
                            hip_px,
                            body_color,
                            8
                        )

                        cv2.line(
                            frame,
                            hip_px,
                            ankle_px,
                            body_color,
                            8
                        )

                        cv2.circle(
                            frame,
                            hip_px,
                            15,
                            body_color,
                            -1
                        )

                        if self.feedback == (
                            "LOWER YOUR HIPS"
                        ):

                            cv2.arrowedLine(
                                frame,
                                (
                                    hip_px[0] + 40,
                                    hip_px[1] - 60
                                ),
                                (
                                    hip_px[0] + 40,
                                    hip_px[1] + 50
                                ),
                                (0, 0, 255),
                                5,
                                tipLength=0.25
                            )

                        elif self.feedback == (
                            "RAISE YOUR HIPS"
                        ):

                            cv2.arrowedLine(
                                frame,
                                (
                                    hip_px[0] + 40,
                                    hip_px[1] + 60
                                ),
                                (
                                    hip_px[0] + 40,
                                    hip_px[1] - 50
                                ),
                                (0, 0, 255),
                                5,
                                tipLength=0.25
                            )

                    else:

                        self.angle_history.clear()

                        self.feedback = (
                            "KEEP FULL SIDE OF BODY VISIBLE"
                        )

                        self.movement = "TIMER PAUSED"

                else:

                    self.angle_history.clear()

                    self.feedback = "BODY NOT DETECTED"

                    self.movement = "TIMER PAUSED"

                # =========================
                # DISPLAY PANEL
                # =========================

                hold_minutes = int(
                    self.good_hold_time // 60
                )

                hold_seconds = int(
                    self.good_hold_time % 60
                )

                hold_text = (
                    f"{hold_minutes:02d}:"
                    f"{hold_seconds:02d}"
                )

                panel_width = min(
                    frame.shape[1],
                    680
                )

                cv2.rectangle(
                    frame,
                    (0, 0),
                    (panel_width, 290),
                    (30, 30, 30),
                    -1
                )

                cv2.putText(
                    frame,
                    "AI GYM TRAINER - PLANK",
                    (20, 35),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (255, 255, 255),
                    2
                )

                cv2.putText(
                    frame,
                    "GOOD FORM HOLD: " + hold_text,
                    (20, 85),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.9,
                    (0, 255, 0),
                    2
                )

                cv2.putText(
                    frame,
                    "SESSION TIME: " + session_text,
                    (20, 125),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.65,
                    (255, 255, 255),
                    2
                )

                cv2.putText(
                    frame,
                    "CORRECTION: " + self.feedback,
                    (20, 170),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.65,
                    body_color,
                    2
                )

                cv2.putText(
                    frame,
                    "BODY ANGLE: "
                    + str(int(self.body_angle)),
                    (20, 215),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.65,
                    (255, 255, 255),
                    2
                )

                cv2.putText(
                    frame,
                    "TARGET: 175 - 180 degrees",
                    (20, 250),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55,
                    (255, 255, 255),
                    1
                )

                status_color = (
                    (0, 255, 0)
                    if self.good_form
                    else (0, 165, 255)
                )

                cv2.putText(
                    frame,
                    self.movement,
                    (20, 280),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    status_color,
                    2
                )

                with self.lock:
                    self.frame = frame.copy()

        finally:

            self.running = False

            if self.cap is not None:
                self.cap.release()
                self.cap = None

            if self.pose is not None:
                self.pose.close()
                self.pose = None

    # =========================
    # VIDEO STREAM
    # =========================

    def get_jpeg_frame(self):

        with self.lock:

            if self.frame is None:
                return None

            frame = self.frame.copy()

        success, buffer = cv2.imencode(
            ".jpg",
            frame
        )

        if not success:
            return None

        return buffer.tobytes()

    # =========================
    # LIVE STATISTICS
    # =========================

    def get_status(self):

        duration = (
            time.time() - self.session_start
            if self.session_start is not None
            else 0
        )

        form_score = (
            self.good_hold_time / duration * 100
            if duration > 0
            else 0
        )

        return {
            "running": self.running,
            "exercise": "Plank",
            "reps": 0,
            "correct_reps": 0,
            "incorrect_reps": 0,
            "form_issues": 0,
            "good_form_seconds": round(
                self.good_hold_time,
                2
            ),
            "duration": round(duration, 2),
            "form_score": round(
                min(100, form_score),
                1
            ),
            "correction": self.feedback,
            "movement": self.movement,
            "body_angle": round(
                self.body_angle,
                1
            )
        }

    # =========================
    # STOP AND SAVE
    # =========================

    def stop(self):

        self.running = False

        if (
            self.thread is not None
            and self.thread.is_alive()
        ):
            self.thread.join(timeout=5)

        duration = (
            time.time() - self.session_start
            if self.session_start is not None
            else 0
        )

        good_form_seconds = round(
            self.good_hold_time,
            2
        )

        duration_seconds = round(
            duration,
            2
        )

        form_score = (
            round(
                good_form_seconds
                / duration_seconds
                * 100,
                1
            )
            if duration_seconds > 0
            else 0
        )

        form_score = min(
            100,
            form_score
        )

        workout_id = None

        if not self.workout_saved:

            connection = None
            cursor = None

            try:

                connection = get_connection()

                cursor = connection.cursor()

                query = """
                    INSERT INTO workouts (
                        exercise,
                        total_reps,
                        correct_reps,
                        incorrect_reps,
                        form_score,
                        duration_seconds,
                        good_form_seconds
                    )
                    VALUES (
                        %s, %s, %s, %s,
                        %s, %s, %s
                    )
                """

                values = (
                    "Plank",
                    0,
                    0,
                    0,
                    form_score,
                    duration_seconds,
                    good_form_seconds
                )

                cursor.execute(
                    query,
                    values
                )

                connection.commit()

                workout_id = cursor.lastrowid

                self.workout_saved = True

                print(
                    "Plank workout saved:",
                    workout_id
                )

            except Exception as error:

                print(
                    "Error saving plank workout:",
                    error
                )

            finally:

                if cursor is not None:
                    cursor.close()

                if connection is not None:
                    connection.close()

        return {
            "success": True,
            "exercise": "Plank",
            "workout_id": workout_id,
            "good_form_seconds": good_form_seconds,
            "duration": duration_seconds,
            "form_score": form_score
        }