import cv2
import mediapipe as mp
import math
import time
from collections import deque

from database import get_connection


def calculate_angle(a, b, c):
    angle = math.degrees(
        math.atan2(c[1] - b[1], c[0] - b[0]) -
        math.atan2(a[1] - b[1], a[0] - b[0])
    )

    angle = abs(angle)

    if angle > 180:
        angle = 360 - angle

    return angle


# =========================
# CAMERA
# =========================

cap = cv2.VideoCapture(0)

mp_pose = mp.solutions.pose

pose = mp_pose.Pose(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

mp_draw = mp.solutions.drawing_utils


# =========================
# VARIABLES
# =========================

feedback = "GET INTO PLANK POSITION"

angle_history = deque(maxlen=5)

good_hold_time = 0.0

last_frame_time = time.time()

session_start = time.time()


# =========================
# MAIN LOOP
# =========================

while True:

    success, frame = cap.read()

    if not success:
        print("Could not access camera")
        break


    current_time = time.time()

    frame_delta = (
        current_time -
        last_frame_time
    )

    last_frame_time = current_time


    frame = cv2.flip(
        frame,
        1
    )


    rgb = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )


    result = pose.process(rgb)


    # =========================
    # SESSION TIMER
    # =========================

    session_time = (
        current_time -
        session_start
    )


    session_minutes = int(
        session_time // 60
    )


    session_seconds = int(
        session_time % 60
    )


    session_text = (
        f"{session_minutes:02d}:"
        f"{session_seconds:02d}"
    )


    if result.pose_landmarks:

        mp_draw.draw_landmarks(
            frame,
            result.pose_landmarks,
            mp_pose.POSE_CONNECTIONS
        )


        lm = (
            result
            .pose_landmarks
            .landmark
        )


        # =========================
        # LEFT SIDE LANDMARKS
        # =========================

        shoulder = [
            lm[
                mp_pose
                .PoseLandmark
                .LEFT_SHOULDER
                .value
            ].x,

            lm[
                mp_pose
                .PoseLandmark
                .LEFT_SHOULDER
                .value
            ].y
        ]


        hip = [
            lm[
                mp_pose
                .PoseLandmark
                .LEFT_HIP
                .value
            ].x,

            lm[
                mp_pose
                .PoseLandmark
                .LEFT_HIP
                .value
            ].y
        ]


        ankle = [
            lm[
                mp_pose
                .PoseLandmark
                .LEFT_ANKLE
                .value
            ].x,

            lm[
                mp_pose
                .PoseLandmark
                .LEFT_ANKLE
                .value
            ].y
        ]


        # =========================
        # VISIBILITY
        # =========================

        visible = (

            lm[
                mp_pose
                .PoseLandmark
                .LEFT_SHOULDER
                .value
            ].visibility > 0.5

            and

            lm[
                mp_pose
                .PoseLandmark
                .LEFT_HIP
                .value
            ].visibility > 0.5

            and

            lm[
                mp_pose
                .PoseLandmark
                .LEFT_ANKLE
                .value
            ].visibility > 0.5
        )


        if visible:

            # =========================
            # BODY ANGLE
            # =========================

            raw_angle = calculate_angle(
                shoulder,
                hip,
                ankle
            )


            angle_history.append(
                raw_angle
            )


            body_angle = (
                sum(angle_history) /
                len(angle_history)
            )


            # =========================
            # CHECK PLANK POSITION
            # =========================

            horizontal_body = (

                abs(
                    shoulder[1] -
                    ankle[1]
                )

                < 0.30
            )


            # =========================
            # STRICT FORM DETECTION
            # =========================

            good_form = False


            if not horizontal_body:

                feedback = (
                    "GET INTO PLANK POSITION"
                )

                body_color = (
                    0,
                    165,
                    255
                )


            elif body_angle >= 175:

                feedback = (
                    "GOOD PLANK"
                )

                body_color = (
                    0,
                    255,
                    0
                )

                good_form = True


            elif hip[1] < (
                shoulder[1] +
                ankle[1]
            ) / 2:

                feedback = (
                    "LOWER YOUR HIPS"
                )

                body_color = (
                    0,
                    0,
                    255
                )


            else:

                feedback = (
                    "RAISE YOUR HIPS"
                )

                body_color = (
                    0,
                    0,
                    255
                )


            # =========================
            # GOOD FORM TIMER
            # =========================

            if good_form:

                good_hold_time += (
                    frame_delta
                )


            hold_minutes = int(
                good_hold_time // 60
            )


            hold_seconds = int(
                good_hold_time % 60
            )


            hold_text = (
                f"{hold_minutes:02d}:"
                f"{hold_seconds:02d}"
            )


            # =========================
            # PIXEL POSITIONS
            # =========================

            h, w, _ = frame.shape


            shoulder_px = (
                int(shoulder[0] * w),
                int(shoulder[1] * h)
            )


            hip_px = (
                int(hip[0] * w),
                int(hip[1] * h)
            )


            ankle_px = (
                int(ankle[0] * w),
                int(ankle[1] * h)
            )


            # =========================
            # BODY LINES
            # =========================

            cv2.line(
                frame,
                shoulder_px,
                hip_px,
                body_color,
                8
            )


            cv2.line(
                frame,
                hip_px,
                ankle_px,
                body_color,
                8
            )


            cv2.circle(
                frame,
                hip_px,
                15,
                body_color,
                -1
            )


            # =========================
            # CORRECTION ARROWS
            # =========================

            if feedback == "LOWER YOUR HIPS":

                cv2.arrowedLine(
                    frame,

                    (
                        hip_px[0] + 40,
                        hip_px[1] - 60
                    ),

                    (
                        hip_px[0] + 40,
                        hip_px[1] + 50
                    ),

                    (0, 0, 255),

                    5,

                    tipLength=0.25
                )


            elif feedback == "RAISE YOUR HIPS":

                cv2.arrowedLine(
                    frame,

                    (
                        hip_px[0] + 40,
                        hip_px[1] + 60
                    ),

                    (
                        hip_px[0] + 40,
                        hip_px[1] - 50
                    ),

                    (0, 0, 255),

                    5,

                    tipLength=0.25
                )


            # =========================
            # PANEL
            # =========================

            cv2.rectangle(
                frame,
                (0, 0),
                (680, 290),
                (30, 30, 30),
                -1
            )


            cv2.putText(
                frame,
                "AI GYM TRAINER - PLANK",
                (20, 35),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "GOOD FORM HOLD: " +
                hold_text,
                (20, 85),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.9,
                (0, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "SESSION TIME: " +
                session_text,
                (20, 125),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "CORRECTION: " +
                feedback,
                (20, 170),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                body_color,
                2
            )


            cv2.putText(
                frame,
                "BODY ANGLE: " +
                str(int(body_angle)),
                (20, 215),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "TARGET: 175 - 180 degrees",
                (20, 250),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (255, 255, 255),
                1
            )


            if good_form:

                status = (
                    "TIMER RUNNING"
                )

                status_color = (
                    0,
                    255,
                    0
                )


            else:

                status = (
                    "TIMER PAUSED"
                )

                status_color = (
                    0,
                    165,
                    255
                )


            cv2.putText(
                frame,
                status,
                (20, 280),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                status_color,
                2
            )


        else:

            cv2.putText(
                frame,
                "KEEP FULL SIDE OF BODY VISIBLE",
                (20, 50),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 0, 255),
                2
            )


    else:

        cv2.putText(
            frame,
            "BODY NOT DETECTED",
            (20, 50),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 0, 255),
            2
        )


    cv2.imshow(
        "AI Gym Trainer - Plank",
        frame
    )


    if (
        cv2.waitKey(1) &
        0xFF
        ==
        ord("q")
    ):
        break


# =========================
# FINISH
# =========================

cap.release()

pose.close()

cv2.destroyAllWindows()


# =========================
# FINAL RESULTS
# =========================

total_session_time = (
    time.time() -
    session_start
)


if total_session_time > 0:

    form_score = round(
        (
            good_hold_time /
            total_session_time
        ) * 100,
        1
    )

else:

    form_score = 0


good_form_seconds = round(
    good_hold_time,
    2
)

duration_seconds = round(
    total_session_time,
    2
)


# =========================
# SAVE TO MYSQL
# =========================

connection = None
cursor = None

workout_id = None


try:

    connection = get_connection()

    cursor = connection.cursor()


    query = """
        INSERT INTO workouts (
            exercise,
            total_reps,
            correct_reps,
            incorrect_reps,
            form_score,
            duration_seconds,
            good_form_seconds
        )
        VALUES (%s, %s, %s, %s, %s, %s, %s)
    """


    values = (
        "Plank",
        0,
        0,
        0,
        form_score,
        duration_seconds,
        good_form_seconds
    )


    cursor.execute(
        query,
        values
    )


    connection.commit()


    workout_id = (
        cursor.lastrowid
    )


except Exception as e:

    print(
        "Error saving plank workout:"
    )

    print(e)


finally:

    if cursor is not None:
        cursor.close()


    if (
        connection is not None
        and
        connection.is_connected()
    ):

        connection.close()


# =========================
# PRINT SUMMARY
# =========================

print()

print(
    "=============================="
)

print(
    "       PLANK SUMMARY"
)

print(
    "=============================="
)


if workout_id is not None:

    print(
        "Workout ID:",
        workout_id
    )


print(
    "Good Form Hold:",
    good_form_seconds,
    "seconds"
)


print(
    "Total Session:",
    duration_seconds,
    "seconds"
)


print(
    "Form Score:",
    str(form_score) + "%"
)


print(
    "=============================="
)


if workout_id is not None:

    print(
        "Workout saved to MySQL!"
    )

else:

    print(
        "Workout was not saved."
    )