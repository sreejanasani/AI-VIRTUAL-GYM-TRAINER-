import cv2
import mediapipe as mp
import math
from collections import deque

from workout_tracker import WorkoutTracker


def calculate_angle(a, b, c):
    angle = math.degrees(
        math.atan2(c[1] - b[1], c[0] - b[0]) -
        math.atan2(a[1] - b[1], a[0] - b[0])
    )

    angle = abs(angle)

    if angle > 180:
        angle = 360 - angle

    return angle


# -------------------------
# CAMERA
# -------------------------

cap = cv2.VideoCapture(0)

mp_pose = mp.solutions.pose

pose = mp_pose.Pose(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

mp_draw = mp.solutions.drawing_utils


# -------------------------
# VARIABLES
# -------------------------

reps = 0
incorrect = 0

stage = None
feedback = "GET READY"
correction = "GET READY"

reached_top = False
bad_form_during_rep = False

tracker = WorkoutTracker("Shoulder Press")


# -------------------------
# SMOOTHING
# -------------------------

left_history = deque(maxlen=5)
right_history = deque(maxlen=5)


# -------------------------
# MAIN LOOP
# -------------------------

while True:

    success, frame = cap.read()

    if not success:
        print("Could not access camera")
        break

    frame = cv2.flip(frame, 1)

    rgb = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )

    result = pose.process(rgb)


    # -------------------------
    # TIMER
    # -------------------------

    elapsed = tracker.get_duration()

    minutes = int(elapsed // 60)
    seconds = int(elapsed % 60)

    timer_text = f"{minutes:02d}:{seconds:02d}"


    if result.pose_landmarks:

        mp_draw.draw_landmarks(
            frame,
            result.pose_landmarks,
            mp_pose.POSE_CONNECTIONS
        )

        lm = result.pose_landmarks.landmark


        # -------------------------
        # LEFT ARM
        # -------------------------

        left_shoulder = [
            lm[
                mp_pose.PoseLandmark.LEFT_SHOULDER.value
            ].x,
            lm[
                mp_pose.PoseLandmark.LEFT_SHOULDER.value
            ].y
        ]

        left_elbow = [
            lm[
                mp_pose.PoseLandmark.LEFT_ELBOW.value
            ].x,
            lm[
                mp_pose.PoseLandmark.LEFT_ELBOW.value
            ].y
        ]

        left_wrist = [
            lm[
                mp_pose.PoseLandmark.LEFT_WRIST.value
            ].x,
            lm[
                mp_pose.PoseLandmark.LEFT_WRIST.value
            ].y
        ]


        # -------------------------
        # RIGHT ARM
        # -------------------------

        right_shoulder = [
            lm[
                mp_pose.PoseLandmark.RIGHT_SHOULDER.value
            ].x,
            lm[
                mp_pose.PoseLandmark.RIGHT_SHOULDER.value
            ].y
        ]

        right_elbow = [
            lm[
                mp_pose.PoseLandmark.RIGHT_ELBOW.value
            ].x,
            lm[
                mp_pose.PoseLandmark.RIGHT_ELBOW.value
            ].y
        ]

        right_wrist = [
            lm[
                mp_pose.PoseLandmark.RIGHT_WRIST.value
            ].x,
            lm[
                mp_pose.PoseLandmark.RIGHT_WRIST.value
            ].y
        ]


        # -------------------------
        # VISIBILITY
        # -------------------------

        visible = (
            lm[
                mp_pose.PoseLandmark.LEFT_SHOULDER.value
            ].visibility > 0.5
            and
            lm[
                mp_pose.PoseLandmark.LEFT_ELBOW.value
            ].visibility > 0.5
            and
            lm[
                mp_pose.PoseLandmark.LEFT_WRIST.value
            ].visibility > 0.5
            and
            lm[
                mp_pose.PoseLandmark.RIGHT_SHOULDER.value
            ].visibility > 0.5
            and
            lm[
                mp_pose.PoseLandmark.RIGHT_ELBOW.value
            ].visibility > 0.5
            and
            lm[
                mp_pose.PoseLandmark.RIGHT_WRIST.value
            ].visibility > 0.5
        )


        if visible:

            # -------------------------
            # ELBOW ANGLES
            # -------------------------

            raw_left_angle = calculate_angle(
                left_shoulder,
                left_elbow,
                left_wrist
            )

            raw_right_angle = calculate_angle(
                right_shoulder,
                right_elbow,
                right_wrist
            )


            left_history.append(
                raw_left_angle
            )

            right_history.append(
                raw_right_angle
            )


            left_angle = (
                sum(left_history) /
                len(left_history)
            )

            right_angle = (
                sum(right_history) /
                len(right_history)
            )


            average_angle = (
                left_angle +
                right_angle
            ) / 2


            # -------------------------
            # WRIST POSITION
            # -------------------------

            wrists_above_shoulders = (
                left_wrist[1] <
                left_shoulder[1]
                and
                right_wrist[1] <
                right_shoulder[1]
            )


            # -------------------------
            # ARM ASYMMETRY
            # -------------------------

            angle_difference = abs(
                left_angle -
                right_angle
            )


            arms_uneven = (
                angle_difference > 25
                and average_angle > 110
            )


            if arms_uneven:
                bad_form_during_rep = True


            # -------------------------
            # ORIGINAL REP LOGIC
            # -------------------------

            # LOWERED POSITION
            if average_angle < 110:

                if (
                    stage == "UP"
                    and reached_top
                ):

                    reps += 1


                    if bad_form_during_rep:

                        incorrect += 1

                        feedback = (
                            "REP COMPLETED - FORM ISSUE"
                        )

                    else:

                        feedback = "GOOD REP"


                    print(
                        "Shoulder Press:",
                        reps
                    )


                else:

                    feedback = "PRESS UP"


                stage = "DOWN"
                reached_top = False
                bad_form_during_rep = False


            # FULL EXTENSION
            elif (
                average_angle > 155
                and wrists_above_shoulders
            ):

                stage = "UP"
                reached_top = True

                feedback = (
                    "GOOD - LOWER SLOWLY"
                )


            # MIDDLE
            else:

                if stage == "DOWN":

                    feedback = (
                        "KEEP PRESSING"
                    )


                elif stage == "UP":

                    feedback = (
                        "LOWER SLOWLY"
                    )


                else:

                    feedback = (
                        "START WITH ARMS BENT"
                    )


            # -------------------------
            # REAL-TIME CORRECTION
            # -------------------------

            if arms_uneven:

                correction = (
                    "KEEP ARMS EVEN"
                )


            elif stage == "DOWN":

                if average_angle < 120:

                    correction = (
                        "PRESS UP"
                    )


                elif average_angle < 150:

                    correction = (
                        "EXTEND ARMS FULLY"
                    )


                else:

                    correction = (
                        "KEEP PRESSING"
                    )


            elif stage == "UP":

                correction = (
                    "LOWER SLOWLY"
                )


            else:

                correction = (
                    "START WITH ARMS BENT"
                )


            # -------------------------
            # FORM SCORE
            # -------------------------

            correct_reps = (
                reps - incorrect
            )

            if correct_reps < 0:
                correct_reps = 0


            form_score = (
                tracker.get_form_score(
                    correct_reps,
                    incorrect
                )
            )


            # -------------------------
            # PIXEL POSITIONS
            # -------------------------

            h, w, _ = frame.shape


            left_shoulder_px = (
                int(left_shoulder[0] * w),
                int(left_shoulder[1] * h)
            )

            left_elbow_px = (
                int(left_elbow[0] * w),
                int(left_elbow[1] * h)
            )

            left_wrist_px = (
                int(left_wrist[0] * w),
                int(left_wrist[1] * h)
            )


            right_shoulder_px = (
                int(right_shoulder[0] * w),
                int(right_shoulder[1] * h)
            )

            right_elbow_px = (
                int(right_elbow[0] * w),
                int(right_elbow[1] * h)
            )

            right_wrist_px = (
                int(right_wrist[0] * w),
                int(right_wrist[1] * h)
            )


            # -------------------------
            # VISUAL CORRECTION
            # -------------------------

            if arms_uneven:

                # Highlight both arms red
                cv2.line(
                    frame,
                    left_shoulder_px,
                    left_elbow_px,
                    (0, 0, 255),
                    7
                )

                cv2.line(
                    frame,
                    left_elbow_px,
                    left_wrist_px,
                    (0, 0, 255),
                    7
                )

                cv2.line(
                    frame,
                    right_shoulder_px,
                    right_elbow_px,
                    (0, 0, 255),
                    7
                )

                cv2.line(
                    frame,
                    right_elbow_px,
                    right_wrist_px,
                    (0, 0, 255),
                    7
                )


            elif correction in [
                "PRESS UP",
                "EXTEND ARMS FULLY",
                "KEEP PRESSING"
            ]:

                # Up arrows beside both wrists
                cv2.arrowedLine(
                    frame,
                    (
                        left_wrist_px[0] - 30,
                        left_wrist_px[1] + 60
                    ),
                    (
                        left_wrist_px[0] - 30,
                        left_wrist_px[1] - 30
                    ),
                    (0, 165, 255),
                    5,
                    tipLength=0.25
                )


                cv2.arrowedLine(
                    frame,
                    (
                        right_wrist_px[0] + 30,
                        right_wrist_px[1] + 60
                    ),
                    (
                        right_wrist_px[0] + 30,
                        right_wrist_px[1] - 30
                    ),
                    (0, 165, 255),
                    5,
                    tipLength=0.25
                )


            elif correction == "LOWER SLOWLY":

                # Down arrows
                cv2.arrowedLine(
                    frame,
                    (
                        left_wrist_px[0] - 30,
                        left_wrist_px[1] - 30
                    ),
                    (
                        left_wrist_px[0] - 30,
                        left_wrist_px[1] + 60
                    ),
                    (0, 255, 0),
                    5,
                    tipLength=0.25
                )


                cv2.arrowedLine(
                    frame,
                    (
                        right_wrist_px[0] + 30,
                        right_wrist_px[1] - 30
                    ),
                    (
                        right_wrist_px[0] + 30,
                        right_wrist_px[1] + 60
                    ),
                    (0, 255, 0),
                    5,
                    tipLength=0.25
                )


            # -------------------------
            # ELBOW ANGLES
            # -------------------------

            cv2.putText(
                frame,
                str(int(left_angle)),
                left_elbow_px,
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                str(int(right_angle)),
                right_elbow_px,
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )


            # -------------------------
            # PANEL
            # -------------------------

            cv2.rectangle(
                frame,
                (0, 0),
                (720, 350),
                (30, 30, 30),
                -1
            )


            cv2.putText(
                frame,
                "AI GYM TRAINER - SHOULDER PRESS",
                (20, 35),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "REPS: " + str(reps),
                (20, 75),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (0, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "FORM ISSUES: " +
                str(incorrect),
                (190, 75),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "FORM SCORE: " +
                str(form_score) +
                "%",
                (20, 115),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "TIME: " +
                timer_text,
                (350, 115),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "POSITION: " +
                str(stage),
                (20, 155),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "MOVEMENT: " +
                feedback,
                (20, 195),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "CORRECTION:",
                (20, 235),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )


            if arms_uneven:

                correction_color = (
                    0,
                    0,
                    255
                )

            elif correction == "LOWER SLOWLY":

                correction_color = (
                    0,
                    255,
                    0
                )

            else:

                correction_color = (
                    0,
                    165,
                    255
                )


            cv2.putText(
                frame,
                correction,
                (20, 275),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.75,
                correction_color,
                2
            )


            cv2.putText(
                frame,
                "LEFT: " +
                str(int(left_angle)) +
                "   RIGHT: " +
                str(int(right_angle)) +
                "   DIFFERENCE: " +
                str(int(angle_difference)),
                (20, 315),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (255, 255, 255),
                1
            )


            cv2.putText(
                frame,
                "Press Q to finish workout",
                (20, 340),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (255, 255, 255),
                1
            )


        else:

            cv2.putText(
                frame,
                "KEEP BOTH ARMS VISIBLE",
                (20, 50),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 0, 255),
                2
            )


    else:

        cv2.putText(
            frame,
            "BODY NOT DETECTED",
            (20, 50),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 0, 255),
            2
        )


    cv2.imshow(
        "AI Gym Trainer - Shoulder Press",
        frame
    )


    if cv2.waitKey(1) & 0xFF == ord("q"):
        break


# -------------------------
# FINISH WORKOUT
# -------------------------

cap.release()
pose.close()
cv2.destroyAllWindows()


correct_reps = reps - incorrect

if correct_reps < 0:
    correct_reps = 0


workout = tracker.save_workout(
    correct_reps,
    incorrect
)

tracker.print_summary(
    workout
)