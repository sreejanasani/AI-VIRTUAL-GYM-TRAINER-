import cv2
import mediapipe as mp
import math
from collections import deque

from workout_tracker import WorkoutTracker


def calculate_angle(a, b, c):
    angle = math.degrees(
        math.atan2(c[1] - b[1], c[0] - b[0]) -
        math.atan2(a[1] - b[1], a[0] - b[0])
    )

    angle = abs(angle)

    if angle > 180:
        angle = 360 - angle

    return angle


def calculate_torso_angle(shoulder, hip):
    dx = shoulder[0] - hip[0]
    dy = hip[1] - shoulder[1]

    if dy <= 0:
        return 0

    angle = math.degrees(
        math.atan2(abs(dx), abs(dy))
    )

    return angle


# -------------------------
# CAMERA
# -------------------------

cap = cv2.VideoCapture(0)

mp_pose = mp.solutions.pose

pose = mp_pose.Pose(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

mp_draw = mp.solutions.drawing_utils


# -------------------------
# VARIABLES
# -------------------------

reps = 0
incorrect = 0

stage = None

feedback = "GET READY"
correction = "GET READY"

reached_depth = False
bad_form_during_rep = False

tracker = WorkoutTracker("Lunge")


# -------------------------
# SMOOTHING
# -------------------------

left_history = deque(maxlen=5)
right_history = deque(maxlen=5)
torso_history = deque(maxlen=5)


# -------------------------
# MAIN LOOP
# -------------------------

while True:

    success, frame = cap.read()

    if not success:
        print("Could not access camera")
        break

    frame = cv2.flip(frame, 1)

    rgb = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )

    result = pose.process(rgb)


    # -------------------------
    # TIMER
    # -------------------------

    elapsed = tracker.get_duration()

    minutes = int(elapsed // 60)
    seconds = int(elapsed % 60)

    timer_text = f"{minutes:02d}:{seconds:02d}"


    if result.pose_landmarks:

        mp_draw.draw_landmarks(
            frame,
            result.pose_landmarks,
            mp_pose.POSE_CONNECTIONS
        )

        lm = result.pose_landmarks.landmark


        # -------------------------
        # LANDMARK OBJECTS
        # -------------------------

        ls = lm[
            mp_pose.PoseLandmark.LEFT_SHOULDER.value
        ]

        rs = lm[
            mp_pose.PoseLandmark.RIGHT_SHOULDER.value
        ]

        lh = lm[
            mp_pose.PoseLandmark.LEFT_HIP.value
        ]

        rh = lm[
            mp_pose.PoseLandmark.RIGHT_HIP.value
        ]

        lk = lm[
            mp_pose.PoseLandmark.LEFT_KNEE.value
        ]

        rk = lm[
            mp_pose.PoseLandmark.RIGHT_KNEE.value
        ]

        la = lm[
            mp_pose.PoseLandmark.LEFT_ANKLE.value
        ]

        ra = lm[
            mp_pose.PoseLandmark.RIGHT_ANKLE.value
        ]


        # -------------------------
        # COORDINATES
        # -------------------------

        left_shoulder = [ls.x, ls.y]
        right_shoulder = [rs.x, rs.y]

        left_hip = [lh.x, lh.y]
        right_hip = [rh.x, rh.y]

        left_knee = [lk.x, lk.y]
        right_knee = [rk.x, rk.y]

        left_ankle = [la.x, la.y]
        right_ankle = [ra.x, ra.y]


        # -------------------------
        # VISIBILITY
        # -------------------------

        left_visibility = min(
            ls.visibility,
            lh.visibility,
            lk.visibility,
            la.visibility
        )

        right_visibility = min(
            rs.visibility,
            rh.visibility,
            rk.visibility,
            ra.visibility
        )


        if (
            left_visibility > 0.5
            and right_visibility > 0.5
        ):

            # -------------------------
            # KNEE ANGLES
            # -------------------------

            raw_left_angle = calculate_angle(
                left_hip,
                left_knee,
                left_ankle
            )

            raw_right_angle = calculate_angle(
                right_hip,
                right_knee,
                right_ankle
            )


            left_history.append(
                raw_left_angle
            )

            right_history.append(
                raw_right_angle
            )


            left_angle = (
                sum(left_history) /
                len(left_history)
            )

            right_angle = (
                sum(right_history) /
                len(right_history)
            )


            active_angle = min(
                left_angle,
                right_angle
            )


            # -------------------------
            # CHOOSE BODY SIDE
            # -------------------------

            if left_visibility >= right_visibility:

                torso_shoulder = left_shoulder
                torso_hip = left_hip

                body_side = "LEFT"

            else:

                torso_shoulder = right_shoulder
                torso_hip = right_hip

                body_side = "RIGHT"


            # -------------------------
            # TORSO ANGLE
            # -------------------------

            raw_torso_angle = calculate_torso_angle(
                torso_shoulder,
                torso_hip
            )


            torso_history.append(
                raw_torso_angle
            )


            torso_angle = (
                sum(torso_history) /
                len(torso_history)
            )


            # -------------------------
            # LUNGE DETECTION
            # -------------------------

            in_lunge = active_angle < 150


            # -------------------------
            # TORSO FORM
            # -------------------------

            torso_bad = (
                in_lunge
                and torso_angle > 20
            )


            if torso_bad:
                bad_form_during_rep = True


            # -------------------------
            # REP LOGIC
            # -------------------------

            if (
                left_angle > 155
                and right_angle > 155
            ):

                if stage == "DOWN":

                    if reached_depth:

                        reps += 1

                        if bad_form_during_rep:

                            incorrect += 1

                            feedback = (
                                "REP COMPLETED - FORM ISSUE"
                            )

                        else:

                            feedback = "GOOD REP"

                        print(
                            "Lunge:",
                            reps
                        )

                    else:

                        incorrect += 1

                        feedback = (
                            "INCOMPLETE - GO LOWER"
                        )


                else:

                    feedback = "READY"


                stage = "UP"

                reached_depth = False
                bad_form_during_rep = False


            elif active_angle < 105:

                stage = "DOWN"

                reached_depth = True

                feedback = (
                    "GOOD DEPTH - COME UP"
                )


            else:

                if stage == "UP":

                    stage = "DOWN"

                    feedback = "GO LOWER"


                elif stage == "DOWN":

                    if reached_depth:

                        feedback = "COME UP"

                    else:

                        feedback = "GO LOWER"


                else:

                    feedback = "START STANDING"


            # -------------------------
            # CORRECTION
            # -------------------------

            if torso_bad:

                correction = (
                    "KEEP TORSO UPRIGHT"
                )


            elif (
                left_angle > 155
                and right_angle > 155
            ):

                correction = (
                    "READY - START LUNGE"
                )


            elif not reached_depth:

                if active_angle > 130:

                    correction = "GO LOWER"

                else:

                    correction = (
                        "A LITTLE LOWER"
                    )


            else:

                correction = "STAND UP"


            # -------------------------
            # FORM SCORE
            # -------------------------

            correct_reps = reps - incorrect

            if correct_reps < 0:
                correct_reps = 0


            form_score = (
                tracker.get_form_score(
                    correct_reps,
                    incorrect
                )
            )


            # -------------------------
            # PIXEL POSITIONS
            # -------------------------

            h, w, _ = frame.shape


            shoulder_px = (
                int(torso_shoulder[0] * w),
                int(torso_shoulder[1] * h)
            )


            hip_px = (
                int(torso_hip[0] * w),
                int(torso_hip[1] * h)
            )


            left_knee_px = (
                int(left_knee[0] * w),
                int(left_knee[1] * h)
            )


            right_knee_px = (
                int(right_knee[0] * w),
                int(right_knee[1] * h)
            )


            # -------------------------
            # TORSO LINE
            # -------------------------

            if torso_bad:

                torso_color = (
                    0,
                    0,
                    255
                )

            else:

                torso_color = (
                    0,
                    255,
                    0
                )


            cv2.line(
                frame,
                shoulder_px,
                hip_px,
                torso_color,
                10
            )


            cv2.circle(
                frame,
                shoulder_px,
                13,
                torso_color,
                -1
            )


            cv2.circle(
                frame,
                hip_px,
                13,
                torso_color,
                -1
            )


            # -------------------------
            # TORSO TARGET
            # -------------------------

            if torso_bad:

                torso_height = abs(
                    shoulder_px[1] -
                    hip_px[1]
                )


                target_shoulder = (
                    hip_px[0],
                    hip_px[1] -
                    torso_height
                )


                # Correct vertical position
                cv2.line(
                    frame,
                    hip_px,
                    target_shoulder,
                    (0, 255, 0),
                    5
                )


                # Move shoulder toward target
                cv2.arrowedLine(
                    frame,
                    shoulder_px,
                    target_shoulder,
                    (0, 0, 255),
                    6,
                    tipLength=0.25
                )


            # -------------------------
            # DEPTH ARROW
            # -------------------------

            elif correction in [
                "GO LOWER",
                "A LITTLE LOWER"
            ]:

                if left_angle < right_angle:

                    active_knee_px = (
                        left_knee_px
                    )

                else:

                    active_knee_px = (
                        right_knee_px
                    )


                cv2.circle(
                    frame,
                    active_knee_px,
                    15,
                    (0, 165, 255),
                    -1
                )


                cv2.arrowedLine(
                    frame,
                    (
                        active_knee_px[0] + 40,
                        active_knee_px[1] - 50
                    ),
                    (
                        active_knee_px[0] + 40,
                        active_knee_px[1] + 50
                    ),
                    (0, 165, 255),
                    5,
                    tipLength=0.25
                )


            # -------------------------
            # STAND-UP ARROW
            # -------------------------

            elif correction == "STAND UP":

                cv2.arrowedLine(
                    frame,
                    (
                        hip_px[0] + 40,
                        hip_px[1]
                    ),
                    (
                        hip_px[0] + 40,
                        hip_px[1] - 80
                    ),
                    (0, 255, 0),
                    5,
                    tipLength=0.25
                )


            # -------------------------
            # KNEE ANGLES
            # -------------------------

            cv2.putText(
                frame,
                str(int(left_angle)),
                left_knee_px,
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                str(int(right_angle)),
                right_knee_px,
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )


            # -------------------------
            # PANEL
            # -------------------------

            cv2.rectangle(
                frame,
                (0, 0),
                (720, 390),
                (30, 30, 30),
                -1
            )


            cv2.putText(
                frame,
                "AI GYM TRAINER - LUNGE",
                (20, 35),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "REPS: " + str(reps),
                (20, 75),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (0, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "FORM ISSUES: " +
                str(incorrect),
                (190, 75),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "FORM SCORE: " +
                str(form_score) +
                "%",
                (20, 115),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "TIME: " +
                timer_text,
                (350, 115),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "POSITION: " +
                str(stage),
                (20, 155),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "MOVEMENT: " +
                feedback,
                (20, 195),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "CORRECTION:",
                (20, 235),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )


            if torso_bad:

                correction_color = (
                    0,
                    0,
                    255
                )

            elif correction == "STAND UP":

                correction_color = (
                    0,
                    255,
                    0
                )

            else:

                correction_color = (
                    0,
                    165,
                    255
                )


            cv2.putText(
                frame,
                correction,
                (20, 275),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.75,
                correction_color,
                2
            )


            cv2.putText(
                frame,
                "LEFT KNEE: " +
                str(int(left_angle)) +
                "   RIGHT KNEE: " +
                str(int(right_angle)),
                (20, 315),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (255, 255, 255),
                1
            )


            cv2.putText(
                frame,
                "TORSO ANGLE: " +
                str(int(torso_angle)) +
                " deg",
                (20, 345),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "TRACKING SIDE: " +
                body_side,
                (300, 345),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (255, 255, 255),
                1
            )


            cv2.putText(
                frame,
                "Torso correction threshold: 20 deg",
                (20, 375),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (255, 255, 255),
                1
            )


        else:

            cv2.putText(
                frame,
                "KEEP FULL BODY AND BOTH LEGS VISIBLE",
                (20, 50),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (0, 0, 255),
                2
            )


    else:

        cv2.putText(
            frame,
            "BODY NOT DETECTED",
            (20, 50),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 0, 255),
            2
        )


    cv2.imshow(
        "AI Gym Trainer - Lunge",
        frame
    )


    if cv2.waitKey(1) & 0xFF == ord("q"):
        break


# -------------------------
# FINISH WORKOUT
# -------------------------

cap.release()
pose.close()
cv2.destroyAllWindows()


correct_reps = reps - incorrect

if correct_reps < 0:
    correct_reps = 0


workout = tracker.save_workout(
    correct_reps,
    incorrect
)

tracker.print_summary(
    workout
)