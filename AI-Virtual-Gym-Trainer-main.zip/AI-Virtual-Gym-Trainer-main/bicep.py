import cv2
import mediapipe as mp
import math
import threading
from collections import deque

from workout_tracker import WorkoutTracker


def calculate_angle(a, b, c):
    angle = math.degrees(
        math.atan2(c[1] - b[1], c[0] - b[0])
        - math.atan2(a[1] - b[1], a[0] - b[0])
    )

    angle = abs(angle)

    if angle > 180:
        angle = 360 - angle

    return angle


def calculate_upper_arm_angle(shoulder, elbow):
    dx = elbow[0] - shoulder[0]
    dy = elbow[1] - shoulder[1]

    return math.degrees(
        math.atan2(abs(dx), abs(dy))
    )


class BicepWorkout:

    def __init__(self):
        self.cap = None
        self.pose = None

        self.mp_pose = mp.solutions.pose
        self.mp_draw = mp.solutions.drawing_utils

        self.count = 0
        self.incorrect = 0

        self.stage = None

        self.feedback = "GET READY"
        self.correction = "GET READY"

        self.bad_form_during_rep = False

        self.elbow_angle_history = deque(maxlen=5)
        self.upper_arm_history = deque(maxlen=5)
        self.correction_history = deque(maxlen=6)

        self.tracker = None

        self.running = False
        self.saved = False

        self.lock = threading.Lock()


    def stable_correction(self, message):
        self.correction_history.append(message)

        if len(self.correction_history) < 4:
            return message

        return max(
            set(self.correction_history),
            key=self.correction_history.count
        )


    def start(self):
        with self.lock:

            if self.running:
                return True

            self.cap = cv2.VideoCapture(0)

            if not self.cap.isOpened():
                self.cap.release()
                self.cap = None
                return False

            self.pose = self.mp_pose.Pose(
                min_detection_confidence=0.5,
                min_tracking_confidence=0.5
            )

            self.count = 0
            self.incorrect = 0
            self.stage = None

            self.feedback = "GET READY"
            self.correction = "GET READY"

            self.bad_form_during_rep = False

            self.elbow_angle_history.clear()
            self.upper_arm_history.clear()
            self.correction_history.clear()

            self.tracker = WorkoutTracker(
                "Bicep Curl"
            )

            self.saved = False
            self.running = True

            return True


    def process_frame(self):

        if not self.running:
            return None

        if self.cap is None:
            return None

        success, frame = self.cap.read()

        if not success:
            return None

        frame = cv2.flip(frame, 1)

        rgb = cv2.cvtColor(
            frame,
            cv2.COLOR_BGR2RGB
        )

        result = self.pose.process(rgb)

        elapsed = self.tracker.get_duration()

        minutes = int(elapsed // 60)
        seconds = int(elapsed % 60)

        timer_text = (
            f"{minutes:02d}:{seconds:02d}"
        )


        if result.pose_landmarks:

            self.mp_draw.draw_landmarks(
                frame,
                result.pose_landmarks,
                self.mp_pose.POSE_CONNECTIONS
            )

            landmarks = (
                result.pose_landmarks.landmark
            )


            shoulder_landmark = landmarks[
                self.mp_pose.PoseLandmark.LEFT_SHOULDER.value
            ]

            elbow_landmark = landmarks[
                self.mp_pose.PoseLandmark.LEFT_ELBOW.value
            ]

            wrist_landmark = landmarks[
                self.mp_pose.PoseLandmark.LEFT_WRIST.value
            ]


            shoulder = [
                shoulder_landmark.x,
                shoulder_landmark.y
            ]

            elbow = [
                elbow_landmark.x,
                elbow_landmark.y
            ]

            wrist = [
                wrist_landmark.x,
                wrist_landmark.y
            ]


            arm_visible = (
                shoulder_landmark.visibility > 0.5
                and elbow_landmark.visibility > 0.5
                and wrist_landmark.visibility > 0.5
            )


            if arm_visible:

                raw_elbow_angle = calculate_angle(
                    shoulder,
                    elbow,
                    wrist
                )

                self.elbow_angle_history.append(
                    raw_elbow_angle
                )

                elbow_angle = (
                    sum(self.elbow_angle_history)
                    / len(self.elbow_angle_history)
                )


                raw_upper_arm_angle = (
                    calculate_upper_arm_angle(
                        shoulder,
                        elbow
                    )
                )

                self.upper_arm_history.append(
                    raw_upper_arm_angle
                )

                upper_arm_angle = (
                    sum(self.upper_arm_history)
                    / len(self.upper_arm_history)
                )


                upper_arm_swing = (
                    elbow_angle < 130
                    and upper_arm_angle > 30
                )


                # =========================
                # REP LOGIC
                # =========================

                if elbow_angle > 150:

                    if self.stage == "UP":

                        self.count += 1

                        if self.bad_form_during_rep:

                            self.incorrect += 1

                            self.feedback = (
                                "REP COMPLETED - FORM ISSUE"
                            )

                        else:

                            self.feedback = "GOOD REP"

                        print(
                            "Bicep Curl:",
                            self.count
                        )

                        self.bad_form_during_rep = False

                    else:

                        self.feedback = "CURL UP"

                    self.stage = "DOWN"


                elif elbow_angle < 50:

                    if self.stage == "DOWN":

                        self.stage = "UP"

                        self.feedback = "GOOD CURL"

                    else:

                        self.feedback = "LOWER ARM"


                else:

                    if self.stage == "DOWN":

                        self.feedback = "KEEP CURLING"

                    elif self.stage == "UP":

                        self.feedback = "LOWER SLOWLY"

                    else:

                        self.feedback = "STRAIGHTEN ARM"


                # =========================
                # REAL-TIME CORRECTION
                # =========================

                if upper_arm_swing:

                    raw_correction = (
                        "KEEP UPPER ARM STILL"
                    )

                    self.bad_form_during_rep = True


                elif self.stage is None:

                    raw_correction = (
                        "STRAIGHTEN YOUR ARM"
                    )


                elif self.stage == "DOWN":

                    if elbow_angle > 130:

                        raw_correction = "CURL UP"

                    elif elbow_angle > 80:

                        raw_correction = (
                            "KEEP CURLING"
                        )

                    elif elbow_angle >= 50:

                        raw_correction = (
                            "CURL HIGHER"
                        )

                    else:

                        raw_correction = "GOOD CURL"


                elif self.stage == "UP":

                    if elbow_angle < 70:

                        raw_correction = (
                            "LOWER SLOWLY"
                        )

                    elif elbow_angle < 130:

                        raw_correction = (
                            "KEEP LOWERING"
                        )

                    else:

                        raw_correction = (
                            "STRAIGHTEN YOUR ARM"
                        )

                else:

                    raw_correction = "GOOD FORM"


                self.correction = (
                    self.stable_correction(
                        raw_correction
                    )
                )


                correct_reps = (
                    self.count - self.incorrect
                )

                form_score = (
                    self.tracker.get_form_score(
                        correct_reps,
                        self.incorrect
                    )
                )


                # =========================
                # PIXEL POSITIONS
                # =========================

                height, width, _ = frame.shape

                shoulder_px = (
                    int(shoulder[0] * width),
                    int(shoulder[1] * height)
                )

                elbow_px = (
                    int(elbow[0] * width),
                    int(elbow[1] * height)
                )

                wrist_px = (
                    int(wrist[0] * width),
                    int(wrist[1] * height)
                )


                # =========================
                # VISUAL CORRECTIONS
                # =========================

                if (
                    self.correction
                    == "KEEP UPPER ARM STILL"
                ):

                    cv2.line(
                        frame,
                        shoulder_px,
                        elbow_px,
                        (0, 0, 255),
                        8
                    )

                    cv2.circle(
                        frame,
                        elbow_px,
                        18,
                        (0, 0, 255),
                        -1
                    )

                    target_elbow = (
                        shoulder_px[0],
                        shoulder_px[1] + 120
                    )

                    cv2.arrowedLine(
                        frame,
                        elbow_px,
                        target_elbow,
                        (0, 0, 255),
                        5,
                        tipLength=0.2
                    )


                elif self.correction in [
                    "CURL UP",
                    "KEEP CURLING",
                    "CURL HIGHER"
                ]:

                    cv2.circle(
                        frame,
                        elbow_px,
                        12,
                        (0, 165, 255),
                        -1
                    )

                    cv2.arrowedLine(
                        frame,
                        wrist_px,
                        shoulder_px,
                        (0, 165, 255),
                        5,
                        tipLength=0.15
                    )


                elif self.correction in [
                    "LOWER SLOWLY",
                    "KEEP LOWERING",
                    "STRAIGHTEN YOUR ARM"
                ]:

                    cv2.circle(
                        frame,
                        elbow_px,
                        12,
                        (0, 255, 0),
                        -1
                    )

                    arrow_end = (
                        wrist_px[0],
                        wrist_px[1] + 80
                    )

                    cv2.arrowedLine(
                        frame,
                        wrist_px,
                        arrow_end,
                        (0, 255, 0),
                        5,
                        tipLength=0.25
                    )


                cv2.putText(
                    frame,
                    str(int(elbow_angle)),
                    elbow_px,
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.8,
                    (255, 255, 255),
                    2
                )


                # =========================
                # INFORMATION PANEL
                # =========================

                cv2.rectangle(
                    frame,
                    (0, 0),
                    (690, 350),
                    (30, 30, 30),
                    -1
                )


                cv2.putText(
                    frame,
                    "AI GYM TRAINER - BICEP CURL",
                    (20, 35),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (255, 255, 255),
                    2
                )


                cv2.putText(
                    frame,
                    "REPS: " + str(self.count),
                    (20, 75),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    1,
                    (0, 255, 0),
                    2
                )


                cv2.putText(
                    frame,
                    "FORM ISSUES: "
                    + str(self.incorrect),
                    (200, 75),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.65,
                    (0, 255, 255),
                    2
                )


                cv2.putText(
                    frame,
                    "FORM SCORE: "
                    + str(form_score)
                    + "%",
                    (20, 115),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.65,
                    (0, 255, 0),
                    2
                )


                cv2.putText(
                    frame,
                    "TIME: " + timer_text,
                    (350, 115),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.65,
                    (255, 255, 255),
                    2
                )


                cv2.putText(
                    frame,
                    "POSITION: "
                    + str(self.stage),
                    (20, 155),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (255, 255, 0),
                    2
                )


                cv2.putText(
                    frame,
                    "MOVEMENT: "
                    + self.feedback,
                    (20, 195),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.65,
                    (255, 255, 0),
                    2
                )


                cv2.putText(
                    frame,
                    "CORRECTION:",
                    (20, 235),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.65,
                    (255, 255, 255),
                    2
                )


                if (
                    self.correction
                    == "KEEP UPPER ARM STILL"
                ):

                    correction_color = (
                        0,
                        0,
                        255
                    )

                elif (
                    self.correction
                    == "GOOD CURL"
                ):

                    correction_color = (
                        0,
                        255,
                        0
                    )

                else:

                    correction_color = (
                        0,
                        165,
                        255
                    )


                cv2.putText(
                    frame,
                    self.correction,
                    (20, 275),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.75,
                    correction_color,
                    2
                )


                cv2.putText(
                    frame,
                    "ELBOW ANGLE: "
                    + str(int(elbow_angle)),
                    (20, 315),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55,
                    (255, 255, 255),
                    1
                )


                cv2.putText(
                    frame,
                    "UPPER ARM: "
                    + str(int(upper_arm_angle))
                    + " deg",
                    (260, 315),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55,
                    (255, 255, 255),
                    1
                )


            else:

                cv2.putText(
                    frame,
                    "KEEP LEFT ARM VISIBLE",
                    (20, 50),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.8,
                    (0, 0, 255),
                    2
                )


        else:

            cv2.putText(
                frame,
                "BODY NOT DETECTED",
                (20, 50),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 0, 255),
                2
            )


        return frame


    def get_jpeg_frame(self):

        frame = self.process_frame()

        if frame is None:
            return None

        success, buffer = cv2.imencode(
            ".jpg",
            frame,
            [
                cv2.IMWRITE_JPEG_QUALITY,
                85
            ]
        )

        if not success:
            return None

        return buffer.tobytes()


    def get_status(self):

        correct_reps = (
            self.count - self.incorrect
        )

        form_score = 0

        duration = 0

        if self.tracker is not None:

            form_score = (
                self.tracker.get_form_score(
                    correct_reps,
                    self.incorrect
                )
            )

            duration = (
                self.tracker.get_duration()
            )


        return {
            "running": self.running,
            "exercise": "Bicep Curl",
            "reps": self.count,
            "correct_reps": correct_reps,
            "form_issues": self.incorrect,
            "form_score": form_score,
            "correction": self.correction,
            "movement": self.feedback,
            "stage": self.stage,
            "duration": round(duration, 2)
        }


    def stop(self):

        with self.lock:

            if not self.running:
                return None

            self.running = False


            if self.cap is not None:

                self.cap.release()

                self.cap = None


            if self.pose is not None:

                self.pose.close()

                self.pose = None


            if self.saved:
                return None


            self.saved = True


            correct_reps = (
                self.count - self.incorrect
            )


            workout = self.tracker.save_workout(
                correct_reps,
                self.incorrect
            )


            self.tracker.print_summary(
                workout
            )


            return workout