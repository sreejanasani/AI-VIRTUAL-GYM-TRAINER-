import cv2
import mediapipe as mp
import math
import time
import threading
from collections import deque
from workout_tracker import WorkoutTracker


def calculate_angle(a, b, c):
    angle = abs(math.degrees(math.atan2(c[1]-b[1], c[0]-b[0]) - math.atan2(a[1]-b[1], a[0]-b[0])))
    return 360-angle if angle > 180 else angle


def upper_arm_angle(shoulder, elbow):
    dx = elbow[0]-shoulder[0]
    dy = shoulder[1]-elbow[1]
    return 90 if dy <= 0 else math.degrees(math.atan2(abs(dx), abs(dy)))


def torso_angle(shoulder, hip):
    dx = shoulder[0]-hip[0]
    dy = hip[1]-shoulder[1]
    return 0 if dy <= 0 else math.degrees(math.atan2(abs(dx), abs(dy)))


class TricepExtensionWorkout:
    def __init__(self):
        self.mp_pose = mp.solutions.pose
        self.mp_draw = mp.solutions.drawing_utils
        self.cap = None
        self.pose = None
        self.thread = None
        self.lock = threading.Lock()
        self.frame = None
        self.running = False
        self.reps = 0
        self.incorrect = 0
        self.stage = None
        self.reached_bottom = False
        self.feedback = 'GET READY'
        self.correction = 'GET INTO POSITION'
        self.bad_form_during_rep = False
        self.tracker = None
        self.saved_result = None
        self.elbow_history = deque(maxlen=5)
        self.upper_arm_history = deque(maxlen=5)
        self.torso_history = deque(maxlen=5)
        self.baseline_upper_arm = None
        self.baseline_torso = None
        self.elbow_angle = 0
        self.arm_angle = 0
        self.current_torso = 0
        self.upper_arm_change = 0
        self.torso_change = 0

    def start(self):
        if self.running:
            return True
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            self.cap.release()
            self.cap = None
            return False
        try:
            self.pose = self.mp_pose.Pose(min_detection_confidence=0.5, min_tracking_confidence=0.5)
        except Exception:
            self.cap.release()
            self.cap = None
            raise
        self.tracker = WorkoutTracker('Single Arm Overhead Tricep Extension')
        self.running = True
        self.thread = threading.Thread(target=self.process_frame, daemon=True)
        self.thread.start()
        return True

    def process_frame(self):
        try:
            while self.running:
                success, frame = self.cap.read()
                if not success:
                    self.feedback = 'CAMERA ERROR'
                    self.correction = 'CAMERA NOT AVAILABLE'
                    break
                frame = cv2.flip(frame, 1)
                result = self.pose.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
                if result.pose_landmarks:
                    self.mp_draw.draw_landmarks(frame, result.pose_landmarks, self.mp_pose.POSE_CONNECTIONS)
                    lm = result.pose_landmarks.landmark
                    p = self.mp_pose.PoseLandmark
                    points = [lm[p.LEFT_SHOULDER.value], lm[p.LEFT_ELBOW.value], lm[p.LEFT_WRIST.value], lm[p.LEFT_HIP.value]]
                    if all(v.visibility > 0.5 for v in points):
                        shoulder, elbow, wrist, hip = [[v.x, v.y] for v in points]
                        self.elbow_history.append(calculate_angle(shoulder, elbow, wrist))
                        self.upper_arm_history.append(upper_arm_angle(shoulder, elbow))
                        self.torso_history.append(torso_angle(shoulder, hip))
                        self.elbow_angle = sum(self.elbow_history)/len(self.elbow_history)
                        self.arm_angle = sum(self.upper_arm_history)/len(self.upper_arm_history)
                        self.current_torso = sum(self.torso_history)/len(self.torso_history)
                        arm_in_position = self.arm_angle < 35
                        if self.elbow_angle > 145 and arm_in_position:
                            self.baseline_upper_arm = (self.arm_angle if self.baseline_upper_arm is None
                                else 0.95*self.baseline_upper_arm + 0.05*self.arm_angle)
                            self.baseline_torso = (self.current_torso if self.baseline_torso is None
                                else 0.95*self.baseline_torso + 0.05*self.current_torso)
                        self.upper_arm_change = (abs(self.arm_angle-self.baseline_upper_arm)
                            if self.baseline_upper_arm is not None else 0)
                        self.torso_change = (abs(self.current_torso-self.baseline_torso)
                            if self.baseline_torso is not None else 0)
                        upper_arm_moving = self.elbow_angle < 145 and self.upper_arm_change > 18
                        torso_moving = self.torso_change > 15
                        full_extension = self.elbow_angle > 155
                        if not arm_in_position:
                            self.correction = 'KEEP UPPER ARM VERTICAL'
                            if self.stage is not None:
                                self.bad_form_during_rep = True
                        elif torso_moving:
                            self.correction = 'KEEP TORSO STABLE'
                            self.bad_form_during_rep = True
                        elif upper_arm_moving:
                            self.correction = 'KEEP ELBOW FIXED'
                            self.bad_form_during_rep = True
                        elif self.stage == 'UP' and self.elbow_angle > 110:
                            self.correction = 'LOWER BEHIND HEAD'
                        elif self.stage == 'UP' and self.elbow_angle >= 90:
                            self.correction = 'LOWER A LITTLE MORE'
                        elif self.stage == 'DOWN' and self.elbow_angle < 125:
                            self.correction = 'EXTEND YOUR ARM'
                        elif self.stage == 'DOWN' and self.elbow_angle <= 155:
                            self.correction = 'EXTEND FULLY'
                        elif full_extension:
                            self.correction = 'GOOD EXTENSION'
                        else:
                            self.correction = 'GOOD FORM'
                        # Same counting sequence as the original: <90 then >155.
                        if self.elbow_angle < 90:
                            if self.stage != 'DOWN':
                                self.stage = 'DOWN'
                                self.reached_bottom = True
                            self.feedback = 'EXTEND ARM'
                        elif self.elbow_angle > 155:
                            if self.stage == 'DOWN' and self.reached_bottom:
                                self.reps += 1
                                if self.bad_form_during_rep:
                                    self.incorrect += 1
                                    self.feedback = 'REP COMPLETED - FORM ISSUE'
                                else:
                                    self.feedback = 'GOOD REP'
                            else:
                                self.feedback = 'LOWER BEHIND HEAD'
                            self.stage = 'UP'
                            self.reached_bottom = False
                            self.bad_form_during_rep = False
                        else:
                            self.feedback = ('KEEP EXTENDING' if self.stage == 'DOWN' else
                                'LOWER SLOWLY' if self.stage == 'UP' else 'LOWER ARM FIRST')
                        h, w = frame.shape[:2]
                        sp, ep, wp, hp = [(int(v[0]*w), int(v[1]*h)) for v in (shoulder, elbow, wrist, hip)]
                        arm_problem = not arm_in_position or upper_arm_moving
                        arm_color = (0,0,255) if arm_problem else (0,255,0)
                        cv2.line(frame, sp, ep, arm_color, 7)
                        cv2.line(frame, ep, wp, arm_color, 7)
                        cv2.line(frame, sp, hp, (0,0,255) if torso_moving else (0,255,0), 5)
                        if not arm_in_position:
                            cv2.arrowedLine(frame, ep, (sp[0], sp[1]-130), (0,0,255), 5, tipLength=0.25)
                        elif upper_arm_moving:
                            cv2.circle(frame, ep, 15, (0,0,255), -1)
                        elif self.stage == 'UP':
                            cv2.arrowedLine(frame, wp, (wp[0], wp[1]+80), (0,165,255), 5, tipLength=0.25)
                        elif self.stage == 'DOWN':
                            cv2.arrowedLine(frame, wp, (wp[0], wp[1]-80), (0,255,0), 5, tipLength=0.25)
                    else:
                        self.feedback = 'BODY NOT VISIBLE'
                        self.correction = 'KEEP LEFT ARM AND TORSO VISIBLE'
                        self.elbow_history.clear()
                        self.upper_arm_history.clear()
                        self.torso_history.clear()
                else:
                    self.feedback = 'BODY NOT DETECTED'
                    self.correction = 'BODY NOT DETECTED'
                    self.elbow_history.clear()
                    self.upper_arm_history.clear()
                    self.torso_history.clear()
                # Place a compact panel at the bottom, keeping the pose visible.
                h, w = frame.shape[:2]
                correct = max(0, self.reps-self.incorrect)
                score = self.tracker.get_form_score(correct, self.incorrect)
                elapsed = self.tracker.get_duration()
                panel_h = min(215, h)
                overlay = frame.copy()
                cv2.rectangle(overlay, (0, h-panel_h), (w, h), (20,25,35), -1)
                cv2.addWeighted(overlay, 0.78, frame, 0.22, 0, frame)
                lines = [
                    'OVERHEAD TRICEP EXTENSION',
                    f'REPS: {self.reps}   FORM ISSUES: {self.incorrect}   SCORE: {score}%',
                    f'TIME: {int(elapsed//60):02d}:{int(elapsed%60):02d}   STAGE: {self.stage or "READY"}',
                    f'MOVEMENT: {self.feedback}',
                    f'CORRECTION: {self.correction}',
                    f'ELBOW: {self.elbow_angle:.0f}   ARM TILT: {self.arm_angle:.0f}   TORSO CHANGE: {self.torso_change:.0f}'
                ]
                step = max(25, min(34, panel_h//6))
                for i, line in enumerate(lines):
                    color = ((0,255,0) if i == 4 and self.correction in ('GOOD FORM','GOOD EXTENSION')
                        else (0,165,255) if i == 4 else (255,255,255))
                    cv2.putText(frame, line, (12, h-panel_h+25+i*step),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.48 if w < 800 else 0.60, color, 2)
                with self.lock:
                    self.frame = frame.copy()
        except Exception as error:
            print('Tricep Extension camera error:', error)
            self.feedback = 'CAMERA ERROR'
            self.correction = str(error)
        finally:
            self.running = False
            if self.cap is not None:
                self.cap.release()
                self.cap = None
            if self.pose is not None:
                self.pose.close()
                self.pose = None

    def get_jpeg_frame(self):
        with self.lock:
            if self.frame is None:
                return None
            frame = self.frame.copy()
        success, buffer = cv2.imencode('.jpg', frame)
        return buffer.tobytes() if success else None

    def get_status(self):
        correct = max(0, self.reps-self.incorrect)
        return {
            'running': self.running,
            'exercise': 'Tricep Extension',
            'reps': self.reps,
            'correct_reps': correct,
            'incorrect_reps': self.incorrect,
            'form_issues': self.incorrect,
            'form_score': self.tracker.get_form_score(correct, self.incorrect) if self.tracker else 0,
            'duration': round(self.tracker.get_duration(), 2) if self.tracker else 0,
            'correction': self.correction,
            'movement': self.feedback,
            'stage': self.stage,
            'elbow_angle': round(self.elbow_angle, 1),
            'upper_arm_angle': round(self.arm_angle, 1),
            'torso_change': round(self.torso_change, 1)
        }

    def stop(self):
        if self.saved_result is not None:
            return self.saved_result
        self.running = False
        if self.thread is not None and self.thread.is_alive():
            self.thread.join(timeout=5)
            if self.thread.is_alive():
                raise RuntimeError('Camera still processing. Try ending again.')
        if self.tracker is None:
            raise RuntimeError('Workout has not started.')
        correct = max(0, self.reps-self.incorrect)
        workout = self.tracker.save_workout(correct, self.incorrect)
        self.tracker.print_summary(workout)
        self.saved_result = {
            'success': True, 'exercise': 'Tricep Extension',
            'total_reps': self.reps, 'correct_reps': correct,
            'incorrect_reps': self.incorrect, 'workout': workout
        }
        return self.saved_result
