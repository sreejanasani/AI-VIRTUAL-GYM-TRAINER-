import cv2
import mediapipe as mp
import math
import threading

from collections import deque
from workout_tracker import WorkoutTracker


def calculate_angle(a, b, c):
    angle = math.degrees(
        math.atan2(c[1] - b[1], c[0] - b[0])
        - math.atan2(a[1] - b[1], a[0] - b[0])
    )

    angle = abs(angle)

    if angle > 180:
        angle = 360 - angle

    return angle


class SquatWorkout:

    def __init__(self):
        self.cap = None
        self.pose = None

        self.mp_pose = mp.solutions.pose
        self.mp_draw = mp.solutions.drawing_utils

        self.lock = threading.RLock()

        self.running = False
        self.saved = False

        self.reps = 0
        self.incomplete = 0

        self.stage = None
        self.feedback = "GET READY"
        self.correction = "GET READY"

        self.reached_depth = False

        self.knee_history = deque(maxlen=5)
        self.torso_history = deque(maxlen=5)
        self.correction_history = deque(maxlen=6)

        self.tracker = None

    def stable_correction(self, message):
        self.correction_history.append(message)

        if len(self.correction_history) < 4:
            return message

        return max(
            set(self.correction_history),
            key=self.correction_history.count
        )

    def start(self):
        with self.lock:
            if self.running:
                return False

            self.cap = cv2.VideoCapture(0)

            if not self.cap.isOpened():
                self.cap.release()
                self.cap = None
                raise RuntimeError("Could not access camera")

            try:
                self.pose = self.mp_pose.Pose(
                    min_detection_confidence=0.5,
                    min_tracking_confidence=0.5
                )
            except Exception:
                self.cap.release()
                self.cap = None
                raise

            self.reps = 0
            self.incomplete = 0

            self.stage = None
            self.feedback = "GET READY"
            self.correction = "GET READY"

            self.reached_depth = False

            self.knee_history.clear()
            self.torso_history.clear()
            self.correction_history.clear()

            self.tracker = WorkoutTracker("Squat")

            self.saved = False
            self.running = True

            return True

    def process_frame(self):
        with self.lock:
            if not self.running or self.cap is None:
                return None

            success, frame = self.cap.read()

            if not success:
                return None

            frame = cv2.flip(frame, 1)

            rgb = cv2.cvtColor(
                frame,
                cv2.COLOR_BGR2RGB
            )

            result = self.pose.process(rgb)

            elapsed = self.tracker.get_duration()

            minutes = int(elapsed // 60)
            seconds = int(elapsed % 60)

            timer_text = f"{minutes:02d}:{seconds:02d}"

            if result.pose_landmarks:

                self.mp_draw.draw_landmarks(
                    frame,
                    result.pose_landmarks,
                    self.mp_pose.POSE_CONNECTIONS
                )

                lm = result.pose_landmarks.landmark

                shoulder = [
                    lm[
                        self.mp_pose.PoseLandmark.LEFT_SHOULDER.value
                    ].x,
                    lm[
                        self.mp_pose.PoseLandmark.LEFT_SHOULDER.value
                    ].y
                ]

                hip = [
                    lm[
                        self.mp_pose.PoseLandmark.LEFT_HIP.value
                    ].x,
                    lm[
                        self.mp_pose.PoseLandmark.LEFT_HIP.value
                    ].y
                ]

                knee = [
                    lm[
                        self.mp_pose.PoseLandmark.LEFT_KNEE.value
                    ].x,
                    lm[
                        self.mp_pose.PoseLandmark.LEFT_KNEE.value
                    ].y
                ]

                ankle = [
                    lm[
                        self.mp_pose.PoseLandmark.LEFT_ANKLE.value
                    ].x,
                    lm[
                        self.mp_pose.PoseLandmark.LEFT_ANKLE.value
                    ].y
                ]

                visible = (
                    lm[
                        self.mp_pose.PoseLandmark.LEFT_SHOULDER.value
                    ].visibility > 0.5
                    and lm[
                        self.mp_pose.PoseLandmark.LEFT_HIP.value
                    ].visibility > 0.5
                    and lm[
                        self.mp_pose.PoseLandmark.LEFT_KNEE.value
                    ].visibility > 0.5
                    and lm[
                        self.mp_pose.PoseLandmark.LEFT_ANKLE.value
                    ].visibility > 0.5
                )

                if visible:

                    raw_knee_angle = calculate_angle(
                        hip,
                        knee,
                        ankle
                    )

                    vertical_point = [
                        hip[0],
                        hip[1] - 0.3
                    ]

                    raw_torso_angle = calculate_angle(
                        shoulder,
                        hip,
                        vertical_point
                    )

                    self.knee_history.append(
                        raw_knee_angle
                    )

                    self.torso_history.append(
                        raw_torso_angle
                    )

                    knee_angle = (
                        sum(self.knee_history)
                        / len(self.knee_history)
                    )

                    torso_angle = (
                        sum(self.torso_history)
                        / len(self.torso_history)
                    )

                    # ORIGINAL SQUAT REP LOGIC

                    if knee_angle > 160:

                        if self.stage == "DOWN":

                            if self.reached_depth:

                                self.reps += 1
                                self.feedback = "GOOD REP"

                                print(
                                    "Completed squat:",
                                    self.reps
                                )

                            else:

                                self.incomplete += 1
                                self.feedback = "INCOMPLETE REP"

                                print(
                                    "Incomplete attempt:",
                                    self.incomplete
                                )

                        else:
                            self.feedback = "READY"

                        self.stage = "UP"
                        self.reached_depth = False

                    else:

                        if self.stage == "UP":
                            self.stage = "DOWN"

                        if knee_angle < 100:

                            self.reached_depth = True
                            self.feedback = "GOOD DEPTH"

                        elif knee_angle < 130:

                            self.feedback = "ALMOST THERE"

                        else:

                            self.feedback = "SQUATTING"

                    # ORIGINAL REAL-TIME CORRECTION

                    if knee_angle > 160:

                        raw_correction = (
                            "READY - START SQUAT"
                        )

                    elif torso_angle > 50:

                        raw_correction = (
                            "KEEP CHEST UP"
                        )

                    elif knee_angle >= 130:

                        raw_correction = "GO LOWER"

                    elif knee_angle >= 100:

                        raw_correction = (
                            "A LITTLE LOWER"
                        )

                    elif knee_angle >= 75:

                        raw_correction = (
                            "GOOD DEPTH - STAND UP"
                        )

                    else:

                        raw_correction = "STAND UP"

                    self.correction = (
                        self.stable_correction(
                            raw_correction
                        )
                    )

                    form_score = (
                        self.tracker.get_form_score(
                            self.reps,
                            self.incomplete
                        )
                    )

                    # DISPLAY COORDINATES

                    h, w, _ = frame.shape

                    shoulder_px = (
                        int(shoulder[0] * w),
                        int(shoulder[1] * h)
                    )

                    hip_px = (
                        int(hip[0] * w),
                        int(hip[1] * h)
                    )

                    knee_px = (
                        int(knee[0] * w),
                        int(knee[1] * h)
                    )

                    ankle_px = (
                        int(ankle[0] * w),
                        int(ankle[1] * h)
                    )

                    # ORIGINAL VISUAL CORRECTIONS

                    if self.correction in [
                        "GO LOWER",
                        "A LITTLE LOWER"
                    ]:

                        cv2.circle(
                            frame,
                            knee_px,
                            15,
                            (0, 165, 255),
                            -1
                        )

                        arrow_start = (
                            hip_px[0] + 40,
                            hip_px[1]
                        )

                        arrow_end = (
                            hip_px[0] + 40,
                            hip_px[1] + 80
                        )

                        cv2.arrowedLine(
                            frame,
                            arrow_start,
                            arrow_end,
                            (0, 165, 255),
                            5,
                            tipLength=0.3
                        )

                    elif self.correction == (
                        "KEEP CHEST UP"
                    ):

                        cv2.line(
                            frame,
                            shoulder_px,
                            hip_px,
                            (0, 0, 255),
                            6
                        )

                        arrow_start = shoulder_px

                        arrow_end = (
                            shoulder_px[0],
                            shoulder_px[1] - 80
                        )

                        cv2.arrowedLine(
                            frame,
                            arrow_start,
                            arrow_end,
                            (0, 0, 255),
                            5,
                            tipLength=0.3
                        )

                    elif self.correction in [
                        "GOOD DEPTH - STAND UP",
                        "STAND UP"
                    ]:

                        cv2.circle(
                            frame,
                            hip_px,
                            12,
                            (0, 255, 0),
                            -1
                        )

                        arrow_start = (
                            hip_px[0] + 40,
                            hip_px[1]
                        )

                        arrow_end = (
                            hip_px[0] + 40,
                            hip_px[1] - 80
                        )

                        cv2.arrowedLine(
                            frame,
                            arrow_start,
                            arrow_end,
                            (0, 255, 0),
                            5,
                            tipLength=0.3
                        )

                    # ANGLE DISPLAY

                    cv2.putText(
                        frame,
                        str(int(knee_angle)),
                        knee_px,
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.8,
                        (255, 255, 255),
                        2
                    )

                    # ORIGINAL INFORMATION PANEL

                    cv2.rectangle(
                        frame,
                        (0, 0),
                        (680, 330),
                        (30, 30, 30),
                        -1
                    )

                    cv2.putText(
                        frame,
                        "AI GYM TRAINER - SQUAT",
                        (20, 35),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (255, 255, 255),
                        2
                    )

                    cv2.putText(
                        frame,
                        "REPS: " + str(self.reps),
                        (20, 75),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        1,
                        (0, 255, 0),
                        2
                    )

                    cv2.putText(
                        frame,
                        "INCOMPLETE: " + str(
                            self.incomplete
                        ),
                        (200, 75),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (0, 255, 255),
                        2
                    )

                    cv2.putText(
                        frame,
                        "FORM SCORE: "
                        + str(form_score)
                        + "%",
                        (20, 115),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.65,
                        (0, 255, 0),
                        2
                    )

                    cv2.putText(
                        frame,
                        "TIME: " + timer_text,
                        (350, 115),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.65,
                        (255, 255, 255),
                        2
                    )

                    cv2.putText(
                        frame,
                        "POSITION: " + str(
                            self.stage
                        ),
                        (20, 155),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (255, 255, 0),
                        2
                    )

                    cv2.putText(
                        frame,
                        "MOVEMENT: "
                        + self.feedback,
                        (20, 195),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.65,
                        (255, 255, 0),
                        2
                    )

                    cv2.putText(
                        frame,
                        "CORRECTION:",
                        (20, 235),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (255, 255, 255),
                        2
                    )

                    if self.correction in [
                        "READY - START SQUAT",
                        "GOOD DEPTH - STAND UP"
                    ]:

                        correction_color = (
                            0, 255, 0
                        )

                    else:

                        correction_color = (
                            0, 165, 255
                        )

                    cv2.putText(
                        frame,
                        self.correction,
                        (20, 275),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.8,
                        correction_color,
                        2
                    )

                    cv2.putText(
                        frame,
                        "KNEE: "
                        + str(int(knee_angle))
                        + "  TORSO LEAN: "
                        + str(int(torso_angle)),
                        (20, 305),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.55,
                        (255, 255, 255),
                        2
                    )

                    # Browser workouts use End Workout
                    # instead of the Q keyboard shortcut.

                    cv2.putText(
                        frame,
                        "Use End Workout in browser",
                        (20, 325),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.45,
                        (255, 255, 255),
                        1
                    )

                else:

                    cv2.putText(
                        frame,
                        "KEEP FULL SIDE OF BODY VISIBLE",
                        (20, 50),
                        cv2.FONT_HERSHEY_SIMPLEX,
                        0.7,
                        (0, 0, 255),
                        2
                    )

            else:

                cv2.putText(
                    frame,
                    "BODY NOT DETECTED",
                    (20, 50),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.8,
                    (0, 0, 255),
                    2
                )

            return frame

    def get_jpeg_frame(self):
        frame = self.process_frame()

        if frame is None:
            return None

        success, buffer = cv2.imencode(
            ".jpg",
            frame,
            [cv2.IMWRITE_JPEG_QUALITY, 85]
        )

        if not success:
            return None

        return buffer.tobytes()

    def get_status(self):
        with self.lock:
            duration = (
                self.tracker.get_duration()
                if self.tracker
                else 0
            )

            total = self.reps + self.incomplete

            form_score = (
                self.tracker.get_form_score(
                    self.reps,
                    self.incomplete
                )
                if self.tracker
                else 0
            )

            return {
                "running": self.running,
                "exercise": "Squat",
                "reps": self.reps,
                "correct_reps": self.reps,
                "form_issues": self.incomplete,
                "form_score": form_score,
                "correction": self.correction,
                "movement": self.feedback,
                "stage": self.stage,
                "duration": duration
            }

    def stop(self):
        with self.lock:
            if self.saved:
                return None

            self.running = False

            if self.cap is not None:
                self.cap.release()
                self.cap = None

            if self.pose is not None:
                self.pose.close()
                self.pose = None

            self.saved = True

            if self.tracker is None:
                return None

            workout = self.tracker.save_workout(
                self.reps,
                self.incomplete
            )

            self.tracker.print_summary(workout)

            return workout