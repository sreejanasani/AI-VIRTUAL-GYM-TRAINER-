import time
from database import get_connection


class WorkoutTracker:

    def __init__(self, exercise):
        self.exercise = exercise
        self.start_time = time.time()


    # =========================
    # DURATION
    # =========================

    def get_duration(self):
        return time.time() - self.start_time


    # =========================
    # FORM SCORE
    # =========================

    def get_form_score(
        self,
        correct_reps,
        incorrect_reps
    ):

        total = correct_reps + incorrect_reps

        if total == 0:
            return 0

        return round(
            (correct_reps / total) * 100,
            1
        )


    # =========================
    # SAVE WORKOUT
    # =========================

    def save_workout(
        self,
        correct_reps,
        incorrect_reps
    ):

        duration = round(
            self.get_duration(),
            2
        )

        total_reps = (
            correct_reps +
            incorrect_reps
        )

        form_score = self.get_form_score(
            correct_reps,
            incorrect_reps
        )


        connection = None
        cursor = None


        try:

            connection = get_connection()

            cursor = connection.cursor()


            query = """
                INSERT INTO workouts (
                    exercise,
                    total_reps,
                    correct_reps,
                    incorrect_reps,
                    form_score,
                    duration_seconds,
                    good_form_seconds
                )
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """


            values = (
                self.exercise,
                total_reps,
                correct_reps,
                incorrect_reps,
                form_score,
                duration,
                0
            )


            cursor.execute(
                query,
                values
            )

            connection.commit()


            workout_id = cursor.lastrowid


            workout = {
                "id": workout_id,
                "exercise": self.exercise,
                "total_reps": total_reps,
                "correct_reps": correct_reps,
                "incorrect_reps": incorrect_reps,
                "form_score": form_score,
                "duration_seconds": duration
            }


            return workout


        except Exception as e:

            print(
                "Error saving workout:"
            )

            print(e)

            return None


        finally:

            if cursor is not None:
                cursor.close()

            if (
                connection is not None
                and
                connection.is_connected()
            ):
                connection.close()


    # =========================
    # PRINT SUMMARY
    # =========================

    def print_summary(
        self,
        workout
    ):

        if workout is None:

            print(
                "Workout was not saved."
            )

            return


        duration = workout[
            "duration_seconds"
        ]

        minutes = int(
            duration // 60
        )

        seconds = int(
            duration % 60
        )


        print()

        print(
            "=============================="
        )

        print(
            "       WORKOUT SUMMARY"
        )

        print(
            "=============================="
        )

        print(
            "Workout ID:",
            workout["id"]
        )

        print(
            "Exercise:",
            workout["exercise"]
        )

        print(
            "Total Reps:",
            workout["total_reps"]
        )

        print(
            "Correct Reps:",
            workout["correct_reps"]
        )

        print(
            "Form Issues:",
            workout["incorrect_reps"]
        )

        print(
            "Form Score:",
            str(workout["form_score"]) + "%"
        )

        print(
            "Duration:",
            f"{minutes} min {seconds} sec"
        )

        print(
            "=============================="
        )

        print(
            "Workout saved to MySQL!"
        )