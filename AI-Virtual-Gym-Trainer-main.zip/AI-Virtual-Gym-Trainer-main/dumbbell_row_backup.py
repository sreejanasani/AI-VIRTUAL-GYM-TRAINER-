import cv2
import mediapipe as mp
import math
from collections import deque

from workout_tracker import WorkoutTracker


def calculate_angle(a, b, c):
    angle = math.degrees(
        math.atan2(c[1] - b[1], c[0] - b[0]) -
        math.atan2(a[1] - b[1], a[0] - b[0])
    )

    angle = abs(angle)

    if angle > 180:
        angle = 360 - angle

    return angle


def calculate_torso_angle(shoulder, hip):
    dx = shoulder[0] - hip[0]
    dy = hip[1] - shoulder[1]

    if dy <= 0:
        return 0

    return math.degrees(
        math.atan2(abs(dx), abs(dy))
    )


# -------------------------
# CAMERA
# -------------------------

cap = cv2.VideoCapture(0)

mp_pose = mp.solutions.pose

pose = mp_pose.Pose(
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

mp_draw = mp.solutions.drawing_utils


# -------------------------
# VARIABLES
# -------------------------

reps = 0
incorrect = 0

stage = None

feedback = "GET READY"
correction = "LEAN FORWARD INTO ROW POSITION"

reached_top = False
bad_form_during_rep = False

baseline_torso_angle = None
setup_ready = False

tracker = WorkoutTracker("Dumbbell Row")


# -------------------------
# SMOOTHING
# -------------------------

elbow_history = deque(maxlen=5)
torso_history = deque(maxlen=7)


# -------------------------
# MAIN LOOP
# -------------------------

while True:

    success, frame = cap.read()

    if not success:
        print("Could not access camera")
        break

    frame = cv2.flip(frame, 1)

    rgb = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )

    result = pose.process(rgb)


    # -------------------------
    # TIMER
    # -------------------------

    elapsed = tracker.get_duration()

    minutes = int(elapsed // 60)
    seconds = int(elapsed % 60)

    timer_text = f"{minutes:02d}:{seconds:02d}"


    # -------------------------
    # POSE DETECTED
    # -------------------------

    if result.pose_landmarks:

        mp_draw.draw_landmarks(
            frame,
            result.pose_landmarks,
            mp_pose.POSE_CONNECTIONS
        )

        lm = result.pose_landmarks.landmark


        # -------------------------
        # LANDMARKS
        # -------------------------

        shoulder = [
            lm[
                mp_pose.PoseLandmark.LEFT_SHOULDER.value
            ].x,
            lm[
                mp_pose.PoseLandmark.LEFT_SHOULDER.value
            ].y
        ]

        elbow = [
            lm[
                mp_pose.PoseLandmark.LEFT_ELBOW.value
            ].x,
            lm[
                mp_pose.PoseLandmark.LEFT_ELBOW.value
            ].y
        ]

        wrist = [
            lm[
                mp_pose.PoseLandmark.LEFT_WRIST.value
            ].x,
            lm[
                mp_pose.PoseLandmark.LEFT_WRIST.value
            ].y
        ]

        hip = [
            lm[
                mp_pose.PoseLandmark.LEFT_HIP.value
            ].x,
            lm[
                mp_pose.PoseLandmark.LEFT_HIP.value
            ].y
        ]


        # -------------------------
        # VISIBILITY
        # -------------------------

        visible = (
            lm[
                mp_pose.PoseLandmark.LEFT_SHOULDER.value
            ].visibility > 0.5
            and
            lm[
                mp_pose.PoseLandmark.LEFT_ELBOW.value
            ].visibility > 0.5
            and
            lm[
                mp_pose.PoseLandmark.LEFT_WRIST.value
            ].visibility > 0.5
            and
            lm[
                mp_pose.PoseLandmark.LEFT_HIP.value
            ].visibility > 0.5
        )


        if visible:

            # -------------------------
            # ELBOW ANGLE
            # -------------------------

            raw_elbow_angle = calculate_angle(
                shoulder,
                elbow,
                wrist
            )

            elbow_history.append(
                raw_elbow_angle
            )

            elbow_angle = (
                sum(elbow_history) /
                len(elbow_history)
            )


            # -------------------------
            # TORSO ANGLE
            # -------------------------

            raw_torso_angle = calculate_torso_angle(
                shoulder,
                hip
            )

            torso_history.append(
                raw_torso_angle
            )

            torso_angle = (
                sum(torso_history) /
                len(torso_history)
            )


            # -------------------------
            # ROW SETUP
            # -------------------------

            proper_row_setup = (
                30 <= torso_angle <= 75
            )


            # -------------------------
            # ENTER ROW POSITION
            # -------------------------

            if (
                proper_row_setup
                and
                not setup_ready
            ):

                setup_ready = True

                baseline_torso_angle = (
                    torso_angle
                )

                stage = None
                reached_top = False

                feedback = "ROW POSITION READY"

                correction = (
                    "EXTEND ARM TO START"
                )


            # -------------------------
            # LEAVE ROW POSITION
            # -------------------------
            #
            # IMPORTANT:
            #
            # We do NOT immediately reset
            # the rep state anymore.
            #
            # If the person becomes almost
            # upright, then we cancel setup.
            #
            # -------------------------

            if (
                setup_ready
                and
                torso_angle < 18
            ):

                setup_ready = False

                baseline_torso_angle = None

                stage = None
                reached_top = False

                bad_form_during_rep = False

                feedback = (
                    "WAITING FOR ROW POSITION"
                )

                correction = (
                    "LEAN FORWARD INTO ROW POSITION"
                )


            # -------------------------
            # NOT READY
            # -------------------------

            if not setup_ready:

                torso_change = 0

                torso_unstable = False
                elbow_far_from_hip = False

                feedback = (
                    "WAITING FOR ROW POSITION"
                )

                correction = (
                    "LEAN FORWARD INTO ROW POSITION"
                )


            # -------------------------
            # READY
            # -------------------------

            else:

                # -------------------------
                # TORSO CHANGE
                # -------------------------

                torso_change = abs(
                    torso_angle -
                    baseline_torso_angle
                )


                # -------------------------
                # TORSO STABILITY
                # -------------------------

                torso_unstable = (
                    elbow_angle < 140
                    and
                    torso_change > 18
                )


                # -------------------------
                # ELBOW TO HIP DISTANCE
                # -------------------------

                elbow_to_hip_distance = math.sqrt(
                    (
                        elbow[0] -
                        hip[0]
                    ) ** 2
                    +
                    (
                        elbow[1] -
                        hip[1]
                    ) ** 2
                )


                # -------------------------
                # ELBOW PATH
                # -------------------------

                elbow_far_from_hip = (
                    elbow_angle < 110
                    and
                    elbow_to_hip_distance > 0.32
                )


                # -------------------------
                # FORM CORRECTION
                # -------------------------

                if not proper_row_setup:

                    correction = (
                        "RETURN TO ROW POSITION"
                    )

                    bad_form_during_rep = True


                elif torso_unstable:

                    correction = (
                        "KEEP TORSO STABLE"
                    )

                    bad_form_during_rep = True


                elif elbow_far_from_hip:

                    correction = (
                        "PULL ELBOW TOWARD HIP"
                    )

                    bad_form_during_rep = True


                elif (
                    stage == "EXTENDED"
                    and
                    elbow_angle > 120
                ):

                    correction = (
                        "PULL ELBOW BACK"
                    )


                elif (
                    stage == "EXTENDED"
                    and
                    elbow_angle >= 100
                ):

                    correction = (
                        "PULL HIGHER"
                    )


                elif stage == "PULLED":

                    correction = (
                        "EXTEND ARM FULLY"
                    )


                else:

                    correction = (
                        "GOOD ROW POSITION"
                    )


                # =========================
                # REP COUNTING
                # =========================
                #
                # EXTENDED > 145
                #
                # PULLED < 100
                #
                # RETURN > 145
                #
                # = ONE REP
                # =========================


                # -------------------------
                # ARM EXTENDED
                # -------------------------

                if elbow_angle > 145:

                    if (
                        stage == "PULLED"
                        and
                        reached_top
                    ):

                        reps += 1


                        if bad_form_during_rep:

                            incorrect += 1

                            feedback = (
                                "REP COMPLETED - FORM ISSUE"
                            )

                        else:

                            feedback = (
                                "GOOD REP"
                            )


                        print(
                            "Dumbbell Row:",
                            reps
                        )


                    else:

                        feedback = "PULL"


                    stage = "EXTENDED"

                    reached_top = False

                    bad_form_during_rep = False


                    # Slowly learn the
                    # normal torso position
                    # while arm is extended.

                    if proper_row_setup:

                        baseline_torso_angle = (
                            0.95 *
                            baseline_torso_angle
                            +
                            0.05 *
                            torso_angle
                        )


                # -------------------------
                # PULLED POSITION
                # -------------------------

                elif elbow_angle < 100:

                    if stage == "EXTENDED":

                        stage = "PULLED"

                        reached_top = True

                        feedback = (
                            "GOOD PULL"
                        )


                    elif stage == "PULLED":

                        feedback = (
                            "EXTEND SLOWLY"
                        )


                    else:

                        feedback = (
                            "EXTEND ARM FIRST"
                        )


                # -------------------------
                # MIDDLE
                # -------------------------

                else:

                    if stage == "EXTENDED":

                        feedback = (
                            "KEEP PULLING"
                        )


                    elif stage == "PULLED":

                        feedback = (
                            "EXTEND ARM"
                        )


                    else:

                        feedback = (
                            "EXTEND ARM FIRST"
                        )


            # -------------------------
            # FORM SCORE
            # -------------------------

            correct_reps = (
                reps - incorrect
            )

            if correct_reps < 0:
                correct_reps = 0


            form_score = tracker.get_form_score(
                correct_reps,
                incorrect
            )


            # -------------------------
            # PIXEL POSITIONS
            # -------------------------

            h, w, _ = frame.shape


            shoulder_px = (
                int(shoulder[0] * w),
                int(shoulder[1] * h)
            )

            elbow_px = (
                int(elbow[0] * w),
                int(elbow[1] * h)
            )

            wrist_px = (
                int(wrist[0] * w),
                int(wrist[1] * h)
            )

            hip_px = (
                int(hip[0] * w),
                int(hip[1] * h)
            )


            # -------------------------
            # TORSO COLOR
            # -------------------------

            if not setup_ready:

                torso_color = (
                    0,
                    0,
                    255
                )


            elif (
                not proper_row_setup
                or
                torso_unstable
            ):

                torso_color = (
                    0,
                    0,
                    255
                )


            else:

                torso_color = (
                    0,
                    255,
                    0
                )


            cv2.line(
                frame,
                shoulder_px,
                hip_px,
                torso_color,
                7
            )


            # -------------------------
            # LEAN FORWARD ARROW
            # -------------------------

            if not setup_ready:

                arrow_end = (
                    shoulder_px[0] + 80,
                    shoulder_px[1] + 50
                )

                cv2.arrowedLine(
                    frame,
                    shoulder_px,
                    arrow_end,
                    (0, 0, 255),
                    5,
                    tipLength=0.25
                )


            # -------------------------
            # ELBOW PATH
            # -------------------------

            elif elbow_far_from_hip:

                cv2.circle(
                    frame,
                    elbow_px,
                    14,
                    (0, 0, 255),
                    -1
                )

                cv2.arrowedLine(
                    frame,
                    elbow_px,
                    hip_px,
                    (0, 0, 255),
                    5,
                    tipLength=0.20
                )


            elif stage == "EXTENDED":

                target_x = int(
                    (
                        elbow[0] +
                        hip[0]
                    ) / 2 * w
                )

                target_y = int(
                    (
                        elbow[1] +
                        hip[1]
                    ) / 2 * h
                )

                cv2.arrowedLine(
                    frame,
                    elbow_px,
                    (
                        target_x,
                        target_y
                    ),
                    (0, 165, 255),
                    5,
                    tipLength=0.25
                )


            # -------------------------
            # ANGLE
            # -------------------------

            cv2.putText(
                frame,
                str(int(elbow_angle)),
                elbow_px,
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )


            # -------------------------
            # PANEL
            # -------------------------

            cv2.rectangle(
                frame,
                (0, 0),
                (800, 430),
                (30, 30, 30),
                -1
            )


            cv2.putText(
                frame,
                "AI GYM TRAINER - DUMBBELL ROW",
                (20, 35),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "REPS: " +
                str(reps),
                (20, 80),
                cv2.FONT_HERSHEY_SIMPLEX,
                1,
                (0, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "FORM ISSUES: " +
                str(incorrect),
                (190, 80),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "FORM SCORE: " +
                str(form_score) +
                "%",
                (20, 120),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (0, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "TIME: " +
                timer_text,
                (350, 120),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )


            # -------------------------
            # SETUP DISPLAY
            # -------------------------

            if setup_ready:

                setup_text = (
                    "READY - ROW POSITION"
                )

                setup_color = (
                    0,
                    255,
                    0
                )

            else:

                setup_text = (
                    "NOT READY - LEAN FORWARD"
                )

                setup_color = (
                    0,
                    0,
                    255
                )


            cv2.putText(
                frame,
                "SETUP: " +
                setup_text,
                (20, 160),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                setup_color,
                2
            )


            cv2.putText(
                frame,
                "POSITION: " +
                str(stage),
                (20, 200),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 0),
                2
            )


            cv2.putText(
                frame,
                "MOVEMENT: " +
                feedback,
                (20, 240),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 0),
                2
            )


            # -------------------------
            # CORRECTION COLOR
            # -------------------------

            if (
                not setup_ready
                or
                not proper_row_setup
                or
                torso_unstable
                or
                elbow_far_from_hip
            ):

                correction_color = (
                    0,
                    0,
                    255
                )


            elif (
                correction ==
                "GOOD ROW POSITION"
            ):

                correction_color = (
                    0,
                    255,
                    0
                )


            else:

                correction_color = (
                    0,
                    165,
                    255
                )


            cv2.putText(
                frame,
                "CORRECTION:",
                (20, 280),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                correction,
                (20, 320),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.65,
                correction_color,
                2
            )


            cv2.putText(
                frame,
                "ELBOW: " +
                str(int(elbow_angle)) +
                "   TORSO LEAN: " +
                str(int(torso_angle)),
                (20, 360),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.6,
                (255, 255, 255),
                2
            )


            cv2.putText(
                frame,
                "REP TARGET: >145 -> <100 -> >145",
                (20, 395),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (255, 255, 255),
                1
            )


            cv2.putText(
                frame,
                "TORSO CHANGE: " +
                str(
                    round(
                        torso_change,
                        1
                    )
                ),
                (390, 395),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                (255, 255, 255),
                1
            )


        else:

            cv2.putText(
                frame,
                "KEEP LEFT SIDE VISIBLE",
                (20, 50),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 0, 255),
                2
            )


    else:

        cv2.putText(
            frame,
            "BODY NOT DETECTED",
            (20, 50),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 0, 255),
            2
        )


    cv2.imshow(
        "AI Gym Trainer - Dumbbell Row",
        frame
    )


    if cv2.waitKey(1) & 0xFF == ord("q"):
        break


# -------------------------
# CLEANUP
# -------------------------

cap.release()
pose.close()
cv2.destroyAllWindows()


# -------------------------
# SAVE WORKOUT
# -------------------------

correct_reps = reps - incorrect

if correct_reps < 0:
    correct_reps = 0


workout = tracker.save_workout(
    correct_reps,
    incorrect
)

tracker.print_summary(
    workout
)